<?php
include('conn/db_connect.php');

$place = $_POST['curier_name'];
if($place=='self'){
    $dt = "<td><label for='area'>From Center:</label></td><td><select style='width:100%' class='inp_cls11' name='curier_area'>";
    $dt .= "<option value='gulshan'>Gulshan Office</option>";
    $dt .= "<option value='banani'>Banani Office</option>";
    $dt .= "<option value='badda'>Badda Office</option>";
    $dt .= "</select></td>";
    echo $dt;
}


/*$q =  mysql_query("SELECT * from irc_area WHERE city_id='$id'") ;
while($ar = mysql_fetch_assoc($q)){ 
    $dt .= '<option value="'.$ar['area_id'].'">'.$ar["area_name"].'</option>';
    
}*/

//echo $dt;

?>


