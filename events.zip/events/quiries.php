<?php

/***************************************** RESOURCE CATEGORY ***************************************************/

   mysql_query("set names 'utf8'");
   $res_cat="SELECT
			resource_category.resource_category as category,
			Count(resources.resource_category) as total,
			resource_category_id
			FROM
			resources
			RIGHT OUTER JOIN resource_category ON resources.resource_category = resource_category.resource_category_id
			GROUP BY resource_category.resource_category
			ORDER BY resource_category._sort";
   $res_cat_rows = mysql_query($res_cat);
   
   /////////////////////////////////////
   
   	mysql_query("set names 'utf8'");
	$res_qry="SELECT
				resource_category.resource_category as category,
				Count(resource_category.resource_category_id) as total
				FROM
				resources
				INNER JOIN resource_category ON resources.resource_category = resource_category.resource_category_id
				GROUP BY resource_category.resource_category";
	$query1 = mysql_query($res_qry);


/********************************************* RESOURCE FOR ***********************************************/

mysql_query("set names 'utf8'");
$res_for="SELECT 
			resource_for.resource_for_id, 	
			resource_for.resource_for,
			count(resources.resource_for)
			FROM
			resource_for
			LEFT OUTER JOIN resources ON resource_for.resource_for_id = resources.resource_for
			GROUP BY resource_for.resource_for
			ORDER BY resource_for._sort";
$res_for1 = mysql_query($res_for);
	
	////////////////////////////////////
	
	mysql_query("set names 'utf8'");
	$res_for="SELECT 
				resource_for.resource_for_id, 	
				resource_for.resource_for,
				count(resources.resource_for)
				FROM
				resource_for
				LEFT OUTER JOIN resources ON resource_for.resource_for_id = resources.resource_for
				
				GROUP BY resource_for.resource_for
				ORDER BY resource_for._sort";
	$res_for1 = mysql_query($res_for); 
	
/********************************************* AUTHOR INFO ***********************************************/

mysql_query("set names 'utf8'");
$res_author="SELECT
			count(resources.author_id),
			author_info.author_id,
			author_info.author_name
			FROM
			author_info
			LEFT OUTER JOIN resources ON author_info.author_id = resources.author_id
			GROUP BY author_info.author_id
			ORDER BY author_info._sort
			LIMIT 30";
$res_author1 = mysql_query($res_author);	

//////////////////////////////////////////////

mysql_query("set names 'utf8'");
$author_lists = mysql_query("SELECT * FROM	author_info ORDER BY author_name");
//////////////////////////////////////////////

/******************************************** AUTHOR NUMBER ************************************************/
mysql_query("set names 'utf8'");
$num_author = mysql_query("SELECT
			count(resources.author_id),
			author_info.author_id,
			author_info.author_name
			FROM
			author_info
			LEFT OUTER JOIN resources ON author_info.author_id = resources.author_id
			GROUP BY author_info.author_id
			ORDER BY author_info._sort");	
$num_authors = mysql_num_rows($num_author);

/*********************************************** RESOURCES NUMBER *********************************************/
mysql_query("set names 'utf8'");
$total_resource="SELECT resource_id FROM resources";
$total = mysql_query($total_resource);
$total_rows = mysql_num_rows($total);

/************************************************ EVENT INFO *******************************************************/
////////////////////////////////
//$date=date('Y-m-d');
//mysql_query("UPDATE irc_event SET active=0 WHERE event_date < ".$date."");
mysql_query("set names 'utf8'");
$event_list = mysql_query("SELECT * FROM irc_event WHERE active=1 ORDER BY event_date");


/************************************************ RESOURCE UPDATE *******************************************************/


?>