<?php 
include('conn/db_connect.php'); 

if($_POST){    
    $subject=mysql_real_escape_string($_POST['subject']);
    $city_id=mysql_real_escape_string($_POST['city']);
    $area_id=mysql_real_escape_string($_POST['area']);
    $qurandate=mysql_real_escape_string($_POST['qurandate']);
    $qurantime=mysql_real_escape_string($_POST['qurantime']);
    $speaker=mysql_real_escape_string($_POST['speaker']);
    $place=mysql_real_escape_string($_POST['place']);
    $introduction=mysql_real_escape_string($_POST['introduction']);

	mysql_query("set names 'utf8'");
        $sql = "INSERT INTO
                irc_quran 
            SET
                quran_subject = '$subject',
                city_id = '$city_id',
                area_id = '$area_id',
                quran_date = '$qurandate',
                quran_time = '$qurantime',
                speaker = '$speaker',
                place = '$place',
                introduction = '$introduction'";
				
        mysql_query($sql, $db_con);
}
header('location: quran.php');
?>