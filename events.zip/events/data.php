<?php include('conn/db_connect.php'); ?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
    <meta charset="UTF-8" />
        <!-- base href="/" --><!--[if IE]></base><![endif]-->
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="description" content="Search panel designed by Apsis Solutions." />
        <title>Custom Search</title>

        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />

        <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/jquery.flexisel.js"></script>
        </head>
        <body>
        <?php
		for($i=1; $i<=20; $i++){
         echo '<div id="div_'.$i.'" class="hello chupa">my_div_'.$i.'</div>';
		}
		 ?>
         <br />
         <div id="pagination"></div>

</body>
</html>
<script>
$(document).ready(function(e) {
    var num_div = $('div.hello').length;
	var num_page = (num_div/4);
	var str = '';
	for(var i=1; i <= num_page; i++){
		str += '<a class="pagi" id="'+i+'" show_div="div_'+i+'" href="javascript:void(0);" style="padding:5px; border:1px solid #666">'+i+'</a>';
	}
	$('#pagination').html(str);
	$('.hello').hide();
	for(var i = 1; i <= 4; i++){
		$('#div_'+i).show(); 
	}
});
$(document).on('click','.pagi',function(){
	var div_id = $(this).attr('show_div');
	var cur_id =  $(this).attr('id');
	$('.hello').hide();
	for(var i = 1; i <= 4; i++){
		var show_div = ((parseInt(cur_id)*4)-4)+i;
		$('#div_'+show_div).show(); 
	}
});
</script>