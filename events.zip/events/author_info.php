<?php include('conn/db_connect.php'); ?>
<?php include('quiries.php');?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <!-- base href="/" --><!--[if IE]></base><![endif]-->
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="description" content="Search panel designed by Apsis Solutions." />
        <title>Custom Search</title>

        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />

        <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/jquery.flexisel.js"></script>
    </head>
    
    <body>  
        <div class="wrapper">
            <div class="header">
                <div class="logo">
                    <a href="<?php echo $home_url; ?>"><img src="images/search.png" /></a>
                </div>
                <div class="title">
                    <img src="images/irc.png" />
                </div>
            </div>
            <div class="clear"></div>
            <div class="container">
                 <div class="top_menu">
                    <ul>
                    <?php	 	
                        while($res_for_rows =  mysql_fetch_row($res_for1)){
                    ?>
                    <li><a href="<?php echo $home_url; ?>?id=<?php echo $res_for_rows[0]; ?>"><?php echo $res_for_rows[1]; ?> (<?php echo $res_for_rows[2]; ?>)</a></li>
                    <?php
                    }
                    ?> 
                    </ul>
                    <div class="clear"></div>
                </div>

                
          <?php 
            $a_id=$_GET['a_id'];
			mysql_query("set names 'utf8'");
            $author = mysql_query("SELECT * FROM author_info 
                    WHERE author_id='$a_id'", $db_con);
            while($auth=mysql_fetch_assoc($author)){
         ?>               
                  
<div align="center">
  <center>
  <table border="0" cellpadding="3" cellspacing="3" style="border-collapse: collapse" bordercolor="#111111" width="70%">
      <tr><td width="">&nbsp;</td></tr>
    <tr>
      <td width="34%"><img style="float: left; padding-right: 10px;" border="0" src="<?php echo $auth['author_photo']?>" width="250" height="250"><b><?php echo $auth['author_name']?></b><br><br><?php echo $auth['author_desc1']?></td>
    </tr>
    <tr><td width="">&nbsp;</td></tr>
    <tr><td width=""><?php echo $auth['author_desc2']?></td></tr>
  </table>
  </center>
</div>
<?php } ?>
<div id="tab1">
    <script>
        get_result('');
    </script>
</div>
     <br />
     <br />
<div class="clear"></div>

            </div>
        </div>
    </body>
</html>
