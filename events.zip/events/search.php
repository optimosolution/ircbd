<?php include('conn/db_connect.php'); ?>
<?php
mysql_query("set names 'utf8'");
$sql = "SELECT search_text FROM search_text WHERE search_text LIKE '".$_GET['term']."%'";
//echo $sql;
$query = mysql_query($sql);

while($row = mysql_fetch_array($query)){
	$item[]['name'] = $row[0];
}

echo (json_encode($item));
?>