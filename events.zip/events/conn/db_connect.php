<?php
$hostname = "localhost"; 
$username = "icshost_ircold";
$password = "0d-71~b-b9x@";
 

$db_con = mysql_connect($hostname, $username, $password)
  or die("Unable to connect to MySQL");
  
$db_selected = mysql_select_db('icshost_ircold', $db_con);
if (!$db_selected) {
    die ('Can\'t use spicygreendb : ' . mysql_error());
}

$home_url='http://www.islamicresourcecenter.com/';

?>