<?php include('conn/db_connect.php'); ?>
<?php include('quiries.php');?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
    <meta charset="UTF-8" />
        <!-- base href="/" --><!--[if IE]></base><![endif]-->
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="description" content="Search panel designed by Apsis Solutions." />
        <title>Custom Search</title>

        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />

        <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/jquery.flexisel.js"></script>
		
        <script src="js/lean-slider.js"></script>
        <link rel="stylesheet" href="js/lean-slider.css" type="text/css" />
        <script src="js/modernizr-2.6.1.min.js"></script>
		
        <script>
            function get_result(name,type){
                $.ajax({
                    url:'find_result.php',
                    type:'POST',
                    data:{name:name,type:type},
                    success:function(data){
                        //alert(data);
                        $('#tab1').html('');
                        mydata = $.parseJSON(data);
                        var total_result = mydata.length;
                        $('#tab1').html('<p style="font-size:10px;color:#ccc;">Total Result Found - '+total_result+'</p>');
                        
                        for(var k in mydata){
                            $('#tab1').append('<div id="div_'+k+'" class="search_container category' + mydata[k].resource_data['resource_category'] + ' auth' + mydata[k].resource_data['author_id'] + '"><div class="search_image"><img height="60" width="60" src="' + mydata[k].resource_data['resource_image'] + '" /></div>'+
                                    '<div class="search_details"><h3 style="padding:5px;"> <a href="' + mydata[k].resource_data['link'] + '" target=_blank>'+mydata[k].resource_data['title']+' ('+mydata[k].resource_data['code']+')</a> <img src="images/icons/'+mydata[k].resource_data['resource_type']+'.jpg" width="35" height="35">&nbsp;<a href="resource_details.php?r_id='+mydata[k].resource_data['resource_id']+'" target=_blank>Details</a> <span class="add_to_selection" resource_id="' + mydata[k].resource_data['resource_id'] + '">Add to Selection</span></h3>'+
                                    '<p><a href="author_info.php?a_id='+mydata[k].resource_data['author_id']+'" target=_blank>' +mydata[k].resource_data['author']+'</a>, '+mydata[k].resource_data['size']+', Total Viewed/Downloaded: '+mydata[k].resource_data['total_view']+', Comments:'+mydata[k].resource_data['comments']+'</p>'+
                                    '<p>' +mydata[k].resource_data['sort_description']+ '</p>'+
                                    '<p><a href="'+mydata[k].resource_data['mirror1']+'">Mirror1</a> <a href="'+mydata[k].resource_data['mirror2']+'">Mirror2</a></p></div></div><div class="clear"></div>'
                                    );
                        }
						
            $(document).ready(function(e) {
                    var num_div = $('div.search_container').length;
                    if((num_div%10)>0){
                        var num_page = (num_div/10)+1;
                    }
                    else{
                        var num_page = (num_div/10);
                    }

                    var str = '';
                    for(var k=1; k <= num_page; k++){
                            str += '<a class="pagi" id="'+k+'" show_div="div_'+k+'" href="javascript:void(0);">'+k+'</a>';
                    }
                    $('#pagination').html(str);
                    $('.search_container').hide();
                    for(var k = 0; k < 10; k++){
                            $('#div_'+k).show(); 
                    }
            });
            $(document).on('click','.pagi',function(){
                    var div_id = $(this).attr('show_div');
                    var cur_id =  $(this).attr('id');
                    $('.pagi').css('font-weight','100');
                    $(this).css('font-weight','bold');
                    $('.search_container').hide();
                    for(var k = 0; k < 10; k++){
                            var show_div = ((parseInt(cur_id)*10)-10)+k;
                            $('#div_'+show_div).show(); 
                    }
                    $('#parent').show(500).delay(100).hide(500);
            });	 
						
                    }  
                });
            }
					
        </script>
    </head>
    
    <body>
        <div class="wrapper">
            <div class="header">
                <div class="logo">
                    <a href="<?php echo $home_url; ?>"><img src="images/search.png" /></a>
                </div>
                <div class="title">
                    <img src="images/irc.png" />
                </div>
            </div>
            <div class="clear"></div>
            <div class="container">
            <div class="slider-wrapper">
                   <div id="slider">
                        <?php 
                                $i=1;
                                for($i=1; $i<15; $i++){
                                $filename='images/slider/'.$i.'.jpg';
                                if (file_exists($filename)) { ?>
                                                <div class="slide<?php echo $i; ?>">
                                                        <img height="220px" src="<?php echo $filename; ?>" alt="" />
                                                </div>
                        <?php } }?>
                   </div>
                   <div id="slider-direction-nav"></div>
                   <div id="slider-control-nav"></div>
           </div>

           <script type="text/javascript">
           $(document).ready(function() {
                   var slider = $('#slider').leanSlider({
                           directionNav: '#slider-direction-nav',
                           controlNav: '#slider-control-nav'
                   });
           });
           </script>
                 <div class="top_menu">
                    <ul>
                    <?php	 	
                        while($res_for_rows =  mysql_fetch_row($res_for1)){
                    ?>
                    <li><a href="<?php echo $home_url; ?>?id=<?php echo $res_for_rows[0]; ?>"><?php echo $res_for_rows[1]; ?> (<?php echo $res_for_rows[2]; ?>)</a></li>
                    <?php
                    }
                    ?> 
                    </ul>
                    <div class="clear"></div>
                </div>
                <table>
                    <tr>
                        <td><input type="text" name="" id="search_box" /></td>
                        <td><input type="button" id="search"  value="Search" /></td>
                    </tr>
                </table>

<div style="float:left">
<div id="tab1">
<?php if(isset($_GET['id'])){
    ?>
<script> get_result('','<?php echo $_GET['id']; ?>'); </script>
<?php } else {?>
    <script>
        get_result('','');
    </script>
	<?php } ?>

</div>
<div class="clear"></div>
<div style="float:right; margin-right:40px; margin-top:30px;" id="pagination"></div>
</div>
<div class="category_holder">
	<div class="cat_menu">
		<p style="background:#E7FFC1; font-size:20px; border-radius:5px;">Total <b><?php echo $total_rows; ?> </b>Resources</p>
	</div>
	<div class="cat_menu">
		<p style="background:#E7FFC1; font-size:20px; border-radius:5px;">My Selection (<span id="selection" style=" cursor: pointer; color:blue;">0</span>)</p>
		<p style="display:none" id="item_id"></p>
	</div>
	<div class="cat_menu">
		<p style="background:#E7FFC1; font-size:22px; border-radius:5px;"><a style="text-decoration:none;" href="quran.php">কোরআন শিক্ষা</a></p>
		<p style="display:none" id="item_id"></p>
	</div>
		<div class="cat_menu">
		<p style="background:#E7FFC1; font-size:20px; border-radius:5px;"><a style="text-decoration:none;" href="event.php">Upcoming Events</a></p>
		<p style="display:none" id="item_id"></p>
	</div>
	
	
	<div class="cat_menu" style="text-align: center;">
		<p><b>Salat Timing</b></p><div style="margin-top: 25px;">
<iframe src="http://www.islamicfinder.org/prayer_service.php?country=bangladesh&city=dhaka&state=81&zipcode=&latitude=23.7231&longitude=90.4086&timezone=6&HanfiShafi=1&pmethod=1&fajrTwilight1=10&fajrTwilight2=10&ishaTwilight=10&ishaInterval=30&dhuhrInterval=1&maghribInterval=1&dayLight=0&page_background=&table_background=&table_lines=&text_color=&link_color=&prayerFajr=&prayerSunrise=&prayerDhuhr=&prayerAsr=&prayerMaghrib=&prayerIsha=&lang=" frameborder=0 width=175 height=280 marginwidth=0 marginheight=0 scrolling="no"> </iframe>
	</div></div>
	
	
	<div class="cat_menu">
		<p><b>Category Menu</b></p>
		<ul>
	<?php	
		 while($row1 =  mysql_fetch_row($res_cat_rows)){
			?>
		<li style="border-bottom: 1px solid #aaa; margin-bottom:5px; padding-bottom:5px;"><a class="tab_menu category" href="javascript:void(0)" cat_id="<?php echo $row1[2]; ?>">&raquo; <?php echo $row1[0].'('.$row1[1].')';?> </a></li>
			<?php
		  }
		?>
		</ul>
	</div>
	<div class="cat_menu">
		<p><b>Select by Author (<?php echo $num_authors; ?>)</b></p>
		<ul>
		<?php	
		 while($row_author =  mysql_fetch_row($res_author1)){
		?>
			<li style="border-bottom: 1px solid #aaa; margin-bottom:5px; padding-bottom:5px;"><a class="tab_menu author" href="javascript:void(0)" auth_id="<?php echo $row_author[1];?> "><?php echo $row_author[2];?> (<?php echo $row_author[0];?>)</a></li>
		<?php
		  }
		?>
		</ul>
		<p><a href="author_list.php" target=_blank>অন্যান্য লেখক</a></p>
	</div>
</div>


<div class="clear"></div>

            </div>
        </div>
        <div id="parent">
        	<div id="shadow"></div>
            <div id="loading_panel"><img src="images/723.GIF"/></div>
        </div>
    </body>
</html>
<script>
	$(document).on('click','.add_to_selection',function(){
        var item_id = $(this).attr('resource_id');
		$(this).removeAttr('resource_id')
		item_count = parseInt($('#selection').text());
		item_count++;
		$('#selection').text(item_count);
		$('#item_id').append(item_id+',');
    });
	$(document).on('click','#selection',function(){
		var all_id = $('#item_id').text();
		var url = 'item_list.php';
		var form = $('<form action="' + url + '" method="post">' +
		  '<input type="text" name="id_array" value="' + all_id + '" />' +
		  '</form>');
		$('body').append(form);
		$(form).submit();
	});
   
	$(document).on('click','.author',function(){
        var auth_id = $(this).attr('auth_id');
		//alert(auth_id);
        $('.search_container').css('display','none');
        $('.auth'+auth_id).css('display','block');
    });
	
	 $(document).on('click','.category',function(){
        var cat_id = $(this).attr('cat_id');
		//alert(cat_id);
        $('.search_container').css('display','none');
        $('.category'+cat_id).css('display','block');
    });
	
	
    $(function() {
    $( "#search_box" ).autocomplete({
      source: 'search.php',
	focus: function( event, ui ) {
        $( "#search_box" ).val( ui.item.name );
        return false;
      },
	  search  : function(){$(this).addClass('working');},
	  open: function(){$(this).removeClass('working');},
	  select: function( event, ui ) {
        $( "#search_box" ).val( ui.item.name );
        get_result(ui.item.name,'');
        return false;
      }
    }).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
      return $( "<li>" )
        .append( "<a>" + item.name + "</a>" )
        .appendTo( ul );
    };
  });
function resetTabs(){
    $("#content > div").hide(); //Hide all content
    $("#tabs a").attr("id",""); //Reset id's      
}

var myUrl = window.location.href; //get URL
var myUrlTab = myUrl.substring(myUrl.indexOf("#")); // For mywebsite.com/tabs.html#tab2, myUrlTab = #tab2     
var myUrlTabName = myUrlTab.substring(0,4); // For the above example, myUrlTabName = #tab

(function(){
    $("#content > div").hide(); // Initially hide all content
    $("#tabs li:first a").attr("id","current"); // Activate first tab
    $("#content > div:first").fadeIn(); // Show first tab content
    
    $("#tabs a").on("click",function(e) {
        e.preventDefault();
        if ($(this).attr("id") == "current"){ //detection for current tab
         return       
        }
        else{             
        resetTabs();
        $(this).attr("id","current"); // Activate this
        $($(this).attr('name')).fadeIn(); // Show content for current tab
        }
    });

    for (i = 1; i <= $("#tabs li").length; i++) {
      if (myUrlTab == myUrlTabName + i) {
          resetTabs();
          $("a[name='"+myUrlTab+"']").attr("id","current"); // Activate url tab
          $(myUrlTab).fadeIn(); // Show url tab content        
      }
    }
})()

$('#search').click(function(){
    $('#tab4').show();
    $('#li_tab').show();
   var name =  $('#search_box').val();
   get_result(name);
});


$(window).load(function() {
    $("#flexiselDemo1").flexisel();
    $(".pp").flexisel();
    });
</script>
 