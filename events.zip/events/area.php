<?php
include('conn/db_connect.php');

$id = $_POST['city_id1'];
$dt1 = "<option value=''>Select</option>";
$q =  mysql_query("SELECT * from irc_area WHERE city_id='$id'") ;

while($ar = mysql_fetch_assoc($q)){ 
    $dt1 .= '<option value="'.$ar['area_id'].'">'.$ar["area_name"].'</option>';
    
}
echo $dt1;

?>