<?php 
include('conn/db_connect.php'); 

if($_POST){
$title=mysql_real_escape_string($_POST['eventtitle']);
$subject=mysql_real_escape_string($_POST['subject']);
$place=mysql_real_escape_string($_POST['place']);
$duration=mysql_real_escape_string($_POST['duration']);
$eventdate=mysql_real_escape_string($_POST['eventdate']);
$eventtime=mysql_real_escape_string($_POST['eventtime']);
$speaker=mysql_real_escape_string($_POST['speaker']);
$introduction=mysql_real_escape_string($_POST['introduction']);
$organized=mysql_real_escape_string($_POST['organized']);

$nam=mysql_real_escape_string($_POST['nam']);
$phone=mysql_real_escape_string($_POST['phone']);
$mail=mysql_real_escape_string($_POST['mail']);
$address=mysql_real_escape_string($_POST['address']);


		mysql_query("set names 'utf8'");
        $sql = "INSERT INTO
                irc_event 
            SET
                event_title = '$title',
				speaker = '$speaker',
				event_place = '$place',
				subject = '$subject',
				duration = '$duration',
				event_date = '$eventdate',
				event_time = '$eventtime',
				introduction = '$introduction',
				organized_by = '$organized',
                                uploader = '$nam',
                                up_phone = '$phone',
                                up_mail = '$mail',
                                up_address = '$address'";
				
        mysql_query($sql);
}
header('location: http://resource.ircbd.org/event.php');
?>