<?php include('conn/db_connect.php'); ?>

<?php
mysql_query("set names 'utf8'");
  $sql = "SELECT
            resource_id,
            resources.resource_title,
            resources.main_source as link,
            resources.resource_code,
            resources.size_info,
            resources.img_location,
            resources.author_id,
            resource_type.resource_type,
            author_info.author_photo,
            resources.total_view,
            resources.total_comments,
            resources.sort_description,
            resources.resource_category,
            resources.mirror1,
            resources.mirror2,
            author_info.author_name            
        FROM resources
                LEFT JOIN author_info ON resources.author_id = author_info.author_id
		LEFT JOIN resource_type ON resources.resource_type = resource_type.resource_type_id
        WHERE search_text LIKE '%".$_POST['name']."%' 
		AND _show=1";
$resource_for = $_POST['type'];
$resource_for == ''?'':$sql .=" AND resource_for='".$resource_for."'";


$query = mysql_query($sql." ORDER BY resources._sort");

$number_of_result = 0;
while($row = mysql_fetch_array($query)){
        $number_of_result++;
	$item[]['resource_data'] = array('title'=>$row['resource_title'],
                                        'resource_id'=>$row['resource_id'],
                                        'link'=>$row['link'],
                                        'code'=>$row['resource_code'],
                                        'size'=>$row['size_info'],
                                        'author'=>$row['author_name'],
                                        'author_id'=>$row['author_id'],
                                        'resource_type'=>$row['resource_type'],
                                        'resource_image'=>$row['img_location'],
                                        'total_view'=>$row['total_view'],
                                        'comments'=>$row['total_comments'],
                                        'resource_category'=>$row['resource_category'],
                                        'mirror1'=>$row['mirror1'],
                                        'mirror2'=>$row['mirror2'],
                                        'sort_description'=>$row['sort_description'],
                                        'author_photo'=>$row['author_photo']);
        //$item[]['main_source'] = $row['main_source'];
}

echo (json_encode($item));
?>