<?php include('conn/db_connect.php'); ?>
<?php include('quiries.php');?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <!-- base href="/" --><!--[if IE]></base><![endif]-->
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="description" content="Search panel designed by Apsis Solutions." />
        <title>Custom Search</title>

        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />

        <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/jquery.flexisel.js"></script>
        <style>
            .inp_cls11{
                font-size: 18px;
                border-radius: 4px;
                padding: 3px 2px;
                width: 450px;
                border: 1px solid #ccc;    
            }
        </style>
        
    </head>
<?php
if(!empty($_POST['id_array'])){
    $resource_list = substr($_POST['id_array'],0,-1);
    mysql_query("UPDATE resources SET total_view=total_view+1 WHERE resource_id IN (".$resource_list.")");
    $sql = "SELECT * FROM resources JOIN author_info ON resources.author_id = author_info.author_id WHERE resource_id IN (".$resource_list.")";
    $run_query = mysql_query($sql);
}
?>
    
    <body>
        <div class="wrapper">
            <div class="header">
                <div class="logo">
                    <a href="<?php echo $home_url; ?>"><img src="images/search.png" /></a>
                </div>
                <div class="title">
                    <img src="images/irc.png" />
                </div>
            </div>
            <div class="clear"></div>
            <div class="container">
                 <div class="top_menu">
                    <ul>
                    <?php	 	
                        while($res_for_rows =  mysql_fetch_row($res_for1)){
                    ?>
                    <li><a href="<?php echo $home_url; ?>?id=<?php echo $res_for_rows[0]; ?>"><?php echo $res_for_rows[1]; ?> (<?php echo $res_for_rows[2]; ?>)</a></li>
                    <?php
                    }
                    ?> 
                    </ul>
                    <div class="clear"></div>
                </div>
                <table>
                    <tr>
                        <td><input type="text" name="" id="search_box" /></td>
                        <td><input type="button" id="search"  value="Search" /></td>
                    </tr>
                </table>
<form action="" method="post">
 <?php
 if(!empty($run_query)){
 while($row = mysql_fetch_array($run_query))
 {  ?>
<!------------------------------------------------------------------------------>
        <script>
            function get_result(name,type){
                $.ajax({
                    url:'find_result.php',
                    type:'POST',
                    data:{name:name,type:type},
                    success:function(data){
                        //alert(data);
                        $('#tab1').html('');
                        mydata = $.parseJSON(data);
                        var total_result = mydata.length;
                        $('#tab1').html('<p style="font-size:10px;color:#ccc;">Total Result Found - '+total_result+'</p>');
                        
                      // $('#tab1').append('<fieldset> <legend>Category:</legend>');//'+mydata[k].resource_data['resource_type']+'
                        
                        for(var k in mydata){
                            $('#tab1').append('<div id="div_'+k+'" class="search_container category' + mydata[k].resource_data['resource_category'] + ' auth' + mydata[k].resource_data['author_id'] + '"><div class="search_image"><img height="60" width="60" src="' + mydata[k].resource_data['resource_image'] + '" /></div>'+
                                    '<div class="search_details"><h3 style="padding:5px;"> <a href="' + mydata[k].resource_data['link'] + '" target=_blank>'+mydata[k].resource_data['title']+' ('+mydata[k].resource_data['code']+')</a> <img src="images/icons/'+mydata[k].resource_data['resource_type']+'" width="35" height="35">&nbsp;<a href="resource_details.php?r_id='+mydata[k].resource_data['resource_id']+'" target=_blank>Details</a> <span class="add_to_selection" resource_id="' + mydata[k].resource_data['resource_id'] + '">Add to Selection</span></h3>'+
                                    '<p><a href="author_info.php?a_id='+mydata[k].resource_data['author_id']+'" target=_blank>' +mydata[k].resource_data['author']+'</a>, '+mydata[k].resource_data['size']+', Total Viewed/Downloaded: '+mydata[k].resource_data['total_view']+', Comments:<a href=resource_details.php target=_blank> '+mydata[k].resource_data['comments']+'</a></p>'+
                                    '<p>' +mydata[k].resource_data['sort_description']+ '</p>'+
                                    '<p><a href="'+mydata[k].resource_data['mirror1']+'">Mirror1</a> <a href="'+mydata[k].resource_data['mirror2']+'">Mirror2</a></p></div></div><div class="clear"></div>'
                                    );
                        }
						
            $(document).ready(function(e) {
                    var num_div = $('div.search_container').length;
                    if((num_div%10)>0){
                        var num_page = (num_div/10)+1;
                    }
                    else{
                        var num_page = (num_div/10);
                    }

                    var str = '';
                    for(var k=1; k <= num_page; k++){
                            str += '<a class="pagi" id="'+k+'" show_div="div_'+k+'" href="javascript:void(0);">'+k+'</a>';
                    }
                    $('#pagination').html(str);
                    $('.search_container').hide();
                    for(var k = 0; k < 10; k++){
                            $('#div_'+k).show(); 
                    }
            });
            $(document).on('click','.pagi',function(){
                    var div_id = $(this).attr('show_div');
                    var cur_id =  $(this).attr('id');
                    $('.pagi').css('font-weight','100');
                    $(this).css('font-weight','bold');
                    $('.search_container').hide();
                    for(var k = 0; k < 10; k++){
                            var show_div = ((parseInt(cur_id)*10)-10)+k;
                            $('#div_'+show_div).show(); 
                    }
                    $('#parent').show(500).delay(100).hide(500);
            });	 
						
                    }  
                });
            }
					
        </script>
<!------------------------------------------------------------------------------>
            
                <div class="squaredTwo">
                    <input type="checkbox" value="<?php echo $row['resource_id']; ?>" class="squaredTwo" id="<?php echo $row['resource_id']; ?>" name="selection[]"/>
                    <label for="<?php echo $row['resource_id']; ?>"></label>
                </div>
                <div class="search_image"><img height="60" width="60" src="<?php echo $row['img_location']; ?>" /></div>

                <div class="">
                    <h3 style="padding:5px;">
                        <a href="resource_details.php?r_id=<?php echo $row['resource_id']; ?>" target=_blank><?php echo $row['resource_title']; ?></a>
                    </h3>
                    <p><a href="author_info.php?a_id=<?php echo $row['author_id']; ?>" target=_blank><?php echo $row['author_name']; ?></a>
                        &nbsp;<?php echo $row['size_info']; ?>,&nbsp;Total Viewed: <?php echo $row['total_view']; ?>,&nbsp;Total Comments: <?php echo $row['total_comments']; ?></p>
                    <p>&nbsp;</p>
                    <p><?php echo $row['sort_description']; ?></p>
                    <p><a href="<?php echo $row['mirror1']; ?>">Mirror1</a>&nbsp;<a href="<?php echo $row['mirror2']; ?>">Mirror2</a></p>
                </div>
                <br>
        <div class="clear"></div>
    
 <?php } ?>
    <br/>
    <h3>Get a Copy from:</h3><br>
        <table style="padding:10px; align:left; width: 100%;">
            <tr>        
                <td style="width:15%"><label for="">Content Through: </label></td><td>
                    <select class="inp_cls" name="cont_thr" style="width:100%">
                <option value="">Select</option>
                <option value="cd">CD/DVD copy</option>
                <option value="pendrive">USB Portable Device</option>
                <option value="memory">SD/Micro SD Memory Chip</option>
                <option value="print">Printed Copy</option>
            </select></td>
            </tr>
            <tr><td>
            <label for="">Delivery By: </label></td>
                <td>
                <select class="inp_cls" name="delivery" id="delivery" style="width:100%">
                    <option value="">Select</option>
                    <option value="courier">Courier Service</option>
                    <option value="self">Self Service</option>
                </select>
                </td>
            </tr>
            <tr id="area"></tr>
            <tr>
            <td><label for="">Name: </label></td><td><input type="text" name="get_name" value="" style="width:100%" required="true"></td>
            </tr>
            <tr>
                <td><label for="">Contact No.: </label></td><td><input style="width:100%" type="text" name="get_cont" value="" required="true"></td>
            </tr>
            <tr>
                <td><label for="">Email Id: </label></td><td><input style="width:100%" type="text" name="get_email" value="" required="true"></td>
            </tr>
            <tr>
            <td><label for="">Contact Address: </label></td><td><input style="width:100%" type="text" name="get_add" value=""  required="true"></td>
            </tr>
            <tr>
                <td><label for="">Any Instruction: </label></td><td><textarea style="width:100%" rows="5" name="get_instruction" value=""></textarea></td>
            </tr>
            <tr>
            <td><input type="submit" value="confirm" name="confirm"></td><td></td>
            </tr>
        </table>
 <?php } ?>
</form>
<script>
$(function() {
    $("#delivery").change(function(){
        //alert("Your book is overdue.");
        var curier = $('#delivery option:selected').val();
        //alert(id);
        $.ajax({
            url: 'search_curier.php',
            data: {curier_name:curier},
            type: 'post',
            success: function(data){
                $('#area').html(data);
            }
        });
    });
});
</script>            
<?php
if(!empty($_POST['confirm'])){
    $select=$_POST['selection'];
    $email=$_POST['get_email'];
    $content_thr=$_POST['cont_thr'];
    $delivery=$_POST['delivery'];
    $courierarea=$_POST['curier_area'];
    $name=$_POST['get_name'];
    $phone=$_POST['get_cont'];
    $address=$_POST['get_add'];
    $instruction=$_POST['get_instruction'];
    
    $message='Contents:<br/>';
    foreach ($select as $selection){
        mysql_query("set names 'utf8'");
            $que="SELECT * FROM resources WHERE resource_id=$selection";
        $resource=  mysql_query($que);
        while ($resc = mysql_fetch_assoc($resource)){
           $info1=$resc['resource_title'];
        }
        $message.='(#) ';
        $message.= $info1;
        $message.='<br>';
    }
    
    $message.='<br><br>Name: <b>'.$name.'</b><br>';
    $message.='Phone: '.$phone.'<br>';
    $message.='Address: '.$address.'.<br><br>';
    $message.='By Content delivery Through: '.$content_thr.'<br>';
    $message.='Delivery Place/Location: '.$delivery.'<br>';
    $message.='Qurier Location (if exists): '.$courierarea.'<br>';
    $message.='<br>Instruction: '.$instruction.'<br>';

    $subject="IRC Content Order";
    echo $message;
    mail("nijhu.tulip@gmail.com",$subject,$message);
    mail($email,$subject,$message);
    
    echo '<br>A Mail Has been submitted to the admin and you too for the varification of your order.';
}

?>               
<div class="clear"></div>

            </div>
        </div>
    </body>
</html>
<script>
	$(document).on('click','.author',function(){
        var auth_id = $(this).attr('auth_id');
		//alert(auth_id);
        $('.search_container').css('display','none');
        $('.auth'+auth_id).css('display','block');
    });
	
	 $(document).on('click','.category',function(){
        var cat_id = $(this).attr('cat_id');
		//alert(cat_id);
        $('.search_container').css('display','none');
        $('.category'+cat_id).css('display','block');
    });
	
	
    $(function() {
    $( "#search_box" ).autocomplete({
      source: 'search.php',
	focus: function( event, ui ) {
        $( "#search_box" ).val( ui.item.name );
        return false;
      },
	  search  : function(){$(this).addClass('working');},
	  open: function(){$(this).removeClass('working');},
	  select: function( event, ui ) {
        $( "#search_box" ).val( ui.item.name );
        get_result(ui.item.name,'');
        return false;
      }
    }).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
      return $( "<li>" )
        .append( "<a>" + item.name + "</a>" )
        .appendTo( ul );
    };
  });
function resetTabs(){
    $("#content > div").hide(); //Hide all content
    $("#tabs a").attr("id",""); //Reset id's      
}

var myUrl = window.location.href; //get URL
var myUrlTab = myUrl.substring(myUrl.indexOf("#")); // For mywebsite.com/tabs.html#tab2, myUrlTab = #tab2     
var myUrlTabName = myUrlTab.substring(0,4); // For the above example, myUrlTabName = #tab

(function(){
    $("#content > div").hide(); // Initially hide all content
    $("#tabs li:first a").attr("id","current"); // Activate first tab
    $("#content > div:first").fadeIn(); // Show first tab content
    
    $("#tabs a").on("click",function(e) {
        e.preventDefault();
        if ($(this).attr("id") == "current"){ //detection for current tab
         return       
        }
        else{             
        resetTabs();
        $(this).attr("id","current"); // Activate this
        $($(this).attr('name')).fadeIn(); // Show content for current tab
        }
    });

    for (i = 1; i <= $("#tabs li").length; i++) {
      if (myUrlTab == myUrlTabName + i) {
          resetTabs();
          $("a[name='"+myUrlTab+"']").attr("id","current"); // Activate url tab
          $(myUrlTab).fadeIn(); // Show url tab content        
      }
    }
})()

$('#search').click(function(){
    $('#tab4').show();
    $('#li_tab').show();
   var name =  $('#search_box').val();
   get_result(name);
});


$(window).load(function() {
    $("#flexiselDemo1").flexisel();
    $(".pp").flexisel();
    });
</script>
