<?php include('conn/db_connect.php'); ?>
<?php include('quiries.php');?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="description" content="Search panel designed by Apsis Solutions." />
        <title>Custom Search</title>
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
        <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/jquery.flexisel.js"></script>
        <style type="text/css">
        .submit{
            font-size: 18px;
            font-weight: bold;
            border-radius: 4px;
            padding: 3px 20px;
            border: 1px solid #ccc;
        }
        .button:hover{
          background:#ddd;
        }
        .dialog{
          border:0px solid #666;
          padding:30px;
          background: #fff;
          position:absolute;
          display:none;
        }
        .dialog label{
          display:inline-block;
          color:#cecece;
        }
        </style>

        <script>
            function get_result(name){
                $.ajax({
                    url:'find_result.php',
                    type:'POST',
                    data:{name:name},
                    success:function(data){
                        //alert(data);
                        $('#tab1').html('');
                        mydata = $.parseJSON(data);
                        var total_result = mydata.length;
                        $('#tab1').html('<p style="font-size:10px;color:#ccc;">Total Result Found - '+total_result+'</p>');
                    }
                });
            }
        </script>

    </head> 
    
    <body>  
        <div class="wrapper">
            <div class="header">
                <div class="logo">
                    <a href="http://resource.ircbd.org/"><img src="images/search.png" /></a>
                </div>
                <div class="title">
                    <img src="images/irc.png" />
                </div>
            </div>
            <div class="clear"></div>
            <div class="container">
                 <div class="top_menu">
                    <ul>
                    <?php	 	
                        while($res_for_rows =  mysql_fetch_row($res_for1)){
                    ?>
                    <li><a href="<?php echo $home_url; ?>?id=<?php echo $res_for_rows[0]; ?>"><?php echo $res_for_rows[1]; ?> (<?php echo $res_for_rows[2]; ?>)</a></li>
                    <?php
                    }
                    ?> 
                    </ul>
                    <div class="clear"></div>
                </div>
                 <br />  
                      <br />
<script type="text/javascript">
    $(document).ready(function(){
       $(".parent").hide(); 
    });
            function codeBinsAddEvent(obj,type,fn){
                if(obj.attachEvent){
                        if(type == "load"){
                            obj.attachEvent('on'+type, fn);
                        }
                        else{
                            obj.attachEvent('onreadystatechange', fn);
                        }
                 }
                else obj.addEventListener(type,fn,false)
            };
            function codeBinsAddLoadEvent(fn){
                codeBinsAddEvent(document.addEventListener&&!window.addEventListener?document:window,'load',fn)
            };
            function codeBinsAddReadyEvent(fn){
                codeBinsAddEvent(document,'DOMContentLoaded',fn)
            };

            $(function() {
    $(".button").click(function() {
        var com_id = $(this).attr('id');
        $(".parent #valueFromMyButton").val(com_id);
        $(".parent input[type=text]").val('');
        $("#valueFromMyModal").val('');
        $('#reply'+com_id).show(500);

    });
    $(".btnOK").click(function() {
        $("#valueFromMyModal").val($(".parent input[type=text]").val().trim());
        $(".parent").hide(400);
    });
     $(".btnclose").click(function() {
        $(".parent").hide(400);
    });
});               
</script> 

              
          <?php 
            $r_id=$_GET['r_id'];
			mysql_query("set names 'utf8'");
            $resource = mysql_query("SELECT * FROM resources 
                    JOIN author_info ON resources.author_id = author_info.author_id
                    WHERE resource_id='$r_id'", $db_con);
            while($rsc=mysql_fetch_assoc($resource)){
         ?>                 
 
<div align="center">
  <center>
  <table border="0" cellpadding="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#111111" width="70%">
    <tr>
      <td width=""><img style="float: left; margin-right: 10px;" border="0" src="<?php echo $rsc['img_location'];?>" width="306" height="231">
          <b><?php echo $rsc['resource_title'];?></b><br/><br/>
      <?php echo $rsc['author_name'];?></td>
    </tr>
<tr><td><?php echo $rsc['sort_description'];?></td></tr>
    
 <?php }?> 
        
    <tr>
      <td width="150%" colspan="3"></td>
    </tr>
    <tr>
      <td width="150%" colspan="3">
      <table border="0" cellpadding="4" cellspacing="4" style="border-collapse: collapse" bordercolor="#111111" width="100%" height="71">
         <?php 
            mysql_query("set names 'utf8'");
            $result = mysql_query("SELECT * FROM comments WHERE resource_id='$r_id' AND parent_id=0");
            $num_rows = mysql_num_rows($result);     
         ?>
        <tr>
          <td width="100%" height="29" colspan="2">
            <b><font size="6"><?php echo $num_rows.' Comments'; ?></font></b>
          </td>
        </tr>
        <tr>
          <td width="17%" height="19">&nbsp;</td>
        </tr>
        <?php while($comm=mysql_fetch_assoc($result)){ ?>
        <tr>
          <td width="17%" height="19" bgcolor="#C0C0C0">
              <?php
              $old_date=$comm['com_date'];
              $new_date = date('j F Y', strtotime($old_date));
              ?>
              <?php echo $comm['com_name'].', '.$comm['address'];?><br> <span class="comment_date"><?php echo $new_date;?></span>
              <input type="button" class="button" value="Reply" id="<?php echo $comm['comment_id'];?>" style="float:right;" />
          </td>
        </tr>
        <tr>
          <td width="17%" height="19"><?php echo $comm['comments'];?>
          </td>
        </tr>
        <tr>
          <td width="17%" height="19">
              <div id="reply<?php echo $comm['comment_id'];?>" style="width:550px; float: right;" class="parent">
     <div id="shadow"></div>
     <form action="" method="post"><table>
      <input type="hidden" id="valueFromMyButton" name="valueFromMyButton" value="<?php echo $comm['comment_id'];?>"/>
      <tr><td><span style="float:left; line-height: 30px;">Name:</span></td><td><input style="float:right;" type="text" name="com_name" size="20"/></td></tr>
      <tr><td><span style="float:left; line-height: 30px;">Address: </span></td><td><input style="float:right;" type="text" name="address" size="20"/></td></tr>
      <tr><td><span style="float:left; line-height: 30px;">Phone: </span></td><td><input style="float:right;" type="text" name="phone" size="20"/></td></tr>
      <tr><td><span style="float:left; line-height: 30px;">Email: </span></td><td><input style="float:right;" type="text" name="email" size="20"/></td></tr>
      <tr><td><span style="float:left; line-height: 30px;">Comment: </span></td><td><textarea style="float:right;" rows="3" name="comment" cols="20"></textarea></td></tr>
      <tr><td></td><td><input style="font-size: 18px;font-weight: bold;border-radius: 4px;padding: 3px 20px;border: 1px solid #ccc;"type="submit" value="Ok" class="btnOK">&nbsp;&nbsp;<input type="button" value="Close" class="btnclose"></td></tr>
         </table></form>
  </div></td>
        </tr>
         <?php 
            $comment_id = $comm['comment_id'];
            mysql_query("set names 'utf8'");
            $sub_com = mysql_query("SELECT * FROM comments WHERE parent_id='$comment_id'", $db_con);
            while($sub=mysql_fetch_assoc($sub_com)){
              $old_date1=$sub['com_date'];
              $new_date1 = date('j F Y', strtotime($old_date1));
                ?>
          
          
        <tr>
            <td style="padding-left: 50px;" width="" height="19" bgcolor="#e0e0e0">&#10155;&nbsp;&nbsp;<?php echo $sub['com_name'].', '.$sub['address'];?><br> <span class="comment_date"><?php echo $new_date1;?></span></td>
        </tr>
        <tr>
          <td style="padding-left: 50px;" width="17%" height="19"><?php echo $sub['comments'];?></td>
        </tr> 
        <tr>
          <td width="17%" height="19">&nbsp;</td>
        </tr>
        <?php } }?>
        
        <?php 
    if($_POST){
       if(!empty($_POST['valueFromMyButton'])){
             $subcom=$_POST['valueFromMyButton'];
             $com_name = mysql_real_escape_string($_POST['com_name']);
             $address=mysql_real_escape_string($_POST['address']);
             $phone=mysql_real_escape_string($_POST['phone']);
             $email=$_POST['email'];
             $comment=mysql_real_escape_string($_POST['comment']);
             $date=date('y-m-d');
        mysql_query("set names 'utf8'");
        $sql = "INSERT INTO
                comments 
            SET
                com_name = '$com_name',
                resource_id = '$r_id',
                address = '$address',
                phone = '$phone',
                email = '$email',
                comments = '$comment',
                parent_id = '$subcom',
                com_date = '$date'";
				
            mysql_query($sql);
      
            $update = mysql_query("UPDATE resources SET total_comments='$num_rows' WHERE resource_id='$r_id'");
            echo '<script>location.replace("resource_details.php?r_id='.$r_id.'");</script>';
                    }
             else {
             $com_name = mysql_real_escape_string($_POST['com_name']);
             $address=mysql_real_escape_string($_POST['address']);
             $phone=mysql_real_escape_string($_POST['phone']);
             $email=$_POST['email'];
             $comment=mysql_real_escape_string($_POST['comment']);
             $date=date('y-m-d');
            mysql_query("set names 'utf8'");
            $sql = "INSERT INTO
                comments 
            SET
                com_name = '$com_name',
                resource_id = '$r_id',
                address = '$address',
                phone = '$phone',
                email = '$email',
                comments = '$comment',
                com_date = '$date'";
				
            mysql_query($sql);
            $q = mysql_query("UPDATE resources SET total_comments=(SELECT COUNT(*) FROM comments WHERE resource_id='$r_id') WHERE resource_id='$r_id'");
            if(!$q)
                echo mysql_error();
            else
            echo '<script>location.replace("resource_details.php?r_id='.$r_id.'");</script>';  
            }
                }
        //header("Location: resource_details.php");
        
        ?>
       <tr>
      <td width="150%" colspan="3">
          <form action="" method="POST">
      <table border="0" cellpadding="4" cellspacing="4" style="border-collapse: collapse" bordercolor="#111111" width="100%">
        <tr>
          <td width="50%">&nbsp;</td>
          <td width="50%">&nbsp;</td>
        </tr>
        <tr>
          <td colspan="2"><font size="6">Write your comments:</font></td>
         
            </tr>
            <tr>
              <td width="50%">Name:</td>
              <td width="50%"><input type="text" name="com_name" size="20"></td>
            </tr>
            <tr>
              <td width="50%">Address:</td>
              <td width="50%"><input type="text" name="address" size="20"></td>
            </tr>
            <tr>
              <td width="50%">Phone:</td>
              <td width="50%"><input type="text" name="phone" size="20"></td>
            </tr>
            <tr>
              <td width="50%">Email:</td>
              <td width="50%"><input type="text" name="email" size="20"></td>
            </tr>
            <tr>
              <td width="50%">Comments:</td>
              <td width="50%"><textarea rows="3" name="comment" cols="20"></textarea></td>
            </tr>
            <tr>
              <td width="50%"><input style="padding: 5px;" type="submit" value="Submit" name="B1">&nbsp;<input style="padding: 5px;" type="reset" value="Reset" name="B2"></td>
              <td width="50%">&nbsp;</td>
            </tr>
          </table>
          </form>
          </td>
        </tr>
      </table> 
      </td>
    </tr>
  </table>
  </center>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p> 


<div class="clear"></div>
            </div>
        </div>
    </body>
</html>
<script>
    $(document).on('click','.tab_menu',function(){
        var cat_id = $(this).attr('cat_id');
        $('.search_container').css('display','none');
        $('.cat'+cat_id).css('display','block');
    });
  
function resetTabs(){
    $("#content > div").hide(); //Hide all content
    $("#tabs a").attr("id",""); //Reset id's      
}

var myUrl = window.location.href; //get URL
var myUrlTab = myUrl.substring(myUrl.indexOf("#")); // For mywebsite.com/tabs.html#tab2, myUrlTab = #tab2     
var myUrlTabName = myUrlTab.substring(0,4); // For the above example, myUrlTabName = #tab

(function(){
    $("#content > div").hide(); // Initially hide all content
    $("#tabs li:first a").attr("id","current"); // Activate first tab
    $("#content > div:first").fadeIn(); // Show first tab content
    
    $("#tabs a").on("click",function(e) {
        e.preventDefault();
        if ($(this).attr("id") == "current"){ //detection for current tab
         return       
        }
        else{             
        resetTabs();
        $(this).attr("id","current"); // Activate this
        $($(this).attr('name')).fadeIn(); // Show content for current tab
        }
    });

    for (i = 1; i <= $("#tabs li").length; i++) {
      if (myUrlTab == myUrlTabName + i) {
          resetTabs();
          $("a[name='"+myUrlTab+"']").attr("id","current"); // Activate url tab
          $(myUrlTab).fadeIn(); // Show url tab content        
      }
    }
})()

$('#search').click(function(){
    $('#tab4').show();
    $('#li_tab').show();
    //$('#tabs').prepend('<li><a href="#" name="#tab4">Search Result</a></li>');
    //$('#content').prepend('<div id="tab4">Resulter</div>');
   var name =  $('#search_box').val();
   get_result(name);
});

$(window).load(function() {
    $("#flexiselDemo1").flexisel();
    $(".pp").flexisel();
    });
</script>
 