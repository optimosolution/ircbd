<?php
	include('include.php');
?>  

<head>
<title>ICS System Solutions - <?php etr("Return sales order") ?></title>
<?php
styleSheet();
include_common();
?>
<script>
function submitForm()
{
	document.postform.submit();
}
</script>
</head>

<body onLoad="onLoad()">
<?php
menubar('index.php');
title("<a href='sales.php'>" . tr("Sales orders") . "</a> > $orderid") ;
?>

<?php
if ($mess != null) {
	echo "<center class=error>$mess</center>";
}
?>

<form name=postform action="return_salesorder.php" method="POST">
<input type=hidden name=customerid value='4'/>
<table>
<?php
	echo "<tr><td><b>" . tr("Order id") . ":</b></td>";
	echo "<td>";
	echo "<input type='text' name='return_orgid'/>";
	echo "</td>";
		echo "<td>";
	echo "<input type='submit' name='Submit' value='Submit'/>";
	echo "</td>";
?>
</tr>
</table>
 
</form>
<?php bottom() ?>
</body>
