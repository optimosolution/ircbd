<?php
	include('include.php');
	include('salesorder.inc.php');

  $customerid = getParam('customerid');
  $unpaid = getParam('unpaid');
	$overdue = getParam('overdue');
	$uninvoiced = getParam('uninvoiced');
	$productid = getParam('productid');
	$credit_orgid = getParam('credit_orgid');
	$displayname= getParam('displayname');

	$starttime = parseDate(getParam('starttime'));
	if (isEmpty($starttime))
		$starttime = roundTime(time(), TYPE_MONTHS);
	$endtime = parseDate(getParam('endtime'));
	if (isEmpty($endtime))
		$endtime = addTime($starttime, TYPE_MONTHS);
		
	$del_orderid = getParam("del_orderid");
	if (!isEmpty($del_orderid)) {
		cancel_order($del_orderid);
	}

 

	$sql = "
	select 
    	so.orderid,
    	so.no,
    	unix_timestamp(orderdate) as orderdate,
    	companyname as companyname,
    	displayname,
    	streetaddress as address,	    
    	invoice_transid,
    	line_amt as total,
    	(line_amt - other_adjustment) as pay_amt,
    	sum(pa.amount) as allocated,
    	rso.orderid as recur,
    	credit_orgid
	from (salesorder so
	inner join (select si.orderid,
	  sum(quantity*unitprice * (1+vat/100-discountprice/100) -
	  if(other_disc<>0, other_disc, quantity*unitprice * discount/100)
	  ) as line_amt
	  from salesorder_item si
	  inner join salesorder so on si.orderid=so.orderid
	  group by si.orderid) as si on so.orderid=si.orderid)
	left join customer c on c.customerid=so.customerid
	left join receipt_allocation pa on pa.orderid=so.orderid
	left join recur_salesorder rso on rso.orderid=so.orderid
	where so.customerid like '$customerid%'
	and orderdate between from_unixtime($starttime) and from_unixtime($endtime)
	and cancelled=0
	";



	if ($unpaid)
		$sql .= " and invoice_transid is not null ";
	if ($uninvoiced)
		$sql .= " and invoice_transid is null ";
	if ($overdue)
		$sql .= " and duedate < now() ";
	if (!isEmpty($productid)) {
		$sql .= " and exists (select * from salesorder_item soi2 where soi2.orderid=so.orderid and soi2.productid=$productid) ";
	}
	if (!isEmpty($credit_orgid)) 
		$sql .= " and credit_orgid=$credit_orgid ";
	$sql .= "group by orderid ";
	if ($unpaid)
		$sql .= " having total > 0 and (total > allocated or allocated is null) ";
	$sql .= "order by orderid desc";
    $rs = query($sql);
    
	$customers = rs2array(query("select customerid, displayname from customer"));
?>

<head>
<title>ICS System Solutions - <?php etr("Sales") ?></title>
<?php
styleSheet();
include_datebox();
?>
</head>

<body>

<?php 
menubar('index.php');
?>
<br>
<form action="sales.php" method="GET">
<div class="border">
<table class='main'>
<tr><td><?php etr("Customer") ?>:</td><td><?php comboBox('customerid', $customers, $customerid, true) ?></td>
<tr>
	<td><?php etr("Only show") ?>:</td>
	<td>
		<?php checkbox('uninvoiced', $uninvoiced, 'Not invoiced') ?>
		<?php checkbox('unpaid', $unpaid, 'Unpaid') ?>
		<?php checkbox('overdue', $overdue, 'Overdue') ?>
	</td>
</tr>
<tr>
	<td><?php etr("Interval") ?>:</td>
	<td>
		<?php datebox("starttime", formatDate($starttime)) ?>
		<?php datebox("endtime", formatDate($endtime)) ?>
	</td>
</tr>
<tr><td><input type="submit" name="search" value="<?php etr("Search") ?>" /></td></tr>
</tr>
</table>
</div>
</form>

<form action="sales.php" method=POST>
<table width="100%" class='main'>
<!-- <th><?php etr("Cancel") ?></th>  -->
<th width='15%'><?php etr("Order date") ?></th>
<th width='8%'><?php etr("Order ID") ?></th>
<th width='30%'><?php etr("Customer") ?></th>         
<th width='8%'><?php etr("Other Adj") ?></th> 
<th width='8%'><?php etr("Discount(%)") ?></th> 
<th width='8%'><?php etr("Amount") ?></th>
<th><?php etr("Invoiced") ?></th>
<th><?php etr("Payed") ?></th>
<th><?php etr("Recurring") ?></th>
<?php

               $total_other_adjustment_amoun=0;
               $total_discount_amount=0;
               
    $class = "odd";
    $i = 0;
    $sub_total=0;
    while ($row = fetch_object($rs)) {
    echo "<tr class='$class'>";
	 /*   	deleteColumn("sales.php?del_orderid=$row->orderid");   */
    	$script = "salesorder.php";
    	if ($row->credit_orgid != null)
    		$script = "credit_salesorder.php";
    	$href = "$script?orderid=$row->orderid";    	
           
             
        echo "<td align=center>" . date(DATE_PATTERN, $row->orderdate) . "</td>"; 
         echo "<td align=right><a href='$href'>";
    
        	printf($row->orderid);
             echo "</a></td>";       
        echo "<td>$row->displayname</td>";
        
                  	$other_adjustment_amount = findValue("SELECT other_adjustment 
                    FROM `salesorder`
                    	where orderid=$row->orderid");
                    	
                  	$discount_amount = findValue("SELECT discount  
                    FROM `salesorder`
                    	where orderid=$row->orderid");  	
                    	
           echo "<td align=center width=130>  $other_adjustment_amount </td>"; 
               $total_other_adjustment_amount =$total_other_adjustment_amount + $other_adjustment_amount;
               
           echo "<td align=center width=130>  $discount_amount  </td>"; 
                 $total_discount_amount=$total_discount_amount + $discount_amount;       
        
        echo "<td align=right>";
        
    
     
        
         echo formatMoney($row->total-$other_adjustment_amount);  
          $sub_total +=$row->total; //-$other_adjustment;
          
       
        if (isEmpty($row->invoice_transid))
        	echo "<td/>";
        else
        	echo "<td align=center>X</td>";
        if ($row->total > $row->allocated || $row->total == 0)
        	echo "<td/>";
        else
        	echo "<td align=center>X</td>";
		echo "<td align=center>";
		echo $row->recur != null ? 'X' : '';
		echo "</td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
        $i++;
    }
  ?>  


   <th> </th>
<th> </th>
<th width='35%' align=right>Total </th>
 <?php  echo "<th>"; echo formatMoney($total_other_adjustment_amount);?> <?php echo "</th>"; ?>
<?php   echo "<th>"; 
echo  formatMoney($total_discount_amount);
  echo"</th>"; ?> 
<th width='15%' align=right> <?php echo formatMoney($sub_total) ?></th>
<th> </th>
<th> </th>
<th> </th>
<th> </th> 
    

</table>
<br/>
<?php newButton("customers.php?mode=createorder") ?>
</form>
<?php bottom() ?>
</body>
