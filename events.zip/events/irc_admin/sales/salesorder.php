<?php
	include('include.php');
	include('salesorder.inc.php');
	include('invoice_pdf.inc.php');

	checkPermission(PERMISSIONID_SELL);

        $mode = getParam("mode");
        $orderid = getParam('orderid');
        $updatesales = getParam("updatesales");
        $show = getParam("show");
        
        $ck = getParam("ck");
        $totalck = count($ck);
        $asdd = 0;

        for ($i = 0; $i < $totalck; $i++)
        {
		$unittupe = findValue("
		select unittype from product
		where productid='$ck[$i]'");
                $asdd++;
                
                $pprice = findValue("Select purchase_price from product where productid = '{$ck[$i]}' ");
                ($pprice =="") ? $pprice =0 : $pprice ;
                // FARUK
                sql("Insert into salesorder_item (orderid, productid, unittype, no, purchaseprice, quantity) values ($orderid,$ck[$i],$unittupe, $asdd, $pprice, 1) ");
                // END FARUK
                $asdd++;
//                sql("Insert into salesorder_item (orderid, productid, unittype, no) values ($orderid,2,$unittupe, $asdd) ");
//                            $mess = add_deritem($orderid, $ck[$i], $unittupe, 0 , $unitprice);
//            $mess = getError($mess);
        }

        if ($updatesales) {
            $totallist = getParam("totallist");
            $qty = getParam("qty");
            $up = getParam("up");
            $prodid = getParam("prodid");

            for ($x = 0; $x < $totallist; $x++) {
               $totalsprice =  $qty[$x] * $up[$x];
               $qty[$x] == "" ? $qty[$x] = 1 : $qty[$x];
               $up[$x] == "" ? $up[$x] = 1 : $up[$x];
               sql("Update salesorder_item set
                    quantity = {$qty[$x]},
                    unitprice = {$up[$x]}
                where
                    productid = '$prodid[$x]' and
                    orderid = $orderid

                ");
               
            }
            
        }

	
	
	$method = getParam('method', METHOD_CASH);
	$new = true;

	$other_adjustment=getParam('other_adjustment');
	$salestypeid=getParam('salestypeid'); 
  $invoicetypeid=getParam('invoicetypeid'); 
  $invoiceforid=getParam('invoiceforid'); 
  $deliverydate=getParam('deliverydate');
  $discount=getParam('discount');
 $locationid = getParam("locationid");
  $fieldforceid = getParam('fieldforceid');
 
   		$orderedby = getParam('orderedby');
	if($orderedby=='')
	  $orderedby='n/a';
	
	
	$customerid = getParam('customerid');
	$recur = getParam('recur');
	$orderdate = time();
	$invoice_transid = null;
	$addable = true;
	$cancelled = false;
	$createdby = null;
	$mess = null;
  $submit = getParam('submit');
  
 
	
	 if ($submit=='Save'){   
                      
       sql("update salesorder
		set
		invoicetype=$invoicetypeid,
    deliverydate='$deliverydate',
    invoicefor=$invoiceforid,
    salestype=$salestypeid,
    fieldforceid = $fieldforceid,
		locationid=$locationid,
		orderedby='$orderedby'
		where orderid=$orderid");
    }	    
 
 
	if (getParam("action") == "create") {
		$locationid = findValue("select locationid from user where username='" . getUser() . "'", 1);
		$sql = "insert into salesorder (orderdate, customerid, createdby, locationid)
		        values (now(), $customerid, '" . getUser() . "', $locationid)";
		sql($sql);
		$orderid = insert_id();
		if ($recur)
			sql("insert into recur_salesorder (orderid, active) values ($orderid, 1)");
	}

	$incVAT = false;
	$useVAT = true;
	if (!isEmpty($orderid)) {
		$listid = findValue("
		select pricelistid
		from customer c
		join salesorder so on so.customerid=c.customerid
		where so.orderid=$orderid");
		$customerid = findValue("select customerid from salesorder where orderid=$orderid");
		
		$incVAT = findValue("select vat_included from pricelist where listid=$listid");
		
		$useVAT = findValue("
		select use_vat
		from customer c
		join salesorder so on so.customerid=c.customerid
		where orderid=$orderid");
		
		$use_discount = findValue("
		select use_discount
		from customer c
		join salesorder so on so.customerid=c.customerid
		where orderid=$orderid");
	}
   
	if (isSave()) {

		$recur = getParam('recur', false);
		if ($recur) {
			$recur_active = getParam('recur_active', 0);
			sql("update recur_salesorder set active=$recur_active where orderid=$orderid");
		}
		$comment = getParam('comment');
		$other_adjustment=getParam('other_adjustment');
		
		 
	/*	sql("
		update salesorder
		set 
    comment='$comment',
		locationid=$locationid,
		orderedby='$orderedby' 			
		where orderid=$orderid");
		
	*/		 
		 
		sql("update user set locationid=$locationid where username='" . getUser() . "'");
		$count = getParam('count');
		$i = 0;
         die;
		while ($i < $count) {
			$no = getParam("no_$i");
			
			$unitprice = getParam("unitprice_$i");
			$unittype = getParam("unittype_$i");
			
			$percent = findValue("select percent
								  from vat_category vc
								  join category c on c.vatcatid=vc.vatcatid
								  join product p on p.categoryid=c.categoryid
								  join salesorder_item soi on soi.productid=p.productid
								  where orderid=$orderid and no=$no");
								  
								  
	/*			$packsize_new = findValue("SELECT packsize_unit 
                    FROM `packsize_unit` put
                     join salesorder_item soi on soi.productid=put.productid 
								  where orderid=$orderid and no=$no");		*/			  
								  
	     $dis_percent = findValue("select dis_percent
								  from discountprice dp
								  join category c on c.discountpriceid=dp.discountpriceid
								  join product p on p.categoryid=c.categoryid
								  join salesorder_item soi on soi.productid=p.productid
								  where orderid=$orderid and no=$no");								  
								  
								   
			$description = getParam("description_$i");
			if ($useVAT) {
				if ($incVAT) {
					$unitpriceInc = $unitprice;
					$unitprice = $unitprice / (1 + $percent/100);
					$vat = $unitpriceInc - $unitprice;
				} else
					$vat = $unitprice * $percent/100;
			} else
				$vat = 0;
				
						if ($dis_percent) 
            $discountprice = $unitprice * $dis_percent/100;
					  else
					  $discountprice=0;
					  
			$quantity = getParam("quantity_$i");
			$comment = getParam("comment_$i");
			$unittype = getParam("unittype_$i");
			sql("
			update salesorder_item set 
				quantity=$quantity, 
				unitprice=$unitprice, 
				unittype =$unittype,
				vat=$percent,
				discountprice=$discountprice,
				comment='$comment'
			where orderid=$orderid and no=$no");
			$i++;
		}
	}
if(isset($other_adjustment) or isset($discount)) {
  sql("
		update salesorder
		set
		discount=$discount,
			other_adjustment=$other_adjustment		
		where orderid=$orderid");
  }
        
      
	$productid_new = getParam('productid_new');
	
	if (array_key_exists('add', $_POST) || !isEmpty($productid_new)) {
		if (!isEmpty($productid_new)) {
			$quantity = getParam('quantity_new'); 
			$unitprice = getParam('unitprice_new');
//                        $unittype = getParam('unittype_new');
			$unittype = getParam('unittype_new');
			$comment = getParam('comment_new');
			$otherdiscount = getParam('other_discount');
			$bonusquantity = getParam('bonus_quantity');
			$samplequantity = getParam('sample_quantity');
			$discount=getParam('discount');
			$other_adjustment=getParam('other_adjustment');
		 
			
			$mess = add_orderitem($orderid, $productid_new, $unittype, $quantity, $unitprice);
			$mess = getError($mess);
		}
	}
	if (array_key_exists('cancel', $_POST)) {
		tx("cancel_order", array($orderid));
	}

	$del_no = getParam("del_no");
	if (!isEmpty($del_no)) {
		sql("delete from salesorder_item where orderid=$orderid and no=$del_no");
		$productid = null;
	}
	if (array_key_exists('invoice', $_POST)) {
	   tx("invoice_salesorder", array($orderid));
	}
	if (getParam("action") == "email") {
		$mess = email_invoice($orderid);
	}
	if (array_key_exists('pay', $_POST)) {
		$payedGross = getParam("payedGross");
		tx("pay_salesorder", array($orderid, $payedGross));
	}
	if (array_key_exists('finish', $_POST)) {
		$payedGross = getParam("payedGross");
		tx("finish_cashorder", array($orderid, $payedGross));
	}
   // ///////////////////////////////kkkkkkkkk
	$items = null;
	$receiptCount = 0;
	$receipt_transid = null;
	$recur = null;
	$credited = false;
	$toPay = 0;
	$comment = '';
	$locationid = null;
	if (!isEmpty($orderid)) {
	    $sql =
  		"select 
  			so.orderid,
  			so.no,
  		    unix_timestamp(orderdate) as orderdate,
		    customerid,
		    invoice_transid,
			cancelled,
			so.createdby,
			rso.orderid as recur_orderid,
			active,
			credit_orgid,
			comment,
			locationid,
			invoicetype, 
		    deliverydate, 
			invoicefor, 
			salestype,
      fieldforceid,         
			other_adjustment,
			discount,
			orderedby
		from salesorder so
		left outer join transaction t on t.transactionid=so.invoice_transid
		left outer join recur_salesorder rso on rso.orderid=so.orderid
		where so.orderid=$orderid
		";
		$rec = find($sql);
		if ($rec != null) {
			if ($rec->credit_orgid != null) {
					header("Location: credit_salesorder.php?orderid=$orderid");
					die;
			}

			$orderid = $rec->orderid;
			$customerid = $rec->customerid;
			$orderdate = $rec->orderdate;
			$invoice_transid = $rec->invoice_transid;
			if ($invoice_transid != null)
  			$addable = false;
  			$cancelled = $rec->cancelled;
  		if ($cancelled)
				$addable = false;
			$createdby = $rec->createdby;
			$recur = $rec->recur_orderid != null;
			$recur_active = $rec->active;
			$comment = $rec->comment;
			$locationid= $rec->locationid;
			$new = false;

			$sql = "
			select
			  si.productid,
			  model,
			  si.quantity,
			  unitprice,
			  vat,
			  no,
			  percent,
              u.description as unittype,
              purchase_price,
              comment
			from salesorder_item si
			join product p on p.productid=si.productid
			join category c on c.categoryid=p.categoryid
			join vat_category vc on vc.vatcatid=c.vatcatid
            left outer join unittype u on u.unittype=p.unittype
			where orderid=$orderid
			and si.productid != " . PRODUCTID_ROUNDING;
			
			$items = query($sql);
		}
	
		$toPay = getSalesOrderTotalIncVat($orderid);
		$rounding = findValue("select unitprice from salesorder_item
		                       where orderid=$orderid and productid=" . PRODUCTID_ROUNDING);
		                       
		//$product_unit = findValue("select unittype from salesorder_item
		//                       where orderid=$orderid and productid=" . PRODUCTID_ROUNDING);                       
		 //echo "Product type $product_unit FFFF";                      
		$payed = findValue("select sum(amount) from receipt_allocation where orderid=$orderid");
		$payed = round($payed, 2);
		$fullyPayed = (round($payed, 2) >= round($toPay, 2) && $toPay != 0);
		$payedGross = findValue("select sum(amount) from receipt_allocation
		                                           where orderid=$orderid and amount > 0");
		$receiptCount = findValue("select count(*) from receipt_allocation
		                           where orderid=$orderid");
		if ($receiptCount == 1) {
			$receipt_transid = findValue("select transactionid
			                              from receipt_allocation ra
										  join receipt r on r.receiptid=ra.receiptid
										  where orderid=$orderid");
		}

		$credited = findValue("select count(orderid)
		                       from salesorder
							   where credit_orgid=$orderid", 0) > 0;
	}

	$productid = getParam('productid');
	$unittype_new='';
	$unitprice_new = '';
	$purchaseprice_new = '';
	
	if (!isEmpty($productid)) {
		$unitprice_new = findValue("
		select price
		from sales_price
		where productid='$productid' and listid=$listid");
		
		$unittype_new = findValue("
		SELECT
`unittype`.`description`
FROM
`product`
Inner Join `unittype` ON `product`.`unittype` = `unittype`.`unittype`
where productid='$productid'");
		  
		$purchaseprice_new = findValue("
		select purchase_price
		from product
		where productid=$productid");
	}

	$customer = null;
	if (!isEmpty($customerid)) {
		$customer = find("select name from customer where customerid=$customerid");
	}

	$locations = rs2array(query("select locationid, name from location"));
	$methods = array();
	$methods[] = array(METHOD_CASH, tr("Cash"));
	$methods[] = array(METHOD_CARD, tr("Card"));
	
	$invoicetypes = rs2array(query("select invoicetypeid, name from invoicetype"));
	$invoicefors = rs2array(query("select invoiceforid, name from invoicefor"));
	$salestypes = rs2array(query("select salestypeid, name from salestype"));
	
	$fieldforces= rs2array(query("select fieldforceid, name from fieldforce"));   

	
?>

<head>
<title>ICS System Solutions - <?php etr("Sales order") ?></title>
<?php
styleSheet();
include_datebox();
include_common();
?>
<script>
function onLoad()
{
	<?php
	if (getParam("method_changed") && $method == METHOD_CARD) 
		echo "document.postform.creditcardno.focus();";
	else
		echo "document.postform.productid_new.focus();";
		
		if (getParam("adjustment") && $method == METHOD_CARD) 
		echo "document.postform.creditcardno.focus();";
	else
		echo "document.postform.productid_new.focus();";
	?>
}

function submitForm()
{
	document.postform.submit();
}

function methodChanged()
{
	document.postform.method_changed.value = 1;
	submitForm();
}



</script>

<script type="text/javascript">
    document.getElementById('summer').onclick= function() {
         var sum= 0;
         var inputs= document.getElementById('inputs').getElementsByTagName('input');
         for (var i= inputs.length; i-->0;) {
             var v= inputs[i].value.split(',').join('.').split(' ').join('');
             if (isNaN(+v))
                 alert(inputs[i].value+' is not a readable number');
             else
                 sum+= +v;
         }
         document.getElementById('sum').value= sum;
    };
</script>
</head>

<body onLoad="onLoad()">
<?php
menubar('index.php', 'salesorder_help.php');
$title = $new ? tr("Register") : $orderid;
title("<a href='sales.php'>" . tr("Sales orders") . "</a> > $title") ;
?>

<?php
if ($mess != null) {
	echo "<center class=error>$mess</center>";
}
if (array_key_exists('finish', $_POST) && false) {
	echo "<center>";
	echo "<applet code='therp.print.PrintApplet.class' ";
	echo "codebase='" . getCodebase() ."' ";
	echo "archive='java/printapplet.jar' width=150 height=30></applet>";
	echo "</center>";
}
?>

<form name=postform action="salesorder.php" method="POST">
<input type=hidden name=customerid value='<?php echo $customerid ?>'/>
<table>
<tr>
<?php
	if (!$new) {
		echo "<td><b>" . tr("Order no") . ":</b></td>";
		echo "<td>";
		if ($rec->no != null)
			echo $rec->no;
		else
			echo $orderid;
		echo "<input type='hidden' name='orderid' value='$orderid'/>";
		echo "</td>";
	}
?>
<td width=20/>
<td><b><?php etr("Customer") ?>:</b></td><td><?php echo $customer->name ?></td>
<td width=20/>
<?php 
if ($customerid != CUSTOMERID_CASH) {
	echo "<td><b>" . tr("Ordered by") .":</b></td>";
	echo "<td>";
	if (isEmpty($invoice_transid)) {
		textbox('orderedby', $rec->orderedby);
		echo "</td><td><input type='image' name='save' value='Save' src='../images/disk.gif'>";	
	} else
		echo $rec->orderedby;	 
	echo "</td>";
} else {
	echo "<td/><td/>";
}
?>
</tr>                
<tr>
	<td><b><?php etr("Order date") ?>:</b></td><td><?php echo date(DATE_PATTERN, $orderdate) ?></td>
	<td/>
	<td class=label><?php etr("Location") ?>:</td>
	<td>
	<?php
	//if (isEmpty($invoice_transid))
		combobox('locationid', $locations, $locationid, false);
//	else {
//		$location = findValue("select name from location where locationid=$locationid");
//		echo $location;
//	}
	?>
	</td>
	 
	<td class=label>&nbsp; </td>
		
	
	<td>
&nbsp;
	</td>
</tr>
<?php
if ($recur) {
	hidden('recur', 1);
	echo "<tr>";
	echo "<td class=label>" . tr("Recur active") . ":</td>";
	echo "<td>";
	checkBox('recur_active', $recur_active);
	echo "</td>";
	echo "</tr>";
} else {
	if ($customerid != CUSTOMERID_CASH) {
		if (!isEmpty($invoice_transid)) {
			echo "<tr>";
			echo "<td class=label>" . tr("Invoice") . ":</td>";
			echo "<td colspan=4>";
			echo "<a href='invoice_pdf.php?orderid=$orderid' target=_blank>" . tr("Print") . "</a>";
			echo "&nbsp;|&nbsp;";
			echo "<a href='email_invoice.php?orderid=$orderid'>" . tr("E-mail customer") . "</a>";
			echo "&nbsp;|&nbsp;";
			echo "<a href='../accounting/transaction.php?transactionid=$invoice_transid&salesorderid=$orderid'>";
			echo tr("Show transaction") . "</a>";
			echo "&nbsp;|&nbsp;";
			echo "<a href='invoice_pdf.php?orderid=$orderid&filename=challan' target=_blank>" . tr("Challan") . "</a>";
			echo "</td>";
			echo "</tr>";
		}
		if (!$new) {
			echo "<tr>";
			echo "<td class=label>" . tr("Receipt") . ":</td>";
			echo "<td colspan=4>";
			if ($fullyPayed)
				etr("Fully paid");
			else
				echo formatMoney($payed) . " / " . formatMoney($toPay);
			echo "&nbsp;&nbsp;";
			if ($payed != 0) {
				if ($receiptCount > 1) {
					echo "<a href='salesorder_receipts.php?orderid=$orderid'>";
					echo tr("Show receipts") . "</a>";
				} else {
					$href = "../accounting/transaction.php?
                             transactionid=$receipt_transid&salesorderid=$orderid";
					echo "<a href='$href'>";
					echo tr("Show transaction") . "</a>";
				}
			}
			echo "</td>";
			echo "</tr>";
		}
	} else {
		echo "<tr>";
		echo "<td class=label>" . tr("Receipt") . ":</td>";
		echo "<td colspan=4>";
		if ($fullyPayed)
			etr("Fully paid");
		else
			etr("Not paid");
		echo "&nbsp;&nbsp;";
		if ($payed != 0) {
			echo "<a href='invoice_pdf.php?orderid=$orderid&type=receipt'>" . tr("Print") . "</a>";
			echo "&nbsp;&nbsp;";
			echo "<a href='../accounting/transaction.php?transactionid=$invoice_transid
			      &salesorderid=$orderid'>" . tr("Show transaction") . "</a>";
		}
		echo "</td>";
		 	
		echo "</tr>";
	}
 
	if ($credited) {
		echo "<tr>";
		echo "<td colspan=2>";
		echo tr("This order is credited") . "&nbsp;&nbsp;";
		echo "<a href='sales.php?credit_orgid=$orderid'>" . tr("Show credit orders") . "</a>";
		echo "</td>";
		echo "</tr>";
	}
	if ($cancelled) {
		echo "<tr>";
		echo "<td colspan=2>";
		echo tr("This order is cancelled");
		echo "</td>";
		echo "</tr>";
	}
}
?>
<tr>
<td class=label><?php etr("Created by") ?>:</td>
<td><?php echo $createdby ?></td>
</tr>
</table>
<?php
 //	button("Save", "save", null, 'F');

?>
  
<br/>
 
<?php
if ($recur) {
	saveButton();
	echo "<br>";
}
?>

<?php if ($items != null) { ?>
<?php //////////////////////////////////////////part 1 ?>  
<div class='border'>
<table>
<?php
if ($addable)
	echo "<th>" . tr("Delete") . "</th>";
?>
<th><?php etr("Product") ?></th>
 <th><?php etr("Unit Type") ?></th> 
<th><?php etr("Quantity") ?></th>
<th><?php etr("Unit price") ?></th>
<!--  <th><?php etr("Purchase price") ?></th>  -->
<th><?php etr("Total Amount") ?></th>
<!--  <th><?php etr("Discount") ?></th>  -->
<?php
	echo "<th>" . tr("VAT") . "</th>";
	?>
<!--   <th><?php etr("Other Disc") ?></th> 	
 <th><?php etr("Bonus QT") ?></th>
  <th><?php etr("Sample QT") ?></th>
-->  
  <th><?php etr("Net Amount") ?></th>
<?php
if ($show == "profitloss")  {
    echo "<th>Purchase Price</th>";
    echo "<th>Profit / Loss</th>";

}


?>
<?php
//if ($addable)
//	echo "<th>" . tr("Save") . "</th>";


$class = 'odd';
$i = 0;
$sum = 0;
$vatSum = 0;
$net_sum_sum=0;
$discount_price_sum=0;
$net=0;
$other_discount_sum=0;
$totallist = 0;
while ($row = fetch($items)) {
    $totallist ++;
	if ($addable)
		echo "<input type=hidden name=no_$i value='$row->no'/>";
  // ////////////////////////////////////////part 2  		
		
	echo "<tr class='$class'>";
	$href = "salesorder.php?orderid=$orderid&del_no=$row->no";
	if ($addable)
		deleteColumn($href);
	echo "<td>";
	echo "$row->productid - $row->model";
        echo "<input type='hidden' name='prodid[]' value='$row->productid' /> ";
        echo "</td>";
	
	echo "<td>";
 	if ($addable)
// 		textbox("unittype_$i", $row->packsize, 7);
            echo $row->packsize;
 else
 		echo $unittype;
 	echo "</td>";    
	
	 
  echo "<td align=center>";
	if ($addable)
            echo "<input type='text' name='qty[]' value='$row->quantity' size=1  class=numberbox  />";
//		numberbox("quantity_$i", $row->quantity, 5, false, true);

	else
		echo $row->quantity;// . ' ' . $row->unittype;
	echo "</td>";
	
	echo "<td align=right>";
	$unitprice = $row->unitprice;
	if ($incVAT)
		$unitprice = $unitprice + $row->vat;

        //FARUK
	if ($addable) {
                if ($unitprice == "" || $unitprice =="0") {
                    $findunit = findValue("Select price from sales_price where productid = '$row->productid'");
                    $unitprice = $findunit;
                }
                
                echo "<input type=text name='up[]' value='$unitprice' size=13 class=moneybox />";
//		moneybox("unitprice_$i", $unitprice);
        } else {
		echo formatMoney($unitprice);
        }

        //END FARUK
	echo "</td>";
	
	
	//echo "<td align=right>" . formatMoney($row->purchase_price) . "</td>";
	$amount = $row->quantity * $row->unitprice;
	echo "<td align=right>" . formatMoney($amount) . "</td>";
	
		$discount_price = (($row->discountprice/100) * $row->unitprice * $row->quantity);
	
	
	if (!$incVAT) {
		$vat = $row->vat/100 * $row->unitprice * $row->quantity;
		echo "<td align=right>" . formatMoney($vat) . "</td>";
	}
	
	$net = $amount -$discount_price + $vat; 
 
  
     $net_sum=$net-$row->other_disc;
	    $other_discount_sum +=$row->other_disc;
	 $net_sum_sum += $net_sum;
 
	  	echo "<td align=right>";
		echo formatMoney($net_sum);
		echo "</td>";
		
		$sum += $amount;

	
	$vatSum += $row->vat/100 * $row->quantity * $row->unitprice;
 
	$discount_price_sum += $row->discountprice/100 * $row->quantity * $row->unitprice;

        if ($show == "profitloss"){
            echo "<td align='right'>$row->purchaseprice</td>";
            $totalpl = $row->unitprice - $row->purchaseprice;
            echo "<td align='right'>" . formatMoney($totalpl) . "</td>";
            $profitloss = $profitloss +$totalpl;
        }
//	if ($addable) {
//		echo "<td align=center>";
//		echo "<input type='image' name='save' value='Save' src='../images/disk.gif'>";
//		echo "</td>";
//	}
	echo "</tr>\n";
	
 
    $class = ($class == "odd" ? "even" : "odd");
    $i++;
}
 //   ////////////////////////////////////////part 3 
 
if ($addable) {
	hidden('count', $i);
	echo "<tr class='<?php echo $class ?>'>";
	echo "<td/>";
	echo "<td>";
	textbox('productid_new', $productid, 10);
	button("Search", "search", "../erp/products.php?mode=selectproduct&orderid=$orderid");
	echo "</td>";
	echo "<td>";
	textbox('unittype_new', $unittype_new, 7);
	echo "</td>";
	echo "<td align=right>";
	numberbox('quantity_new', 1, 5, false, true);
	echo "</td>";
	echo "<td align=right>";
	moneybox('unitprice_new', $unitprice_new);
  echo "</td>";
		echo "<td align=right>";
	echo " ";
	echo "</td>";
			echo "<td align=right>";
	echo "&nbsp;";
	echo "</td>";
	echo "<td align=right>";
	if (!isEmpty($purchaseprice_new))
	echo formatMoney($purchaseprice_new);
	echo "</td>";
 
	 
	echo "<td><input type=submit name=add value='Add'/></td>";
	echo "</tr>";
}
?>
<tr>
<td/>
<?php
if ($addable) echo "<td/>";
?>
<td/>
<td/>
<?php
if ($incVAT)
	echo "<td align=right>" . tr("VAT") . ":</td>";
else {
	echo "<td/>";
	echo "<td align=right><b>" . formatMoney($sum) . "</b></td>";
}
?>
 

<td align=right> </td>
<td align=right><b><?php echo formatMoney($net_sum_sum) ?></b></td>
<?php
        if ($show == "profitloss"){
            echo "<td align='right' colspan=2><b>" . formatMoney($profitloss) . "</b></td>";
       }
        ?>
</tr> 
<?php $colspan = $addable ? 4 : 3 ?>
<tr>
<td colspan='<?php echo $colspan ?>'/>
<!--
<td align=right><?php etr("Rounding") ?>:</td>
<td align=right><?php echo formatMoney($rounding) ?></td>
-->

</tr>



 <tr>
<td colspan='<?php echo $colspan ?>'/>
<td align=right><b>Discount (%)</td>
<?php

 $discount= findValue("select discount from salesorder where orderid=$orderid");
  //$discount_percent= findValue("select discount from salesorder where orderid=$orderid");
 
if ($discount<=0){    
   	echo "<td align=right>";
  textbox('discount','0', 7);
  echo "</td>";
  
 }  else{
 
    
	echo "<td align=right>";
   textbox('discount', formatMoney($discount), 7);
  // $total_other_adjustment_amount=$other_adjustment-$other_adjustment_amount;
   //echo "$other_adjustment_amount</td>";
   $discountamount1=$discount/100* $net_sum_sum;
   echo "</td>";
   echo "<td align=right>Tk.";
    echo formatMoney($discountamount1);
   echo "</td>";
   
   }

?>
 </tr>







<tr>
<td colspan='<?php echo $colspan ?>'/>
<td align=right><b>Adjustment</td>
<?php

$other_adjustment_amount = findValue("select other_adjustment from salesorder where orderid=$orderid");
  
if ($other_adjustment_amount<=0){    
   	echo "<td align=right>";
  textbox('other_adjustment','0', 7);
  echo "</td>";
  
 }  else{
 
    
	echo "<td align=right>";
   textbox('other_adjustment', $other_adjustment_amount, 7);
  // $total_other_adjustment_amount=$other_adjustment-$other_adjustment_amount;
   //echo "$other_adjustment_amount</td>";
   echo "</td>";
   }

?>
 </tr>
 
 
<tr>
<td colspan='<?php echo $colspan ?>'/>
<td align=right class=label><?php

if($discount>0){
         $overalldiscountamount = (($discount/100)*$net_sum_sum);
 }
 else
  $overalldiscountamount=0;
  
 //echo "With discount $overalldiscountamount";
if($other_adjustment_amount>0){
         $overalladjustment = $other_adjustment_amount;
}
else
  $overalladjustment=0;
         
//   echo "With adjustment $overalladjustment";
///echo "(($discount_percent/100)*$net_sum_sum)";
// echo "SS $ss";

$toPay=$net_sum_sum-$overalladjustment-$overalldiscountamount+$vatSum-$other_discount_sum;



 etr("To pay") ?>:</td>
 


<td align=right><b><?php echo formatMoney($toPay) ?></b></td>
</tr>
<?php
if ($customerid == CUSTOMERID_CASH) {
	$showExchange = true;
	$exchange = 0;
	if ($payedGross > 0) {
		$exchange = $payedGross - $toPay;
	}
	if ($exchange < 0.01)
		$showExchange = false;
	echo "<tr>";
	$colspan = $addable ? 4 : 3;
	echo "<td colspan='$colspan'>";
	if ($payed < $toPay) {
		echo tr("Payment method").':&nbsp;';
		combobox('method', $methods, $method, false, "methodChanged()");
		hidden('method_changed', 0);
	}
	echo "</td>";
	$text = $method == METHOD_CASH ? "Amount paid" : "Credit card no";
	echo "<td align=right>" . tr($text) . ":</td>";
	echo "<td align=right>";
	if ($payedGross == 0)
		$payedGross = $toPay;// -$other_adjustment;

		
	$payedGross = round($payedGross, 2);
	if ($method == METHOD_CASH) {
		if ($payed < $toPay)
			moneybox('payedGross', $payedGross);
		else
			echo formatMoney($payedGross);
	} else {
		if ($payed < $toPay) {
			echo "<input type=password name=creditcardno>";
			hidden('payedGross', $payedGross);
		}
	}
	echo "</td>";
	if ($showExchange) {
		echo "</tr>";
		echo "<tr>";
		echo "<td colspan='$colspan'/>";
		echo "<td align=right>" . tr("Exchange") . ":</td>";
		echo "<td align=right>";
		echo formatMoney($exchange);
		echo "</td>";
		echo "</tr>";
	}
}
?>
<tr>
    <td colspan="9">
        <?php
        if ($addable) {?>
        <input value="Update Quantity and Price " name="updatesales" type="submit" />
        <?php } ?>
    </td>
</tr>
</table>
</div>
<br/>
<?php } ?>

<?php
if ($new) {
	button("Create", "save");
} else {
	if (!$recur) {
		if ($customerid == CUSTOMERID_CASH) {
			if (!$fullyPayed && !$cancelled) {
				button('Receipt', 'finish', null, 'F');
				echo "&nbsp;";
			}
			if ($fullyPayed) {
				button('New order', 'new',
				       "salesorder.php?customerid=$customerid&action=create", 'N');
				echo "<script>document.postform.new.focus();</script>";
				echo "&nbsp;";
			}
		}
		else {
			if (isEmpty($invoice_transid) && !$cancelled) {
				button('doInvoice', 'invoice');
				echo "&nbsp;";
			} else if (!$fullyPayed && !$cancelled) {
				button('Receipt', 'pay');
				echo "&nbsp;";
			}
		}
		if (!isEmpty($invoice_transid)) {
			button("Credit order", 'credit',
			       "credit_salesorder.php?action=create&credit_orgid=$orderid&customerid=$customerid");
			echo "&nbsp;";
		}
	}
	if (!$cancelled) {
		button("Cancel order", 'cancel');
		echo "&nbsp;";
	}
	button("Show stock moves", "moves", "../erp/stockmoves.php?salesorderid=$orderid");
}

?>
<input type="hidden" name="new" value="<?php echo $new ?>"/>
<input type="hidden" name="totallist" value="<?php echo $totallist ?>"/>
</form>

<?php bottom() ?>

</body>
