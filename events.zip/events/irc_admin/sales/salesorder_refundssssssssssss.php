<?php
	include('include.php');
	//include('salesorder.inc.php');
	
	$orderid_bool = false;   //THIS BOOLEAN IS USED FOR SEARCHING VALUES WITH ORDERID

    $model = getParam('model');
	$recur = getParam('recur');

	$starttime = parseDate(getParam('starttime'));
	if (isEmpty($starttime))
		$starttime = roundTime(time(), TYPE_MONTHS);
	$endtime = parseDate(getParam('endtime'));
	if (isEmpty($endtime))
		$endtime = addTime($starttime, TYPE_MONTHS);
	
	$del_productid = getParam("del_productid");
	if (!isEmpty($del_productid)) {
		sql("delete from mnf_productrecipe where productid=$del_productid");
	}
	
	$orderid = getParam('orderid');  // COLLECT VALUE FROM [ORDER ID] TEXT BOX
	
	if ($orderid != ""){ 	// CHECKING CONDITION
		
		$orderid_bool = true;
 		$orderid_db = "and salesorder_refund.orderid like '$orderid%' ";
 	}

 
	if ($orderid_bool == 1){  // CHECKING CONDITION IS IT TRUE? IF YES THEN EXECUTE UPPER CODE, IF NO THEN GOTO ELSE AND EXECUTE
	
		$selectSQL = "SELECT
			salesorder_refund.productid,
			unix_timestamp(returndate) as returndate,
			product.model,
			salesorder_refund.orderid,
			salesorder_refund.quantity
			FROM
			product
			Inner Join salesorder_refund ON product.productid = salesorder_refund.productid
			WHERE product.model like '$model%' $orderid_db and returndate between from_unixtime($starttime) and from_unixtime($endtime)
			ORDER BY salesorder_refund.orderid DESC 
			";
			
		}
	else
		{
		$selectSQL = "SELECT
			salesorder_refund.productid,
			unix_timestamp(returndate) as returndate,
			product.model,
			salesorder_refund.orderid,
			salesorder_refund.quantity,
			salesorder.orderid,
			salesorder.refundamount
			FROM
			product
			Inner Join salesorder_refund ON product.productid = salesorder_refund.productid
			Inner Join salesorder ON salesorder_refund.orderid = salesorder.orderid
			WHERE product.model like '$model%'and returndate between from_unixtime($starttime) and from_unixtime($endtime)
			 ORDER BY salesorder_refund.orderid DESC 
			";
		}
		

	if ($orderid_bool == 1){  // CHECKING CONDITION IS IT TRUE? IF YES THEN EXECUTE UPPER CODE, IF NO THEN GOTO ELSE AND EXECUTE
	
		$selectSQL_refund = "SELECT
				salesorder.orderid,
				salesorder.refundamount,
				salesorder_refund.orderid
				FROM
				salesorder
				Inner Join salesorder_refund ON salesorder.orderid = salesorder_refund.orderid
				WHERE returndate between from_unixtime($starttime) and from_unixtime($endtime) $orderid_db
				GROUP BY salesorder_refund.orderid 
				ORDER BY salesorder_refund.orderid DESC

			";
			
		}
	else
		{
		$selectSQL_refund = "SELECT
			salesorder.orderid,
			salesorder.refundamount,
			salesorder_refund.orderid
			FROM
			salesorder
			Inner Join salesorder_refund ON salesorder.orderid = salesorder_refund.orderid
			WHERE returndate between from_unixtime($starttime) and from_unixtime($endtime)
			GROUP BY salesorder_refund.orderid 
			ORDER BY salesorder_refund.orderid DESC

			";
		}


	$mode = getParam('mode');

?>

<head>
<title>ICS System Solutions - Product Return List</title>
<?php styleSheet() ;
include_datebox();
?>
</head>

<body>

<?php menubar('customers.php') ?>
<?php
	title(tr("Product Return List"))
?>

<form action="salesorder_refunds.php" method="GET">
<input type=hidden name=mode value='<?php echo $mode ?>'/>
<div class="border">
<table border="0">
<tr>
	<td><?php etr("Order Id") ?>:</td><td><input type='text' name='orderid' value='<?php echo $orderid ?>'/></td>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
	<td><?php etr("Product Name") ?>:</td><td><input type='text' name='model' value='<?php echo $model ?>'/></td>

	<td>&nbsp;&nbsp;&nbsp;&nbsp;<?php etr("Interval") ?>:</td>
	<td colspan="4">
		<?php datebox("starttime", formatDate($starttime)) ?>
		
		<?php datebox("endtime", formatDate($endtime)) ?>
	</td>
</tr>

<tr><td><?php searchButton() ?></td></tr>
</tr>
</table>
</div>
</form>

<form action="salesorder_refunds.php" method=POST>
<table width='100%'>
<!--<th><?php etr("Delete") ?></th>-->
<!-- <th><?php etr("Update") ?></th> -->
<th><?php etr("Order Id") ?></th>
<th><?php etr("Product Name") ?></th>
<th><?php etr("Quantity") ?></th>
<th><?php etr("Return Date") ?></th>

<?php
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
		$href = "../erp/product.php?productid=$row->productid";
        echo "<tr class='$class'>";
		
		$href2 = "salesorder_refund.php?orderid=$row->orderid";
		
		echo "<td><a href='$href2'>$row->orderid</a></td>";
		echo "<td><a href='$href'>$row->model</a></td>";
		echo "<td>$row->quantity</td>";
		$datedb = formatDate($row->returndate);
		echo "<td>$datedb</td>";

		echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table>

<!------------------------------- Starting Table 2 ---------------------------------------->

<table width='100%'>
<tr>
<td><br><br></td>
</tr>
<!--<th><?php etr("Delete") ?></th>-->
<!-- <th><?php etr("Update") ?></th> -->
<th width="50%"><?php etr("Order Id") ?></th>
<th width="50%"><?php etr("Refund Amount") ?></th>
<!--<th width="34%"><?php etr("Refund Date") ?></th> -->
<?php
//$orderid_bool2 = true;
    $rs = query($selectSQL_refund);
    $class = "odd";
    while ($row = fetch_object($rs)) {
	
		$href = "../erp/product.php?productid=$row->productid";
        echo "<tr class='$class'>";

		$href2 = "salesorder_refund.php?orderid=$row->orderid";
		
		//$orderid_gropuby = "GROUP BY salesorder.orderid";
		
		echo "<td>$row->orderid</td>";
		echo "<td>$row->refundamount</td>";
		//$datedb = formatDate($row->returndate);
		//echo "<td>$datedb</td>";

		echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table>
<table>
<tr>
<td><?php // button("New  Entry", "new", "salesorder_refund.php?mode=$mode") ?></td>
</tr>
</table>
</form>
<?php bottom() ?>
</body>
