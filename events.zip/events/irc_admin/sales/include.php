<?php
include('../include/therp_include.php');

define('METHOD_CASH', 1);
define('METHOD_CARD', 2);

function menubar($currentHref = null, $helpUrl = 'http://icsss.co.uk/acconline')
{
	top0("Sales");
	echo "<table width='100%' cellspacing=0 cellpadding=0 >";
	echo "<tr>";
	echo "<td>";
	echo "<table width='100%' class=menubar>";
		echo "<tr>";
			$percent = 20;
			menu('index.php', 'Sales', $percent, true, $currentHref);
			menu('customers.php?mode=createorder', 'New Invoice', $percent, true, $currentHref);
			menu('sales.php', 'Show Sales Invoice', $percent, true, $currentHref);			
			menu('customers.php', 'Customers', $percent, true, $currentHref);
			menu('reports.php', 'Reports', $percent, true, $currentHref);
			menu('configuration.php', 'Configuration', $percent, true, $currentHref);
			menu($helpUrl, 'Help', $percent, false, $currentHref);
		echo "</tr>";
	echo "</table>";
	echo "</td>";
	echo "</tr>";
	echo "</table>";
	//showUpgrade();
}


?>