<?php

function createInvoicePDF($orderid, $filename = '', $type = 'invoice')
{
	$template = findValue("select invoice_template from settings");
	//
  if($filename!='')
    $template = $filename;
  
  ////echo "invoice_pdf_$template.inc.php";
 //die();
  include("invoice_pdf_$template.inc.php");
	
	buildInvoicePDF($orderid, '', $type);	
}

?>