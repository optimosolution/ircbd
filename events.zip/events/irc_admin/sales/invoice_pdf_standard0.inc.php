<?php
include('../include/ConvertCharset.class.php');     
include "../include/inwordconvert.class.php";               


function ccs($text)
{
	$lang = getLanguage();
	if ($lang == 'en')
		return $text;
	if ($lang == 'sv')
		return utf8_decode($text);
	if ($text == null)
		$text = '';
	if (strlen($text) == 0)
		$text = ' ';
	$converter = new ConvertCharset;	
	$text = $converter->Convert($text, "UTF-8", "cp874", 0);
	return $text;
}

function setHeaderFont($pdf)
{	
	if (getLanguage() == 'th')
		$pdf->setFont('Angsab', '', 12);
	else
		$pdf->setFont('Arial', 'B', 10);
	return $pdf;
}

function setLabelFont($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	if (getLanguage() == 'th')
		$pdf->setFont('Angsa' . $style, '', 10);
	else
		$pdf->setFont('Arial', $style, 10);
	return $pdf;
}

function setLogoFont($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	if (getLanguage() == 'th')
		$pdf->setFont('Angsa' . $style, '', 10);
	else
		$pdf->setFont('Arial', $style, 9);
	return $pdf;
}

function setNormalFont($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	if (getLanguage() == 'th')
		$pdf->setFont('Angsa' . $style, '', 10);
	else
		$pdf->setFont('Times', $style, 10);
	return $pdf;
}

function setNumericFont($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	$pdf->setFont('Courier', $style, 10);
	return $pdf;
}

function setCustomFont2($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	if (getLanguage() == 'th')
		$pdf->setFont('Angsa' . $style, '', 15);
	else
		$pdf->setFont('Arial', $style, 15);
	return $pdf;
}


function buildInvoicePDF($orderid, $filename = '', $type = 'invoice')
{
	include('../include/fpdf/fpdf.php');
	$rightAlign = 'R';
 
	$order = find("SELECT
                `so`.`orderid`,
                `so`.`no`,
                `c`.`name` as name,
                `so`.`orderdate`,
                `so`.`deliverydate`,
                `so`.`invoicetype`,
                `so`.`invoicefor`,
                `so`.`salestype`,
                `so`.`fieldforceid` AS fieldforceid,
                `so`.`locationid` AS `locationid`,
                `c`.`customerid` as customerid,
                unix_timestamp(transtime) AS `invoicedate`,
                unix_timestamp(duedate) AS `duedate`,
                `so`.`orderedby` AS `orderby`,
                `location`.`name` AS `location`,
                `c`.`mainphone` as mainphone,
                `c`.`zipcode` as zipcode ,
                `c`.`city` as city,
                `c`.`streetaddress` as streetaddress
                FROM
					`salesorder` AS `so`
					Inner Join `customer` AS `c` ON `so`.`customerid` = `c`.`customerid`
					Inner Join `transaction` AS `t` ON `t`.`transactionid` = `so`.`invoice_transid`
					Inner Join `location` ON `so`.`locationid` = `location`.`locationid`           	 
					where so.orderid=$orderid"); 
 		   
     
    	/* 
    
    
    $customerinfo = find("SELECT
					 
					FROM
					`salesorder` AS `so`
					Inner Join `customer` AS `c` ON `so`.`customerid` = `c`.`customerid`
					where so.orderid=$orderid");
    
   		*/    
			 
	$incVAT = $order->customerid == CUSTOMERID_CASH;  
	
  $items = query("select
	          p.productid,
					  model,
					  comment,
					  si.quantity,
					  unitprice,
					  vat,
					  discountprice,
            other_disc,
            bonus_qnt,
            sample_qnt,					  
					  no,
					  other_disc,
        		bonus_qnt,
        		sample_qnt,
					  u.description as unittype
					from salesorder_item si
					join product p on p.productid=si.productid
				    left outer join unittype u on u.unittype=p.unittype
					where orderid=$orderid 
					and si.productid != " . PRODUCTID_ROUNDING . "
					");

	$company = find("
          	select companyname, streetaddress, city, zipcode, vatnumber, registrationno 
          	from companyinfo"); 
            
  $custid= findValue("select customerid from salesorder where orderid=$orderid");	         	               
          	
	$customer = find("select name, companyname, streetaddress, city, zipcode, vatnumber from customer 
	                  where customerid=$custid");
  
  $other_adjustment_amount = findValue("select other_adjustment from salesorder where orderid=$orderid");	
    
  $overall_discount = findValue("select discount from salesorder where orderid=$orderid");	
    	                  
	                  
/*	$customerPhones = query("
	select telephoneno, description 
	from customer_phone cp
	join phone_category c on c.phonecatid=cp.phonecatid
	where customerid=$order->customerid");
 */
	$total = getSalesOrderTotalEx($orderid);
	$vatTotal = getSalesOrderTotalVat($orderid);
	$rounding = findValue("select unitprice from salesorder_item 
						   where orderid=$orderid and productid=" . PRODUCTID_ROUNDING);

	define('MARGIN', 5);
	define('WIDTH', 205);
	define('HEIGHT', 290);
	define('ROWHEIGHT', 6);

	$pdf=new FPDF();
	$pdf->AddPage();
	$pdf->AddFont('angsa','','angsa.php'); 
	$pdf->AddFont('angsab','','angsab.php'); 
	//$pdf->Line(MARGIN,MARGIN, MARGIN, HEIGHT);
	//$pdf->Line(MARGIN,HEIGHT, WIDTH, HEIGHT);
	//$pdf->Line(WIDTH,HEIGHT, WIDTH, MARGIN);
	//$pdf->Line(WIDTH,MARGIN, MARGIN, MARGIN);
	
	
	
	$leftX = MARGIN * 80;
	$x = $leftX;
	$y = 2 * MARGIN + ROWHEIGHT;
	$logofile = "../images/invoice" . ".png";
	if (!file_exists($logofile))
		$logofile = "../images/invoice.png";
	if (file_exists($logofile)) {
		$pdf->Image($logofile, MARGIN+3, MARGIN+5);
	$pdf = setLabelFont($pdf, true);
	}
	
	


	$leftX = MARGIN * 80;
	$x = $leftX;
	$y = 2 * MARGIN + ROWHEIGHT;
	
	
	$pdf = setCustomFont2($pdf, false);
	$pdf->Text(120, 12, ccs(tr("Q-Shop")));

  $pdf = setLabelFont($pdf, false);
	$pdf->Text(120, 16, ccs(tr("Head Office: House # 7 (GF)")));
	  $pdf = setLabelFont($pdf, false);
	$pdf->Text(120, 20, ccs(tr("NAVANA Garden,    Dhaka-1111")));
	  $pdf = setLabelFont($pdf, false);
	$pdf->Text(120, 24, ccs(tr("Hotline:   0172 951505 ")));
	  $pdf = setLabelFont($pdf, false);
	$pdf->Text(120, 28, ccs(tr("Email:          xxxx@yahoo.com")));
	 
	
	
	
	$logofile = "../images/companyname" . ".png";
	if (!file_exists($logofile))
		$logofile = "../images/companylogo.png";
	if (file_exists($logofile)) {
		$pdf->Image($logofile, MARGIN+85, MARGIN+1);
	 	echo "Image($logofile, MARGIN+1, MARGIN+1)";
		$pdf = setLabelFont($pdf, true);
		//$y += 12;
    $y=35;
    $x=10;		
	} else {
		$pdf = setLogoFont($pdf, true);
		$pdf->Text($x, $y, $company->companyname);
		$y += ROWHEIGHT;		
	}
  
		  
		   
	 
	
	$pdf = setLabelFont($pdf, false);
	$y += ROWHEIGHT;	
	$pdf = setLabelFont($pdf, false);
	$pdf->Text($x, $y, ccs(tr("Invoice No.") . ":"));
	$x1 = $x + 27;
	$pdf = setNormalFont($pdf, false);
	$pdf->Text($x1, $y, ccs($invoicefor)."-".ccs($order->orderid));
		$y += ROWHEIGHT;
	$pdf = setLabelFont($pdf, false);
	$pdf->Text($x, $y, ccs(tr("Date") . ":"));
	
	$x1 = $x+ 27;
	$pdf = setNormalFont($pdf, false);
	$pdf->Text($x1, $y, ccs($order->orderdate));
	
		$y += ROWHEIGHT;
	$x1 = $x+ 25;
	$pdf = setNormalFont($pdf, false);
$pdf->Text($x, $y, ccs(tr("Delivery Date") . ":"));

	
	$x1 = $x+ 27;
	$pdf = setNormalFont($pdf, false);
	$pdf->Text($x1, $y, ccs($order->deliverydate));
	
	
  $y += ROWHEIGHT;
  $x1 = $x+ 25;
	$pdf = setNormalFont($pdf, false);
$pdf->Text($x, $y, ccs(tr("Order Ref") . ":"));

	
	$x1 = $x+ 27;
	$pdf = setNormalFont($pdf, false);
	$pdf->Text($x1, $y, ccs($order->orderby));
	
	$y += ROWHEIGHT;	
	$x1 = $x+ 25;
	$pdf = setNormalFont($pdf, false);
$pdf->Text($x, $y, ccs(tr("Depo") . ":"));


	$x1 = $x+ 27;
	$pdf = setNormalFont($pdf, false);
	$pdf->Text($x1, $y, ccs($order->location));
	
	  
	
	$rightX = 120;
	$x = $rightX;
	$y = 2*MARGIN + ROWHEIGHT;	
	$pdf = setHeaderFont($pdf);
	switch ($type) {
		case 'invoice': $label = 'Invoice'; break;
		case 'receipt': $label = 'Receipt'; break;
		case 'credit': $label = 'Credit note'; break;
	}
	    $y += ROWHEIGHT;
	    $y += ROWHEIGHT;
 /* 
  $pdf->Text($x, $y, ccs(tr($label)));
	$pdf = setLabelFont($pdf);
	$label = "Order #";
	if ($type == 'invoice')
		$label = "Invoice #";
	$y += ROWHEIGHT;
	$pdf->Text($x, $y, ccs(tr($label)));
	$pdf = setNumericFont($pdf, true);
	$x += 25;
	$pdf->Text($x, $y, $order->no);
	$pdf = setLabelFont($pdf);
	$x = $rightX;
	$label = $type == 'invoice' ? "Invoice date" : "Receipt date";
	$y += ROWHEIGHT;
	$pdf->Text($x, $y, ccs(tr($label)) . ": ");
	$pdf = setNumericFont($pdf);
	$x += 25;
	$pdf->Text($x, $y, formatDate($order->invoicedate));
	$x = $rightX;
	$pdf = setLabelFont($pdf);
  if ($type == 'invoice') {
		$y += ROWHEIGHT;
		$pdf->Text($x, $y, ccs(tr("Due date") . ": "));
		$pdf = setNumericFont($pdf);
		$x += 25;
		$pdf->Text($x, $y, formatDate($order->duedate));
		$x = $rightX;
	}  */

	//$y += ROWHEIGHT;	
	//$x1 = $x+ 25;
	//$pdf = setNormalFont($pdf, false);
//$pdf->Text($x, $y, ccs(tr("Field Force") . ":"));
 
 $x1 = $x+ 25;
 $y=$y+10;
	 $y += ROWHEIGHT; 
	$pdf = setNormalFont($pdf, false);
  $pdf->Text($x, $y, ccs(tr("Customer ID") . ":"));
   
  
  $x1 = $x+ 25;
  $pdf->Text($x1, $y, ccs($order->customerid));

   
 
	
	 $x1 = $x+ 25;
	 $y += ROWHEIGHT; 
	$pdf = setNormalFont($pdf, false);
  $pdf->Text($x, $y, ccs(tr("Name") . ":"));

  $pdf = setNormalFont($pdf, true);
  $x1 = $x+ 25;
  $pdf->Text($x1, $y, ccs($customer->companyname));
  
   $x1 = $x+ 25;
	 $y += ROWHEIGHT; 
	$pdf = setNormalFont($pdf, false);
  $pdf->Text($x, $y, ccs(tr("Address")));

  
  $x1 = $x+ 25;
  $pdf->Text($x1, $y, ccs($order->streetaddress)); 
  
  
   $x1 = $x+ 25;
	 $y += ROWHEIGHT; 
	$pdf = setNormalFont($pdf, false);
  $pdf->Text($x, $y, ccs(tr("")));

  
  $x1 = $x+ 25;
  $pdf->Text($x1, $y,ccs($order->city)."-". ccs($order->zipcode )); 
  
  
   $x1 = $x+ 25;                  
	 $y += ROWHEIGHT; 
	$pdf = setNormalFont($pdf, false);
  $pdf->Text($x, $y, ccs(tr("Contact No.") . ":"));

  
  $x1 = $x+ 25;
  $pdf->Text($x1, $y, ccs($order->mainphone)); 
  
  
			$y += ROWHEIGHT;
	$x1 = $x+ 25;
	$pdf = setNormalFont($pdf, false);
$pdf->Text($x, $y, ccs(tr("Type") . ":"));

   
	$x1 = $x+ 25;
	$pdf = setNormalFont($pdf, false);
	$pdf->Text($x1, $y, ccs($salestype));
  
   	$y += ROWHEIGHT;
	$pdf->SetX(0);
	$pdf->SetY($y+ROWHEIGHT);

	$pdf = setLabelFont($pdf,true);
	$pdf->Cell(22, ROWHEIGHT, ccs(tr("  Product ID")), 1);
	$pdf->Cell(45, ROWHEIGHT, ccs(tr("            Product Name")), 1);
	$pdf->Cell(20, ROWHEIGHT, ccs(tr(" Pack Size")), 1);
	$pdf->Cell(20, ROWHEIGHT, ccs(tr("Quantity  ")), 1, 0, $rightAlign);
	$pdf->Cell(20, ROWHEIGHT, ccs(tr("Bonus Qty")), 1);
	$pdf->Cell(30, ROWHEIGHT, ccs(tr("Trade Price    ")), 1, 0, $rightAlign);
//	$pdf->Cell(20, ROWHEIGHT, ccs(tr("TP Total")), 1, 0, $rightAlign);
//	$pdf->Cell(11, ROWHEIGHT, ccs(tr("VAT")), 1, 0, $rightAlign);
//	$pdf->Cell(11, ROWHEIGHT, ccs(tr("Disc%")), 1, 0, $rightAlign);
//	$pdf->Cell(14, ROWHEIGHT, ccs(tr("Disc amt")), 1, 0, $rightAlign);
	//$pdf->Cell(17, ROWHEIGHT, ccs(tr("Other Disc.")), 1);	 
	$pdf->Cell(40, ROWHEIGHT, ccs(tr(" Total Amount       ")), 1, 1, $rightAlign);
	
	$subtotal=0;
	$totalvat=0;
	$totaldiscountprice=0;
  $totalother_disc=0;
  $discountamount=0;
                         
	while ($row = fetch($items)) {
		$pdf = setLabelFont($pdf);
		//$pdf->Cell(22, ROWHEIGHT, ccs($row->productid), 'LR');//Work Fine
		$pdf->Cell(22, ROWHEIGHT, "      $row->productid", 'L', 0, 'L');//Client Requirement
		
	  //	$pdf = setNormalFont($pdf);
		//$comment = ($row->comment)?" ($row->comment)":'';
		//$pdf->Cell(30, ROWHEIGHT, ccs($row->model).$comment, 'LR');
		
		$pdf->Cell(45, ROWHEIGHT, ccs($row->model), 'LR');
		$pdf->Cell(20, ROWHEIGHT, ccs($row->unittype), 'LR');
		
    $pdf = setNumericFont($pdf);
		//$pdf->Cell(20, ROWHEIGHT, ccs($row->quantity), 'LR', 0, 'R'); //Work Fine
		$pdf->Cell(20, ROWHEIGHT, "   $row->quantity", 'L', 0, 'L');//Client Requirement
		
    $pdf = setNumericFont($pdf);
		//$pdf->Cell(20, ROWHEIGHT, ccs($row->bonus_qnt), 'LR', 0, 'R');//Work Fine
		$pdf->Cell(20, ROWHEIGHT, "   $row->bonus_qnt", 'LR', 0, 'L');//Client Requirement
		
		$pdf = setNumericFont($pdf);
		$pdf->Cell(30, ROWHEIGHT, formatMoney(ccs($row->unitprice )), 'LR', 0, 'R');
		
    //$pdf = setNumericFont($pdf);
		//$pdf->Cell(20, ROWHEIGHT, formatMoney(ccs($row->unitprice * $row->quantity) ), 'LR', 0, 'R');
      
/*		$pdf = setNumericFont($pdf);
		$pdf->Cell(11, ROWHEIGHT, formatMoney(ccs($row->vat)), 'LR', 0, 'R');

		$pdf = setNumericFont($pdf);
		$pdf->Cell(11, ROWHEIGHT, ccs($row->discountprice), 'LR', 0, 'R');
		
    $discountamount =($row->discountprice/100)*($row->unitprice * $row->quantity);
     
    $pdf = setNumericFont($pdf);
		$pdf->Cell(14, ROWHEIGHT, formatMoney(ccs($discountamount)), 'LR', 0, 'R');
    			
		$pdf = setNumericFont($pdf);
		$pdf->Cell(17, ROWHEIGHT, formatMoney(ccs($row->other_disc)), 'LR', 0, 'R');
		
   */
	
	
    $total = ($row->unitprice * $row->quantity)-$discountamount-$row->other_disc+$row->vat;
	//$subtotal = $subtotal + $row->vat -($discountamount+$row->other_disc);
	
  
  
		//if ($incVAT)
		//	$unitprice += $row->vat;  
	//	$pdf->Cell(20, ROWHEIGHT, formatMoney($unitprice), 'LR', 0, 'R');
	  //$amount=(($row->unitprice*$row->quantity)-$row->discountprice-$row->other_disc);
	    
	
		
		$pdf->Cell(40, ROWHEIGHT, formatMoney($total), 'LR', 1, 'R');
		
  $totalvat+=$row->vat;
  $totaldiscountprice+=$discountamount;
  $totalother_disc+=$row->other_disc;
  $totalamount+=$total ;    //+$totalvat-$totaldiscountprice
  $subtotal+=$row->unitprice * $row->quantity;
		
}
 	$amount=(($row->unitprice*$row->quantity)-$discountamount-$row->other_disc);
		//$pdf = setLabelFont($pdf,false);
		$pdf = setNumericFont($pdf,true);
		$pdf->Cell(157, ROWHEIGHT, 'Subtotal', 1, 0, $rightAlign);
  	//$pdf->Cell(20, ROWHEIGHT, formatMoney($subtotal), 1, 0, $rightAlign);	
  //  $pdf->Cell(11, ROWHEIGHT,formatMoney($totalvat), 1, 0, $rightAlign);
//	  $pdf->Cell(11, ROWHEIGHT, '', 1, 0, $rightAlign);
//		$pdf->Cell(14, ROWHEIGHT, formatMoney($totaldiscountprice), 1, 0, $rightAlign);
//	  $pdf->Cell(, ROWHEIGHT, formatMoney($totalother_disc), 1, 0, $rightAlign);	 	 
	  $pdf->Cell(40, ROWHEIGHT, formatMoney($totalamount), 1, 1, $rightAlign);
    
		//	$top = '';  

      
		$pdf = setLabelFont($pdf, true);
  $pdf->Cell(89, ROWHEIGHT, '', '');
	$pdf->Cell(50, ROWHEIGHT, 'Discount', '', 0, 'R');
	$pdf->Cell(19, ROWHEIGHT, ' ('.ccs($overall_discount).'%):','',0, 'R');

	
	$pdf = setNumericFont($pdf,true);
	//$label = 'To pay';
//	if ($type == 'credit')
//		$label = 'To refund';
     $discountprice=$overall_discount/100*$totalamount;
	$pdf->Cell(40, ROWHEIGHT, formatMoney($discountprice), '', 1, $rightAlign);

	$pdf->Cell(98, ROWHEIGHT, '', '');
	$pdf->Cell(60, ROWHEIGHT, 'Special Discount:', '', 0, 'R');
	$pdf = setNumericFont($pdf,true);
	//$label = 'To pay';
//	if ($type == 'credit')
//		$label = 'To refund';
	$pdf->Cell(40, ROWHEIGHT, formatMoney($other_adjustment_amount), '', 1, $rightAlign);
		
 $netpay=$totalamount-$other_adjustment_amount-$discountprice;   
 $netpayamount=formatMoney($netpay); 
	$pdf->Cell(98, ROWHEIGHT, '', '');
	$pdf->Cell(60, ROWHEIGHT, "Net Payble Amount:", '', 0, 'R');
	$pdf = setNumericFont($pdf,true);
//	$label = 'To pay';
//	if ($type == 'credit')
//		$label = 'To refund';
	$pdf->Cell(40, ROWHEIGHT, formatMoney($netpay), 0, 1, $rightAlign);
	
		$pdf->Cell(13, ROWHEIGHT, '', 0, 1, $rightAlign);
		
			$pdf->Cell(13, ROWHEIGHT, '', 0, 1, $rightAlign);
			
				
	 
$inword = new Convert($netpay,'');
$pdf->Cell(2, 2, "Taka (in word): ".$inword->getAmount()." only",'', 1, 'L');


  $pdf->Cell(2, 3*ROWHEIGHT, 'Carton Qty:', '', 1);	
		
//$pdf = setNumericFont($pdf, true);
	/*$border = 'B';
	$showExchange = $type == 'receipt';
	if ($showExchange) {
		$payedGross = findValue("
		select sum(amount) from receipt_allocation 
		where orderid=$orderid and amount > 0");
	 	$exchange = $payedGross - $total - $vatTotal;
	 	if (round($exchange, 2) == 0)
	 		$showExchange = false;
	}
	if ($showExchange)
		$border = '';
	$pdf->Cell(30, ROWHEIGHT, formatMoney($total + $vatTotal), $border . 'RL', 1, 'R');
	if ($showExchange) {
		$pdf->Cell(100, ROWHEIGHT, '', '');
		$pdf->Cell(20, ROWHEIGHT, '', '', 0, 'R');
		$pdf = setLabelFont($pdf);
		$pdf->Cell(30, ROWHEIGHT, ccs(tr('Payed')), '', 0, 'R');
		$pdf = setNumericFont($pdf);
		$pdf->Cell(30, ROWHEIGHT, formatMoney($payedGross), 'RL', 1, 'R');
		$pdf->Cell(100, ROWHEIGHT, '', '');
		$pdf->Cell(20, ROWHEIGHT, '', '', 0, 'R');
		$pdf = setLabelFont($pdf);
		$pdf->Cell(30, ROWHEIGHT, ccs(tr('Exchange')), '', 0, 'R');
		$pdf = setNumericFont($pdf);
		$pdf->Cell(30, ROWHEIGHT, formatMoney($exchange), 'BRL', 1, 'R');
	}
	$pdf->Cell(100, 2*ROWHEIGHT, '', '', 1);
	$pdf = setLabelFont($pdf);
//	if ($type == 'receipt') {
		*/

		$pdf->Cell(100, 10*ROWHEIGHT, '', '', 1);
	   $pdf->Cell(50, ROWHEIGHT,  '___________________', '');
		$pdf->Cell(50, ROWHEIGHT, '___________________', '');
		
		$pdf->Cell(50, ROWHEIGHT, '___________________', '');
		$pdf->Cell(50, ROWHEIGHT, '___________________', '', 1);
  
  	
    $pdf->Cell(50, ROWHEIGHT, ccs(tr('Customer\'s signature')), '');
		$pdf->Cell(50, ROWHEIGHT, ccs(tr('         Prepared By')), '');
    
    $pdf->Cell(50, ROWHEIGHT, ccs(tr('         Delivered By')), '');
		$pdf->Cell(50, ROWHEIGHT, ccs(tr(' Authorized Signature')), '', 1);		
		
		$pdf->Cell(100, 2*ROWHEIGHT, '', '', 1);	
		
/*	} else if ($type == 'invoice') {
		$comment = findValue("select comment from salesorder where orderid=$orderid", null);
		$pdf = setNormalFont($pdf);
		if ($comment != null) {
			$pdf->Cell(200, ROWHEIGHT, ccs($comment), '', 1);
		}
	*/	$rs = query("select text from invoice_footer order by rowno");
		while ($row = fetch($rs)) {
			$pdf->Cell(200, ROWHEIGHT, ccs($row->text), '', 1);
		}
	//}
	
	$dest = '';
	if (!isEmpty($filename)) {
		$dest = 'F';
	}
	$pdf->Output($filename, $dest);
}

?>