<?php
	include('include.php');

    $model = getParam('model');
    $locationid = getParam('locationid');
	$type = getParam('type', TYPE_MONTHS);
	
	
	$starttime = parseDate(getParam('starttime'));
	if (isEmpty($starttime))
		$starttime = roundTime(time(), TYPE_MONTHS);
	$endtime = parseDate(getParam('endtime'));
	if (isEmpty($endtime))
		$endtime = addTime($starttime, TYPE_MONTHS);
	
	
	
	
//	$start=1257033600;
	
	//$end=1257465600;

	//$locationSQL = "1=1";
	if (!isEmpty($locationid)) {
		$locationSQL = "locationid=$locationid";
	}	else
		$locationSQL = "1=1";
	//supplier_price price	

	$selectSQL = "
			select
	    p.productid,
	    model,
	    (select sum(soi.quantity)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and orderdate between from_unixtime($starttime) and from_unixtime($endtime)
	     where soi.productid=p.productid and $locationSQL) as quantity,
	    (select sum(soi.quantity*soi.unitprice)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and orderdate between from_unixtime($starttime) and from_unixtime($endtime)
	     where soi.productid=p.productid and $locationSQL) as revenue
	     from product p
	where model like '$model%'
	and productid not in (" . PRODUCTID_UNSPECIFIED . ", " . PRODUCTID_ROUNDING . ")
	";
	 
	$locations = rs2array(query("select locationid, name from location"));	

?>

<head>
<title>ICS System Solutions - <?php etr("Sales analysis") ?></title>
<?php
styleSheet();
include_datebox();
?>
</head>

<body>

<?php menubar('index.php') ?>
<?php title(tr("Sales analysis")) ?>


<form name=searchform action="revienew_analysis_dated.php" method="GET">
<div class="border">
<center>
<table  class='main'>
<tr>
<td><?php etr("Product") ?>:</td><td><?php textbox('model', $model) ?></td><td width=20/>
<td><?php etr("Location") ?>:</td><td><?php combobox('locationid', $locations, $locationid, true) ?></td>
<td>&nbsp;</td>
</tr>
<tr>
	<td><?php etr("Interval") ?>:</td>
	<td>
		<?php datebox("starttime", formatDate($starttime)) ?>
		<?php datebox("endtime", formatDate($endtime)) ?>
	</td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td><?php searchButton() ?>	</td>
</tr>
</table>
</center>
</div>
</form>
&nbsp;

<center>
<input type=hidden name=orderid value='<?php echo $orderid ?>'/>
<table  class='main'>
<th><?php etr("Productno") ?></th>
<th><?php etr("Product") ?></th>
<th><?php etr("Quantity") ?></th>
<th><?php etr("Sales Unit Price") ?></th>
<th><?php etr("Sales Price") ?></th>
<th><?php etr("Purchase Unit Price") ?></th>
<th><?php etr("Purchase Price") ?></th>
<th><?php etr("Revenue") ?></th>


<?php
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
    	$href = "../erp/product.php?productid=$row->productid";
        echo "<tr class='$class'>";
        echo "<td>$row->productid</td>";
        echo "<td><a href='$href'>$row->model</a></td>";
		$href = "sales.php?productid=$row->productid&starttime=$start&endtime=$end";
        echo "<td align=right><a href='$href'>$row->quantity</a></td>";
      echo "<td align=right><a href='$href'>". formatMoney($row->revenue)/$row->quantity ."</a></td>";
        echo "<td align=right><a href='$href'>" . formatMoney($row->revenue) . "</a></td>";
              
  $rs1 = query("SELECT sum(`purchaseorder_item`.`unitprice`) AS `price`,
                           sum(`purchaseorder_item`.`quantity`) AS `quantity`
                          FROM
                          `purchaseorder_item`
                          Inner Join `product` ON `product`.`productid` = `purchaseorder_item`.`productid`
                          where `purchaseorder_item`.productid=$row->productid
                            group by  `purchaseorder_item`.`unitprice`,`purchaseorder_item`.`quantity`");
           $total=0;
           $total_qty=0;               
	        while ($row1 = fetch_object($rs1)){
          
             //formatMoney($row1->price)/$row1->quantity;
                 $total+= $row1->price *$row1->quantity;
                 $total_qty+= $row1->quantity ;
                 
          }
	        
	          
	        
      echo "<td align=right>"; 
          //$purchase_avg_price=$row1->price/$row1->quantity;
	          echo  formatMoney($total/$total_qty,2);
             
          //  echo "AAAA $purchase_avg_price BBBBB";     
       // $purchase_avg_price=formatMoney($row1->price)/$row1->quantity;
        echo "</td>";
        
        echo "<td align=right>";
        //echo $purchase_price; 
                 
            $purchase_avg_price=($total/$total_qty)*$row->quantity;
            
            echo formatMoney($purchase_avg_price,2); 
       // echo formatMoney($purchase_price)*$row->quantity;
        echo "</td>";
        echo "<td align=right><a href='$href'>"; 
         $netrevenue=formatMoney($row->revenue-$purchase_avg_price); 
         
            echo  $netrevenue;
        echo "</a></td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table>
</center>
<?php bottom() ?>
</body>
