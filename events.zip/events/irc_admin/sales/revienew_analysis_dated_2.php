<?php
	include('include.php');

    $model = getParam('model');
    $locationid = getParam('locationid');
	$type = getParam('type', TYPE_MONTHS);
	
	
	$starttime = parseDate(getParam('starttime'));
	if (isEmpty($starttime))
		$starttime = roundTime(time(), TYPE_MONTHS);
	$endtime = parseDate(getParam('endtime'));
	if (isEmpty($endtime))
		$endtime = addTime($starttime, TYPE_MONTHS);
	
	
	
	
//	$start=1257033600;
	
	//$end=1257465600;

	//$locationSQL = "1=1";
	if (!isEmpty($locationid)) {
		$locationSQL = "locationid=$locationid";
	}	else
		$locationSQL = "1=1";
	//supplier_price price	

	$selectSQL = "
			select
	    p.productid,
	    model,
	    (select sum(soi.quantity)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and orderdate between from_unixtime($starttime) and from_unixtime($endtime)
	     where soi.productid=p.productid and $locationSQL) as quantity,
	    (select sum(soi.quantity*soi.unitprice)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and orderdate between from_unixtime($starttime) and from_unixtime($endtime)
	     where soi.productid=p.productid and $locationSQL) as revenue
	     from product p
	where model like '$model%'
	and productid not in (" . PRODUCTID_UNSPECIFIED . ", " . PRODUCTID_ROUNDING . ")
	";
	 
	$locations = rs2array(query("select locationid, name from location"));	

?>

<head>
<title>ICS System Solutions - <?php etr("Sales analysis") ?></title>
<?php
styleSheet();
include_datebox();
?>
</head>

<body>

<?php menubar('index.php') ?>
<?php title(tr("Sales analysis")) ?>


<form name=searchform action="revienew_analysis_dated.php" method="GET">
<div class="border">
<center>
<table  class='main'>
<tr>
<td><?php etr("Product") ?>:</td><td><?php textbox('model', $model) ?></td><td width=20/>
<td><?php etr("Location") ?>:</td><td><?php combobox('locationid', $locations, $locationid, true) ?></td>
<td>&nbsp;</td>
</tr>
<tr>
	<td><?php etr("Interval") ?>:</td>
	<td>
		<?php datebox("starttime", formatDate($starttime)) ?>
		<?php datebox("endtime", formatDate($endtime)) ?>
	</td>
</tr>
<tr>
	<td>&nbsp;</td>
	<td><?php searchButton() ?>	</td>
</tr>
</table>
</center>
</div>
</form>
&nbsp;

<center>
<input type=hidden name=orderid value='<?php echo $orderid ?>'/>
<table  class='main'>
<th><?php etr("Productno") ?></th>
<th><?php etr("Product") ?></th>
<th><?php etr("Quantity") ?></th>
<th><?php etr("Sales Unit Price") ?></th>
<th><?php etr("Sales Price") ?></th>
<th><?php etr("Purchase Unit Price") ?></th>
<th><?php etr("Purchase Price") ?></th>
<th><?php etr("Revenue") ?></th>


<?php
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
    	$href = "../erp/product.php?productid=$row->productid";
        echo "<tr class='$class'>";
        echo "<td>$row->productid</td>";
        echo "<td><a href='$href'>$row->model</a></td>";
		$href = "sales.php?productid=$row->productid&starttime=$start&endtime=$end";
        echo "<td align=right><a href='$href'>$row->quantity</a></td>";
      echo "<td align=right><a href='$href'>". formatMoney($row->revenue)/$row->quantity ."</a></td>";
        echo "<td align=right><a href='$href'>" . formatMoney($row->revenue) . "</a></td>";
        
$purchase_price=findValue("SELECT
                          Avg(`supplier_price`.`price`) AS `supplier_price`
                          FROM
                          `supplier_price`
                          Inner Join `product` ON `product`.`productid` = `supplier_price`.`productid`
                          where `supplier_price`.productid=$row->productid
                          group by  `supplier_price`.`productid`");
	
      echo "<td align=right>"; 
        echo formatMoney($purchase_price);
        echo "</td>";
        
        echo "<td align=right>";
        //echo $purchase_price; 
        $netrevenue=formatMoney($purchase_price)*$row->quantity;
        echo formatMoney($purchase_price)*$row->quantity;
        echo "</td>";
        echo "<td align=right><a href='$href'>"; 
        echo formatMoney($row->revenue)-$netrevenue; 
        echo "</a></td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table>
</center>
<?php bottom() ?>
</body>
