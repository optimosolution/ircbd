<?php
	include('include.php');
	include('salesorder.inc.php');

	$receiptid_bool =false;   // THIS BOOLEAN IS USED FOR HANDLING RECEIPTID
	$receiptid = getParam('receiptid');
	
	$moneyreceiptno= getParam('moneyreceiptno');
 
	if ($receiptid != "")
		{
		  $receiptid_bool =true;
		}
	$new = true;
	$customerid = getParam('customerid');
	$amount = getParam('amount');
	$receiptdate = time();
	$transid = null;
	$accountid = getParam('accountid');

	if (isSave()) {
		if (isNew()) {
			$receiptid = tx("create_receipt", array($customerid, $amount, $accountid,$moneyreceiptno));
		} else {
			$count = getParam('count');
			$i = 0;
			while ($i < $count) {
				$orderid = getParam("orderid_$i");
				$allocation = getParam("allocation_$i");
				$old_allocation = getParam("old_allocation_$i");
				if ($allocation != $old_allocation) {
					sql("update receipt_allocation set amount=$allocation
					     where orderid=$orderid and receiptid=$receiptid");
					if (affected_rows() == 0) {
						sql("insert into receipt_allocation (orderid, receiptid, amount) 
						     values ($orderid, $receiptid, $allocation)");
					}
				}
				if (getParam("allocate_all_$i") == 1) {
					sql("delete from receipt_allocation where receiptid=$receiptid and orderid=$orderid");
					sql("insert into receipt_allocation (receiptid, orderid, amount) 
					     select $receiptid, $orderid, amount
						 from receipt where receiptid=$receiptid");
				}
				$i++;
			}
		}
	}


	if (!isEmpty($receiptid)) {
	    $sql =
  		"select receiptid,
  		       unix_timestamp(transtime) as receiptdate,
		       customerid,
		       p.transactionid, 
			   p.amount,
			   accountid as bankaccount
		from receipt p
		join transaction t on t.transactionid=p.transactionid
		join transaction_part tp on tp.transactionid=t.transactionid 
		where receiptid=$receiptid
		";
		$rec = find($sql);
		if ($rec != null) {
			$receiptid = $rec->receiptid;
			$customerid = $rec->customerid;
			$receiptdate = $rec->receiptdate;
			$transid = $rec->transactionid;
			$amount = $rec->amount;
			$bankaccount = $rec->bankaccount;
			$new = false;
		}
	}

	$customer = null;
	if (!isEmpty($customerid)) {
		$customer = find("select companyname from customer where customerid=$customerid");
	 }
	
	$orders = null;
	$leftToAllocate = null;
	if (!$new) {
		$orders = query("
SELECT
so.orderid,so.orderdate,so.customerid,si2.totalamount,pa.allocated,(si2.totalamount -(si.topay*so.disc+so.adjust)-si2.otherdisc) as Total2Pay
FROM
(select orderid,orderdate,customerid,invoice_transid,cancelled, sum(discount/100)as disc,sum(other_adjustment) as adjust from salesorder group by orderid) as so
Inner Join(select orderid,sum((quantity * unitprice+vat/100)) as topay  from salesorder_item where other_disc=0 group by orderid) as si
on so.orderid = si.orderid
Inner Join(select orderid,sum(other_disc) as otherdisc, sum((quantity * unitprice+vat/100)) as totalamount  from salesorder_item  group by orderid) as si2
on so.orderid = si2.orderid
Left Join (select orderid,receiptid, sum(amount) as allocated from receipt_allocation group by orderid) as pa
on so.orderid = pa.orderid
where so.customerid=$customerid
and so.invoice_transid is not null and so.cancelled != 1
having allocated != si2.totalamount or allocated is null
");
		$allocated = findValue("select sum(amount) from receipt_allocation
		                        where receiptid=$receiptid");
								
		$leftToAllocate = $amount - $allocated;
		
	}

	$bankaccounts = rs2array(query("
	select a.accountid, name
	from account a 
	join account_group ag on ag.dimid=a.dimid and ag.accountid=a.accountid
	where  a.accountid=1010 or a.dimid=1 and ag.groupid = " . GROUPID_BANK_ACCOUNTS));
?>

<head>
<title>ICS System Solutions - <?php etr("Receipt") ?></title>
<?php styleSheet() ?>
</head>

<body>
<?php menubar("index.php") ?>
<?php 
$title = $receiptid;
if ($new) $title = tr("New");
title("<a href='receipts.php'>" . tr("Receipts") . "</a> > $title") 
?>

<form action="receipt.php" method="POST">
<input type=hidden name=customerid value='<?php echo $customerid ?>'/>
<table>
<?php
	if (!$new) {
		echo "<tr><td class=label>" . tr("Receipt id") . ":</td>";
		echo "<td>";
		echo $receiptid;
		echo "<input type='hidden' name='receiptid' value='$receiptid'/>";
		echo "</td>";
	}
?>
<tr><td class=label><?php etr("Customer") ?>:</td><td><?php echo $customer->companyname ?></td>
<tr><td class=label><?php etr("Date") ?>:</td><td><?php echo date(DATE_PATTERN, $receiptdate) ?></td></tr>
<tr>
	<td class=label><?php etr("Amount") ?>:</td>
	<td>
	<?php 
	if ($new)
		echo "<input type=text name=amount value='$amount'/>";
	else	
		echo $amount;
	?>
	</td>
</tr>
<tr>
	<td class=label><?php etr("Account") ?>:</td>
	<td><?php comboBox('accountid', $bankaccounts, $accountid, false, !$new) ?></td>
	</td>
</tr>
<tr>
	<td class=label><?php etr("Money Receipt No.") ?>:</td>
	<td><input type=text name=moneyreceiptno value='<?php echo $moneyreceiptno; ?>' ></td>
	</td>
</tr>
	
</tr>
<?php
if (!$new) {
	echo "<tr>";
	echo "<td colspan=2><a href='../accounting/transaction.php?transactionid=$transid'>General ledger transaction</a></td>";
	echo "</tr>";
}

?>
</table>
<br/>
<?php 
if ($orders != null && $receiptid_bool == true) { 
	echo "<p>Left to allocate: $leftToAllocate</p>";
	echo "<table>";
	echo "<th>" . tr("Sales order") . "</th>";
	echo "<th>" . tr("Order Date") . "</th>";
	echo "<th>" . tr("Amount") . "</th>";
	echo "<th>" . tr("Previous allocations") . "</th>";
	echo "<th>" . tr("Due Amount") . "</th>";
	$class = 'odd';
	$i = 0;
	while ($row = fetch($orders)) {
		$totalamount = $row->Total2Pay;
		$allocated = $row->allocated;
		$dueamount = $totalamount - $allocated;
		echo "<input type=hidden name=orderid_$i value='$row->orderid'/>";
		echo "<tr class='$class'>";
		echo "<td><a href='salesorder.php?orderid=$row->orderid'>$row->orderid</a></td>";
		echo "<td>$row->orderdate</td>";
		echo "<td align=right>$row->Total2Pay</td>";
		echo "<td align=right>$row->allocated</td>";
		echo "<td align=right>$dueamount</td>";
		echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
		$i++;
	}
	echo "</table>";
	echo "<input type=hidden name=count value='$i' />";
}
else

if ($orders != null) { 
	echo "<p>Left to allocate: $leftToAllocate</p>";
	echo "<table>";
	echo "<th>" . tr("Sales order") . "</th>";
		echo "<th>" . tr("Order Date") . "</th>";
	echo "<th>" . tr("Amount") . "</th>";
	echo "<th>" . tr("Previous allocations") . "</th>";
	echo "<th>" . tr("Due Amount") . "</th>";
	echo "<th>" . tr("Allocated all") . "</th>";
	echo "<th>" . tr("Allocation") . "</th>";
	$class = 'odd';
	$i = 0;
	while ($row = fetch($orders)) {
		$totalamount = $row->Total2Pay;
		$allocated = $row->allocated;
		$dueamount = $totalamount - $allocated;
		echo "<input type=hidden name=orderid_$i value='$row->orderid'/>";
		echo "<tr class='$class'>";
		echo "<td><a href='salesorder.php?orderid=$row->orderid'>$row->orderid</a></td>";
		echo "<td>$row->orderdate</td>";
		echo "<td align=right>$row->Total2Pay</td>";
		echo "<td align=right>$row->allocated</td>";
		echo "<td align=right>$dueamount</td>";
		echo "<td align=center><input type=checkbox name='allocate_all_$i' value='1'/></td>";
		echo "<td><input type=text name=allocation_$i value='$row->allocation'/></td>";
		echo "<input type=hidden name=old_allocation_$i value='$row->allocation'/>";
		echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
		$i++;
	}
	echo "</table>";
	echo "<input type=hidden name=count value='$i' />";
  }


?>
<br>
<?php button("Save", "save") ?>

<input type="hidden" name="new" value="<?php echo $new ?>"/>
</form>
<?php bottom() ?>
</body>
