<?php include("include.php") ?>

<head>
<title>ICS System Solutions - <?php etr("Sales") ?></title>
<?php styleSheet() ?>
</head>

<body>

<div class=main>
<table width="100%" cellspacing=0 cellpadding=0>
<tr class=menubar><td style="padding: 2"></td></tr>
</table>
<?php 

menubar('index.php', 'index_help.php');
//menupage_begin();
?>
<table>
<tr>
  <th bgcolor="#000000"><span class="style1">Product No</span></th>
<th bgcolor="#000000"><span class="style1">Product</span></th>
<th bgcolor="#000000"><span class="style1">Pack Size</span></th>
<th bgcolor="#000000"><span class="style1">Refund Amount </span></th>
 
<th bgcolor="#000000"><span class="style1">Quantity</span></th>
<tr class='even'>
  <td colspan="5">&nbsp;</td>
</tr>
<tr bgcolor="#D8D3D1" class='even'>
  <td colspan="5"><strong>Dated: 28-05-2010 </strong></td>
  </tr>
<tr class='even'>
  <td>1007</td><td><a href='product.php?productid=1007'>Amicox-1 kg </a></td><td align=right>50 gm</td>
  <td align=right>     100.00</td><td align=right><a href='stockmoves.php?productid=1007&locationid=' class=sum>283</a></td></tr><tr class='odd'>
    <td bgcolor="#D8D3D1">1006</td>
    <td bgcolor="#D8D3D1"><a href='product.php?productid=1006'>Amicox-100 gm </a></td>
    <td align=right bgcolor="#D8D3D1">50 gm</td>
    <td align=right bgcolor="#D8D3D1">     300.00</td>
    <td align=right bgcolor="#D8D3D1"><a href='stockmoves.php?productid=1006&locationid=' class=sum>20</a></td>
  </tr><tr class='even'>
      <td>1008</td><td><a href='product.php?productid=1008'>Caldivet D3-100 gm </a></td><td align=right>50 gm</td>
      <td align=right>     50.00</td><td align=right><a href='stockmoves.php?productid=1008&locationid=' class=sum>101</a></td></tr><tr class='odd'>
        <td bgcolor="#D8D3D1">1009</td>
        <td bgcolor="#D8D3D1"><a href='product.php?productid=1009'>Caldivet D4-1 kg </a></td>
        <td align=right bgcolor="#D8D3D1">50 gm</td>
        <td align=right bgcolor="#D8D3D1">     500.00</td>
        <td align=right bgcolor="#D8D3D1"><a href='stockmoves.php?productid=1009&locationid=' class=sum>16</a></td>
      </tr>
      <tr class='even'>
        <td colspan="5"><strong>Dated: 27-05-2010 </strong></td>
      </tr>
      <tr class='even'>
        <td bgcolor="#D8D3D1">1013</td><td bgcolor="#D8D3D1"><a href='product.php?productid=1013'>Calphovet Liquid-1 lt </a></td><td align=right bgcolor="#D8D3D1">50 gm</td>
        <td align=right bgcolor="#D8D3D1">     1000.00</td><td align=right bgcolor="#D8D3D1"><a href='stockmoves.php?productid=1013&locationid=' class=sum>243</a></td></tr><tr class='odd'>
          <td>1010</td><td><a href='product.php?productid=1010'>Calphovet Liquid-100 ml </a></td><td align=right>50 gm</td>
          <td align=right>     1500.00</td><td align=right><a href='stockmoves.php?productid=1010&locationid=' class=sum>89</a></td></tr><tr class='even'>
            <td bgcolor="#D8D3D1">1011</td><td bgcolor="#D8D3D1"><a href='product.php?productid=1011'>Calphovet Liquid-250 ml </a></td><td align=right bgcolor="#D8D3D1">50 gm</td>
            <td align=right bgcolor="#D8D3D1">     154.00</td><td align=right bgcolor="#D8D3D1"><a href='stockmoves.php?productid=1011&locationid=' class=sum>9</a></td></tr><tr class='odd'>
              <td>1012</td><td><a href='product.php?productid=1012'>Calphovet Liquid-500ml </a></td><td align=right>50 gm</td>
              <td align=right>     567.00</td><td align=right><a href='stockmoves.php?productid=1012&locationid=' class=sum>14</a></td></tr><tr class='even'>
                <td bgcolor="#D8D3D1">1017</td><td bgcolor="#D8D3D1"><a href='product.php?productid=1017'>Calphovet plus-1lt </a></td><td align=right bgcolor="#D8D3D1">50 gm</td>
                <td align=right bgcolor="#D8D3D1">679.00</td><td align=right bgcolor="#D8D3D1"><a href='stockmoves.php?productid=1017&locationid=' class=sum>20</a></td></tr>
              <tr class='odd'>
                <td colspan="5"><strong>Dated: 26-05-2010 </strong></td>
              </tr>
              <tr class='odd'>
                <td>1015</td><td><a href='product.php?productid=1015'>Calphovet plus-250 ml </a></td><td align=right>50 gm</td>
                <td align=right>     2700.00</td><td align=right><a href='stockmoves.php?productid=1015&locationid=' class=sum>27</a></td></tr><tr class='even'>
                  <td bgcolor="#D8D3D1">1016</td><td bgcolor="#D8D3D1"><a href='product.php?productid=1016'>Calphovet plus-500ml </a></td><td align=right bgcolor="#D8D3D1">50 gm</td>
                  <td align=right bgcolor="#D8D3D1">     500.00</td><td align=right bgcolor="#D8D3D1"><a href='stockmoves.php?productid=1016&locationid=' class=sum>23</a></td></tr><tr class='odd'>
                    <td>1021</td><td><a href='product.php?productid=1021'>CF - 10 Liquid-1 lt </a></td><td align=right>50 gm</td>
                    <td align=right>     480.00</td>
                    <td align=right><a href='stockmoves.php?productid=1021&locationid=' class=sum>34</a></td></tr><tr class='even'>
                      <td bgcolor="#D8D3D1">1019</td><td bgcolor="#D8D3D1"><a href='product.php?productid=1019'>CF - 10 Liquid-100ml </a></td><td align=right bgcolor="#D8D3D1">50 gm</td>
                      <td align=right bgcolor="#D8D3D1">     208.00</td><td align=right bgcolor="#D8D3D1"><a href='stockmoves.php?productid=1019&locationid=' class=sum>2</a></td></tr><tr class='odd'>
                        <td>1020</td><td><a href='product.php?productid=1020'>CF - 10 Liquid-500ml </a></td><td align=right>50 gm</td>
                        <td align=right>     347.00</td><td align=right><a href='stockmoves.php?productid=1020&locationid=' class=sum>34</a></td></tr>
                      <tr bgcolor="#D8D3D1" class='even'>
                        <td colspan="5"><strong>Dated: 24-05-2010 </strong></td>
                      </tr>
                      <tr class='even'>
                        <td>1018</td><td><a href='product.php?productid=1018'>CF - 10 Powder-100gm </a></td><td align=right>50 gm</td>
                        <td align=right>     985.00</td><td align=right><a href='stockmoves.php?productid=1018&locationid=' class=sum>5</a></td></tr><tr class='odd'>
                          <td bgcolor="#D8D3D1">1023</td>
                          <td bgcolor="#D8D3D1"><a href='product.php?productid=1023'>Cinavet-1 lt </a></td>
                          <td align=right bgcolor="#D8D3D1">50 gm</td>
                          <td align=right bgcolor="#D8D3D1">     876.00</td>
                          <td align=right bgcolor="#D8D3D1"><a href='stockmoves.php?productid=1023&locationid=' class=sum>5</a></td>
                        </tr><tr class='even'>
                            <td>1022</td><td><a href='product.php?productid=1022'>Cinavet-100ml </a></td><td align=right>50 gm</td>
                            <td align=right>     900.00</td>
                            <td align=right><a href='stockmoves.php?productid=1022&locationid=' class=sum>3</a></td></tr><tr class='odd'>
                              <td bgcolor="#D8D3D1">1026</td>
                              <td bgcolor="#D8D3D1"><a href='product.php?productid=1026'>Coccivet Liquido-1 lt </a></td>
                              <td align=right bgcolor="#D8D3D1">50 gm</td>
                              <td align=right bgcolor="#D8D3D1">     474.00</td>
                              <td align=right bgcolor="#D8D3D1"><a href='stockmoves.php?productid=1026&locationid=' class=sum>7</a></td>
                            </tr><tr class='even'>
                                <td>1024</td><td><a href='product.php?productid=1024'>Coccivet Liquido-100 ml </a></td><td align=right>50 gm</td>
                                <td align=right>     477.00</td>
                                <td align=right><a href='stockmoves.php?productid=1024&locationid=' class=sum>89</a></td></tr><tr bgcolor="#D8D3D1" class='odd'>
                                  <td>1025</td>
                                  <td><a href='product.php?productid=1025'>Coccivet Liquido-250 ml </a></td>
                                  <td align=right>50 gm</td>
                                  <td align=right>     755.00</td>
                                  <td align=right><a href='stockmoves.php?productid=1025&locationid=' class=sum>33</a></td>
                                </tr><tr class='even'>
                                    <td>1014</td><td><a href='product.php?productid=1014'>DCP -25kg </a></td><td align=right>50 gm</td>
                                    <td align=right>     1800.00</td>
                                    <td align=right><a href='stockmoves.php?productid=1014&locationid=' class=sum>87</a></td></tr><tr bgcolor="#D8D3D1" class='odd'>
                                      <td>1333</td>
                                      <td><a href='product.php?productid=1333'>dfdcfd </a></td>
                                      <td align=right>50 gm</td>
<td align=right>     568.00</td>
<td align=right><a href='stockmoves.php?productid=1333&locationid=' class=sum>98</a></td>
                                    </tr></table>
<p><strong><a href="salesorder_refund.html">Previous Product List </a></strong></p>


<?php bottom(); // menupage_end() 
 
?>
<?php //menupage_end() ?>
</div>
</body>