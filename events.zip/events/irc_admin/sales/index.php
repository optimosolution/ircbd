<?php include("include.php") ?>       
 
<head>
<title>ICS System Solutions - <?php etr("Sales") ?></title>
<?php styleSheet() ?>
</head>

<body>

<div class=main>

 
<?php

menubar('index.php', 'index_help.php');  
//menupage_begin();
?>


<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="20%"valign='top'>
    <?php
    include('../res/calendar_code.php');
    ?>


    <br><br><br><br>

    News from Service center.


    </td>
    <td width="80%">

<ul>
<!--
<li class=menupage>
<a href='salesorder.php?customerid=1&action=create' id='newcacheorder' tabindex=1 accesskey='C' class=menupage
	title='<?php etr("toolTip_newCashSalesOrder")?>'>
<?php etr("New cash sales order") ?>
</a>
</li>
<script>document.getElementById('newcacheorder').focus();</script>
-->
<li class=menupage>
<a href='customers.php?mode=createorder' tabindex=2 accesskey='O' class=menupage
   title='<?php etr("toolTip_newSalesOrder")?>'>
<?php etr("Invoice") ?>
</a>
</li>
<!--
<li class=menupage>
<a href='posclient.php' class=menupage>
<?php etr("Point-of-sales") ?>
</a>
</li>

<li class=menupage>
<a href='customers.php?mode=createorder&recur=1' tabindex=3 class=menupage
	title='<?php etr("toolTip_newRecurringSalesOrder")?>'>
<?php etr("New recurring sales order") ?>
</a>
</li>
 -->
<li class=menupage>
<a href='receipts.php' class=menupage title='<?php etr("toolTip_receipts")?>'>
<?php etr("Receipts") ?>
</a>
</li>
<li class=menupage><a href='sales.php' class=menupage title='<?php etr("toolTip_showSalesOrders")?>'>
<?php etr("Show All Requisition") ?></a></li>
<li class=menupage><a href='sales_analysis.php' class=menupage title='<?php etr("toolTip_salesAnalysis")?>'>
<?php etr("Requisition Analysis") ?></a></li>
<li class=menupage><a href='customers.php?mode=createorder&salesorder=return' class=menupage title='<?php etr("toolTip_SalesOrdersReturn")?>'>
<?php etr("Return Requisition Order") ?>
</a>
</li>
<!--
<li class=menupage><a href='sales_refund.php' class=menupage title='<?php etr("toolTip_showSalesOrders")?>'>
<?php etr("Return / Refund") ?>
</a>
</li>
-->
<li class=menupage><a href='../erp/product_lowlevel.php' class=menupage title='<?php etr("toolTip_showSalesOrders")?>'>
<?php etr("Product Lowlevel") ?>
</a>
</li>

<!-- <li class=menupage><a href='sales_analysis_2.php' class=menupage title='<?php etr("toolTip_showSalesOrders")?>'>
<?php etr("Search Records") ?>
</a>
</li> -->
</ul>

    </td>
  </tr>
</table>


<?php bottom(); // menupage_end()

?>
<?php //menupage_end() ?>
</div>
</body>
