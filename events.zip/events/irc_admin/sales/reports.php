<?php include("include.php") ?>

<head>
<title>ICS System Solutions - <?php etr("Sales") ?></title>
<?php styleSheet() ?>
</head>

<body>

<div class=main>
<table width="100%" cellspacing=0 cellpadding=0>
<tr class=menubar><td style="padding: 2"></td></tr>
</table>
<?php 

menubar('index.php', 'index_help.php');
//menupage_begin();
?>


<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="20%"valign='top'>
    <?php
    include('../res/calendar_code.php');
    ?>
    
   
    <br><br><br><br>
    
    </td>
    <td width="80%">

<ul>
<li class=menupage>
<a href='product_lowlevel.php' id='newcacheorder' tabindex=1 accesskey='C' class=menupage
	title='<?php etr("Low level report")?>'>
<?php etr("Low level product list") ?>
</a>
</li>
<script>document.getElementById('newcacheorder').focus();</script>
<li class=menupage>
<a href='salesorder_refund.php' tabindex=2 accesskey='O' class=menupage
   title='<?php etr("salesorder_refund")?>'>
<?php etr("Salesorder Refund/Return") ?>
</a>
</li>

 
<li class=menupage>
<a href='receipts.php' tabindex=3 class=menupage
	title='<?php etr("Receipt from Customer")?>'>
<?php etr("Receipt from Customer") ?>
</a>
</li>
 
<li class=menupage>
<a href='revienew_analysis_dated.php' tabindex=3 class=menupage
	title='<?php etr("revienew_analysis_dated")?>'>
<?php etr("Revienew Analysis") ?>
</a>
</li>         

<li class=menupage>
<a href=' revienew_analysis_dated_2.php' tabindex=3 class=menupage
	title='<?php etr("revienew_analysis_2")?>'>
<?php etr("Revienew Analysis 2") ?>
</a>
</li> 
 
 <li class=menupage><a href='sales_analysis_dated.php' class=menupage title='<?php etr("toolTip_salesAnalysis day wise")?>'>
<?php etr("Sales analysis day wise") ?></a></li>
<li class=menupage>
<a href='sales_analysis_2.php' class=menupage title='<?php etr("toolTip_receipts")?>'>
<?php etr("Sales Analysis 2") ?>
</a>
</li>
<li class=menupage><a href='sales.php' class=menupage title='<?php etr("toolTip_showSalesOrders")?>'>
<?php etr("Show sales orders") ?></a></li>
<li class=menupage><a href='sales_analysis.php' class=menupage title='<?php etr("toolTip_salesAnalysis")?>'>
<?php etr("Sales analysis") ?></a></li>
<li class=menupage><a href='sales_analysis_cust_dated.php' class=menupage title='<?php etr("sales_analysis_cust_dated")?>'>
<?php etr("Sales analysis dated") ?></a></li>
</ul>

 
    
    </td>
  </tr>
</table>


<?php bottom(); // menupage_end() 
 
?>
<?php //menupage_end() ?>
</div>
</body>
