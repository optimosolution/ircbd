<?php
include('../include/ConvertCharset.class.php');
include "../include/inwordconvert.class.php";


function ccs($text)
{
	$lang = getLanguage();
	if ($lang == 'en')
		return $text;
	if ($lang == 'sv')
		return utf8_decode($text);
	if ($text == null)
		$text = '';
	if (strlen($text) == 0)
		$text = ' ';
	$converter = new ConvertCharset;
	$text = $converter->Convert($text, "UTF-8", "cp874", 0);
	return $text;
}

function setHeaderFont($pdf)
{
	if (getLanguage() == 'th')
		$pdf->setFont('Angsab', '', 12);
	else
		$pdf->setFont('Arial', 'B', 10);
	return $pdf;
}

function setLabelFont($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	if (getLanguage() == 'th')
		$pdf->setFont('Angsa' . $style, '', 9);
	else
		$pdf->setFont('Arial', $style, 9);
	return $pdf;
}

function setCustomFont2($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	if (getLanguage() == 'th')
		$pdf->setFont('Angsa' . $style, '', 30);
	else
		$pdf->setFont('Arial', $style, 30);
	return $pdf;
}

function setCustomFont($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	if (getLanguage() == 'th')
		$pdf->setFont('Angsa' . $style, '', 11);
	else
		$pdf->setFont('Arial', $style, 11);
	return $pdf;
}

function setLogoFont($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	if (getLanguage() == 'th')
		$pdf->setFont('Angsa' . $style, '', 10);
	else
		$pdf->setFont('Arial', $style, 9);
	return $pdf;
}     

function setNormalFont($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	if (getLanguage() == 'th')
		$pdf->setFont('Angsa' . $style, '', 10);
	else
		$pdf->setFont('Times', $style, 9);
	return $pdf;
}

function setNumericFont($pdf, $bold = false)
{
	$style = $bold ? 'B' : '';
	$pdf->setFont('Courier', $style, 10);
	return $pdf;
}


function buildInvoicePDF($orderid, $filename = '', $type = 'invoice')
{
	include('../include/fpdf/fpdf.php');
	$rightAlign = 'R';

	$order = find("SELECT
                `so`.`orderid`,
                `so`.`no`,
                `c`.`name` as name,
        --        `fieldforce`.`fieldforceid` AS `fieldforceid`,
          --      `fieldforce`.`name` AS `fieldforcename`,
                `so`.`orderdate`,
                `so`.`deliverydate`,
                `so`.`invoicetype`,
                `so`.`invoicefor`,
                `so`.`salestype`,
                `so`.`fieldforceid` AS fieldforceid,
                `so`.`locationid` AS `locationid`,
				`so`.`areaid` AS areaid,
                `c`.`customerid` as customerid,
                unix_timestamp(transtime) AS `invoicedate`,
                unix_timestamp(duedate) AS `duedate`,
          --   `salestype`.`name` AS `salestype`,
          --   `invoicefor`.`name` AS `invoicefor`,
          --    `invoicetype`.`name` AS `invoicetype`,
                `so`.`orderedby` AS `orderby`,
                `location`.`name` AS `location`,
                `c`.`mainphone` as mainphone,
                `c`.`zipcode` as zipcode ,
                `c`.`city` as city,
                `c`.`streetaddress` as streetaddress
                FROM
					`salesorder` AS `so`
					Inner Join `customer` AS `c` ON `so`.`customerid` = `c`.`customerid`
					Inner Join `transaction` AS `t` ON `t`.`transactionid` = `so`.`invoice_transid`
			--		Inner Join `invoicefor` ON `so`.`invoicefor` = `invoicefor`.`invoiceforid`
			--		Inner Join `invoicetype` ON `so`.`invoicetype` = `invoicetype`.`invoicetypeid`
			--		Inner Join `salestype` ON `so`.`salestype` = `salestype`.`salestypeid`
					Inner Join `location` ON `so`.`locationid` = `location`.`locationid`
			--		Inner Join `area` ON `so`.`areaid` = `area`.`areaid`
			--		Inner Join `fieldforce` ON `so`.`fieldforceid` = `fieldforce`.`fieldforceid`
			
					where so.orderid=$orderid");
					
					
	

	  
    	/*


    $customerinfo = find("SELECT

					FROM
					`salesorder` AS `so`
					Inner Join `customer` AS `c` ON `so`.`customerid` = `c`.`customerid`
					where so.orderid=$orderid");

   		*/

	$incVAT = $order->customerid == CUSTOMERID_CASH;
	$items = query("select
	          p.productid,
					  model,
					  comment,
					  si.quantity,
					  unitprice,
					  vat,
					  discountprice,
            other_disc,
            bonus_qnt,
            sample_qnt,
					  no,
					  other_disc,
        		bonus_qnt,
        		sample_qnt,
					  u.description as unittype
					from salesorder_item si
					join product p on p.productid=si.productid
				    left outer join unittype u on u.unittype=p.unittype
					where orderid=$orderid
					and si.productid != " . PRODUCTID_ROUNDING . "
					");
	/*//=========================================================
		$orders = query("SELECT
			so.orderid, si.total, pa.allocated,pa2.allocation
			FROM salesorder so
			inner Join (select orderid, sum(quantity * unitprice+vat) as total from salesorder_item group by orderid ) as si
			ON so.orderid = si.orderid
			left join (select orderid,receiptid, sum(amount) as allocated from receipt_allocation group by orderid) as pa
			on so.orderid = pa.orderid and pa.receiptid != $receiptid
                --      //on so.orderid = pa.orderid and pa.receiptid != 37
			left join (select orderid,receiptid, amount as allocation from receipt_allocation group by orderid) as pa2
			on so.orderid = pa2.orderid and pa2.receiptid = $receiptid
                 --     //on so.orderid = pa2.orderid and pa2.receiptid = 37
			where so.customerid= $customerid
			and so.cancelled != 1
			having allocated != total or allocated is null");
    //=======================================================*/
					
					

	$company = find("
          	select companyname, streetaddress, city, zipcode, vatnumber, registrationno
          	from companyinfo");

  $custid= findValue("select customerid from salesorder where orderid=$orderid");

	$customer = find("select name, companyname, streetaddress, city, zipcode, vatnumber from customer
	                  where customerid=$custid");

  $other_adjustment_amount = findValue("select other_adjustment from salesorder where orderid=$orderid");

  $overall_discount = findValue("select discount from salesorder where orderid=$orderid");


//=========================================================
// THIS QUERY IS USED FOR SHOW THE SALES RECEIPTS
        $orders = query("SELECT
so.orderid,so.orderdate,so.customerid,si2.totalamount,pa.allocated,(si2.totalamount -(si.topay*so.disc+so.adjust)-si2.otherdisc) as Total2Pay
FROM
(select orderid,orderdate, customerid,invoice_transid,cancelled, sum(discount/100)as disc,sum(other_adjustment) as adjust from salesorder group by orderid) as so
Inner Join(select orderid,sum((quantity * unitprice+vat/100)) as topay  from salesorder_item where other_disc=0 group by orderid) as si
on so.orderid = si.orderid
Inner Join(select orderid,sum(other_disc) as otherdisc, sum((quantity * unitprice+vat/100)) as totalamount  from salesorder_item  group by orderid) as si2
on so.orderid = si2.orderid
Left Join (select orderid,receiptid, sum(amount) as allocated from receipt_allocation group by orderid) as pa
on so.orderid = pa.orderid
where so.customerid=$order->customerid
and so.invoice_transid is not null and so.cancelled != 1
having allocated != si2.totalamount or allocated is null
");
    //=======================================================
/*	$customerPhones = query("
	select telephoneno, description
	from customer_phone cp
	join phone_category c on c.phonecatid=cp.phonecatid
	where customerid=$order->customerid");
 */
	$total = getSalesOrderTotalEx($orderid);
	$vatTotal = getSalesOrderTotalVat($orderid);
	$rounding = findValue("select unitprice from salesorder_item
						   where orderid=$orderid and productid=" . PRODUCTID_ROUNDING);

	define('MARGIN', 5);
	define('WIDTH', 205);
	define('HEIGHT', 290);
	define('ROWHEIGHT', 6);

	$pdf=new FPDF();
	$pdf->AddPage();
	$pdf->AddFont('angsa','','angsa.php');
	$pdf->AddFont('angsab','','angsab.php');
// 	$pdf->Line(MARGIN,MARGIN, MARGIN, HEIGHT);
 //$pdf->Line(MARGIN,HEIGHT, WIDTH, HEIGHT);
 //	$pdf->Line(WIDTH,HEIGHT, WIDTH, MARGIN);
 	//$pdf->Line(WIDTH,MARGIN, MARGIN, MARGIN);



	$leftX = MARGIN * 80;
	$x = $leftX;
	$y = 2 * MARGIN + ROWHEIGHT;
	$logofile = "../images/invoice" . ".png";
	if (!file_exists($logofile))
		$logofile = "../images/invoice.png";
	if (file_exists($logofile)) {
		$pdf->Image($logofile, MARGIN+3, MARGIN+5);
	$pdf = setLabelFont($pdf, true);
	}

 
	//$leftX = MARGIN * 80;
	//$x = $leftX;
	//$y = 2 * MARGIN + ROWHEIGHT;
/*	$logofile = "../images/banner" . ".jpg";
	if (!file_exists($logofile))
		$logofile = "../images/banner.jpg";        
	if (file_exists($logofile)) {
		$pdf->Image($logofile, MARGIN+2, MARGIN+1);
	//	echo "Image($logofile, MARGIN+1, MARGIN+1)"; 
		$pdf = setLabelFont($pdf, true);
		//$y += 12;
    $y=35;
    $x=10;
	} else {
		$pdf = setLogoFont($pdf, true);
		$pdf->Text($x, $y, $company->companyname);
		$y += ROWHEIGHT;
	}
    
	
		///////////
	*/	 

	$leftX = MARGIN * 80;
	$x = $leftX;
	$y = 2 * MARGIN + ROWHEIGHT;
	
	
	$pdf = setCustomFont2($pdf, false);
	$pdf->Text(120, 12, ccs(tr("OneBook Demo")));

  $pdf = setLabelFont($pdf, false);
	$pdf->Text(120, 16, ccs(tr("House No# 234, Road No # 22")));
	  $pdf = setLabelFont($pdf, false);
	$pdf->Text(120, 20, ccs(tr(" Uttara, Dhaka-1230")));
	  $pdf = setLabelFont($pdf, false);
	$pdf->Text(120, 24, ccs(tr("Phone:   0161 7211792 ")));
	  $pdf = setLabelFont($pdf, false);
	$pdf->Text(120, 28, ccs(tr("Email:    ics.onebook@gmail.com")));

	//	$y += ROWHEIGHT; 
		
		/////////////
	if($order->invoicetype==1){ 
  $pdf = setCustomFont2($pdf, true);
	$pdf->Text(14, 40, ccs(tr("Cash Invoice", 1, 0, $rightAlign)));
  /*
      $pdf->Cell(11, ROWHEIGHT,formatMoney($totalvat), 1, 0, $rightAlign);   
        	 	$invoice = "../images/cashinvoice" . ".png";
        	if (!file_exists($invoice))
        		$invoice = "../images/cashinvoice.png";
        	if (file_exists($invoice)) {
        		$pdf->Image($invoice, 10, 5*ROWHEIGHT);
       		
        	}
*/  
}
  if($order->invoicetype==2){    
  $pdf = setCustomFont2($pdf, true);
	$pdf->Text(14, 40, ccs(tr("Credit Invoice", 1, 0, $rightAlign)));    
  }   
  if($order->invoicetype==3){    
  $pdf = setCustomFont2($pdf, true);
	$pdf->Text(14, 40, ccs(tr("Sample Invoice", 1, 0, $rightAlign)));
  }	
		
		
		/// end of invoicing
    $y=45;
    $x=10;		
		
	$y += ROWHEIGHT;
	$pdf = setCustomFont($pdf, false);
	$pdf->Text($x, $y, ccs(tr("Invoice No.") . ":"));
	$x1 = $x + 25;
	$pdf = setCustomFont($pdf, false);
	$pdf->Text($x1, $y, ccs($invoicefor)."-".ccs($order->orderid));
	//	$y += ROWHEIGHT; 		
		$x1 = $x + 50;	
	$pdf = setCustomFont($pdf, false);
	$pdf->Text($x1, $y, ccs(tr("Date") . ":"));

  $x1 = $x1 + 25;	
	$pdf = setCustomFont($pdf, false);
	$pdf->Text($x1, $y, ccs($order->orderdate));
	
 	$y += ROWHEIGHT;
 
	$pdf = setCustomFont($pdf, false);
$pdf->Text($x, $y, ccs(tr("Order Ref") . ":"));


	$x1 = $x+ 25;
	$pdf = setCustomFont($pdf, false);
	$pdf->Text($x1, $y, ccs($order->orderby));	

		//$y += ROWHEIGHT;
	$x1 = $x+ 50;
	$pdf = setCustomFont($pdf, false);
$pdf->Text($x1, $y, ccs(tr("Delivery Date") . ":"));


	$x1 = $x1+ 25;
	$pdf = setCustomFont($pdf, false);
	$pdf->Text($x1, $y, ccs($order->deliverydate));


	$y += ROWHEIGHT;
	$pdf = setCustomFont($pdf, false);
$pdf->Text($x, $y, ccs(tr("Depot") . ":"));


	$x1 = $x+ 25;
	$pdf = setCustomFont($pdf, false);
	$pdf->Text($x1, $y, ccs($order->location));

 $x1 = $x+ 50;
  

  $x1 = $x1+ 25;
   
  
  //--
    $y += ROWHEIGHT;

	$pdf = setCustomFont($pdf, false);
 
  	$x1 = $x+ 25;
 
	
  
  //----
	
  $y += ROWHEIGHT;

 
  	$x1 = $x+ 25;
 
	
	// $y += ROWHEIGHT;
	$x1 = $x+ 34;
 
	
        $y += ROWHEIGHT;
     	$x1= $x+50;
	 

/*
        $y += ROWHEIGHT;
     	$x1= $x+50;
	$pdf->Text($x1, $y, ccs($custid));
	    
*/	    
	    
	      

// end of the top left side value


		if (!isEmpty($company->registrationno)) {
		$pdf = setLabelFont($pdf, false);
		$y += ROWHEIGHT;
		$text = ccs(tr("Registrationno")) . ': ';
		$pdf->Text($x, $y, $text);
		$x += 25;
		$pdf = setNumericFont($pdf, false);
		$pdf->Text($x, $y, $company->registrationno);
		$x = $rightX;
	}

	$rightX = 120;
	$x = $rightX;
	$y = 2*MARGIN + ROWHEIGHT;
	$pdf = setHeaderFont($pdf);
	switch ($type) {
		case 'invoice': $label = 'Invoice'; break;
		case 'receipt': $label = 'Receipt'; break;
		case 'credit': $label = 'Credit note'; break;
	}
	    $y += ROWHEIGHT;
	    $y += ROWHEIGHT;
 /*
  $pdf->Text($x, $y, ccs(tr($label)));
	$pdf = setLabelFont($pdf);
	$label = "Order #";
	if ($type == 'invoice')
		$label = "Invoice #";
	$y += ROWHEIGHT;
	$pdf->Text($x, $y, ccs(tr($label)));
	$pdf = setNumericFont($pdf, true);
	$x += 25;
	$pdf->Text($x, $y, $order->no);
	$pdf = setLabelFont($pdf);
	$x = $rightX;
	$label = $type == 'invoice' ? "Invoice date" : "Receipt date";
	$y += ROWHEIGHT;
	$pdf->Text($x, $y, ccs(tr($label)) . ": ");
	$pdf = setNumericFont($pdf);
	$x += 25;
	$pdf->Text($x, $y, formatDate($order->invoicedate));
	$x = $rightX;
	$pdf = setLabelFont($pdf);
  if ($type == 'invoice') {
		$y += ROWHEIGHT;
		$pdf->Text($x, $y, ccs(tr("Due date") . ": "));
		$pdf = setNumericFont($pdf);
		$x += 25;
		$pdf->Text($x, $y, formatDate($order->duedate));
		$x = $rightX;
	}  */

	//$y += ROWHEIGHT;
	//$x1 = $x+ 25;
	//$pdf = setNormalFont($pdf, false);
//$pdf->Text($x, $y, ccs(tr("Field Force") . ":"));

 
    $y=35;
    //$x=10;	
 $x = 120;
 
	 $y += ROWHEIGHT;
	$pdf = setCustomFont($pdf, false);
  $pdf->Text($x, $y, ccs(tr("Customer ID") . ":"));


  $x1 = $x+ 25;
  $pdf->Text($x1, $y, ccs($order->customerid));




	 $x1 = $x+ 25;
	 $y += ROWHEIGHT;
	$pdf = setCustomFont($pdf, false);
  $pdf->Text($x, $y, ccs(tr("Name") . ":"));


  $x1 = $x+ 25;
  $pdf->Text($x1, $y, ccs($customer->name));

   $x1 = $x+ 25;
	 $y += ROWHEIGHT;
	$pdf = setCustomFont($pdf, false);
  $pdf->Text($x, $y, ccs(tr("Address") . ":"));


  $x1 = $x+ 25;
  $pdf->Text($x1, $y, ccs($order->streetaddress));


   $x1 = $x+ 25;
	 $y += ROWHEIGHT;
	$pdf = setCustomFont($pdf, false);
  $pdf->Text($x, $y, ccs(tr("")));


  $x1 = $x+ 25;
  $pdf->Text($x1, $y,ccs($order->city)."-". ccs($order->zipcode ));


        $x1 = $x+ 25;
	$y += ROWHEIGHT;
	$pdf = setCustomFont($pdf, false);
        $pdf->Text($x, $y, ccs(tr("Contact No.") . ":"));


        $x1 = $x+ 25;
        $pdf->Text($x1, $y, ccs($order->mainphone));


	$y += ROWHEIGHT;
	$x1 = $x+ 25;
 


	$x1 = $x+ 25;
	 
   /*     $y += ROWHEIGHT;
        $x1 = $x+ 25;
	$pdf = setCustomFont($pdf, false);
        $pdf->Text($x, $y, ccs(tr("Order ID") . ":"));


        $x1 = $x+ 25;
	$pdf = setCustomFont($pdf, false);
	$pdf->Text($x1, $y, ccs($orderid)); */

        $y=$y+5;
	$pdf->SetX(0);
	$pdf->SetY($y+ROWHEIGHT);
        $pdf->$y+ROWHEIGHT;

	$pdf = setLabelFont($pdf,TRUE);
	$pdf->Cell(20, ROWHEIGHT, ccs(tr("Product ID")), 1);
	$pdf->Cell(45, ROWHEIGHT, ccs(tr("Product Name")), 1);
	$pdf->Cell(20, ROWHEIGHT, ccs(tr("Size")), 1);
	$pdf->Cell(15, ROWHEIGHT, ccs(tr("Qty")), 1, 0, $rightAlign);
	$pdf->Cell(22, ROWHEIGHT, ccs(tr("Sales Price")), 1, 0, $rightAlign);
	$pdf->Cell(22, ROWHEIGHT, ccs(tr("Total Proice")), 1, 0, $rightAlign);
	$pdf->Cell(15, ROWHEIGHT, ccs(tr("VAT")), 1, 0, $rightAlign);
	$pdf->Cell(22, ROWHEIGHT, ccs(tr(" Total Amount")), 1, 1, $rightAlign);

	$subtotal=0;
	$totalvat=0;
	$totaldiscountprice=0;
        $totalother_disc=0;
        $discountamount=0;

        $pdf = setLabelFont($pdf);
	while ($row = fetch($items)) {

		$pdf->Cell(20, ROWHEIGHT, ccs($row->productid), 'LR');
		$pdf->Cell(45, ROWHEIGHT, ccs($row->model), 'LR');
		$pdf->Cell(20, ROWHEIGHT, ccs($row->unittype), 'LR');
		$pdf->Cell(15, ROWHEIGHT, ccs($row->quantity), 'LR', 0, 'R');
		$pdf->Cell(22, ROWHEIGHT, formatMoney(ccs($row->unitprice )), 'LR', 0, 'R');
		$pdf->Cell(22, ROWHEIGHT, formatMoney(ccs($row->unitprice * $row->quantity) ), 'LR', 0, 'R');
		$pdf->Cell(15, ROWHEIGHT, formatMoney(ccs($row->vat)), 'LR', 0, 'R');



        $total = ($row->unitprice * $row->quantity)-$discountamount-$row->other_disc+$row->vat;
	//$subtotal = $subtotal + $row->vat -($discountamount+$row->other_disc);



		//if ($incVAT)
		//	$unitprice += $row->vat;
	//	$pdf->Cell(20, ROWHEIGHT, formatMoney($unitprice), 'LR', 0, 'R');
	  //$amount=(($row->unitprice*$row->quantity)-$row->discountprice-$row->other_disc);



		$pdf->Cell(22, ROWHEIGHT, formatMoney($total), 'LR', 1, 'R');

  $totalvat+=$row->vat;
  $totaldiscountprice+=$discountamount;
  $totalother_disc+=$row->other_disc;
  $totalamount+=$total ;    //+$totalvat-$totaldiscountprice
  $subtotal+=$row->unitprice * $row->quantity;

}
 
 
 	$amount=(($row->unitprice*$row->quantity)-$discountamount-$row->other_disc);
	$pdf = setLabelFont($pdf);
	$pdf->Cell(100, ROWHEIGHT, 'Subtotal', 1, 0, $rightAlign);
  	$pdf->Cell(22, ROWHEIGHT, formatMoney($subtotal), 1, 0, $rightAlign);
        $pdf->Cell(22, ROWHEIGHT,formatMoney($totalvat), 1, 0, $rightAlign);
	$pdf->Cell(15, ROWHEIGHT, '', 1, 0, $rightAlign);

	$pdf->Cell(22, ROWHEIGHT, formatMoney($totalamount), 1, 1, $rightAlign);

		//	$top = '';

  
 $discountamountwithoutod=findValue("SELECT sum( `quantity` * `unitprice` )/100 AS tamount
FROM `salesorder_item` 
WHERE orderid =$orderid
AND `other_disc` =0 ");
 
	$pdf = setLabelFont($pdf, true);
        $pdf->Cell(87, ROWHEIGHT, '', '');
	$pdf->Cell(61, ROWHEIGHT, 'Discount', '', 0, 'R');
	$pdf->Cell(13, ROWHEIGHT, ' ('.ccs($overall_discount).'%):', '', 0, 'R');


	$pdf = setLabelFont($pdf, true);
	$pdf->Cell(20, ROWHEIGHT, formatMoney($discountamountwithoutod*$overall_discount), '', 1, $rightAlign);

  

	$pdf->Cell(100, ROWHEIGHT, '', '');
	$pdf->Cell(61, ROWHEIGHT, 'Other Adjustment:', '', 0, 'R');
	$pdf = setLabelFont($pdf, true);
	//$label = 'To pay';
//	if ($type == 'credit')
//		$label = 'To refund';
	$pdf->Cell(20, ROWHEIGHT, formatMoney($other_adjustment_amount), '', 1, $rightAlign);

 $netpay=$totalamount-$other_adjustment_amount-($discountamountwithoutod*$overall_discount);
 $netpayamount=formatMoney($netpay);
	$pdf->Cell(100, ROWHEIGHT, '', '');
	$pdf->Cell(61, ROWHEIGHT, "Net Payble Amount:", '', 0, 'R');
	$pdf = setLabelFont($pdf, true);
//	$label = 'To pay';
//	if ($type == 'credit')
//		$label = 'To refund';
	$pdf->Cell(20, ROWHEIGHT, formatMoney($netpay), 0, 1, $rightAlign);
        $pdf->Cell(13, ROWHEIGHT, '', 0, 1, $rightAlign);
	$pdf->Cell(13, ROWHEIGHT, '', 0, 1, $rightAlign);
	//=======================================================
	 // Middle
	/*$y+=55;
	$pdf->SetX(0);
	$pdf->SetY($y+ROWHEIGHT);
        $pdf->$y+ROWHEIGHT;
   */     
//   $inword = new Convert($netpay,'');
//$pdf = setLabelFont($pdf, true);
//$pdf->Cell(100, ROWHEIGHT, "Tk. (In word) :".$inword->getAmount() ." only",'', 0, $rightAlign);
//	$pdf->Cell(40, ROWHEIGHT, '',0, 1, $rightAlign);
 // 	$pdf->Cell(40, ROWHEIGHT, '',0, 1, $rightAlign);    
 
   
	       	$pdf = setLabelFont($pdf, true);
		//$pdf->Cell(100, 1, '', '', 1);
	   $pdf->Text(5, 273, '_______________________', '');
		$pdf->Text(50, 273, '_______________________', '');

		$pdf->Text(100, 273, '________________________', '');
		$pdf->Text(150, 273, '________________________', '', 1);


    $pdf->Text(5, 277, ccs(tr('Customer\'s. signature')), '');
		$pdf->Text(50, 277, ccs(tr('Prepared By')), '');

    $pdf->Text(100, 277, ccs(tr('Delivered By')), '');
		$pdf->Text(150, 277, ccs(tr('Authorized Signature')), '', 1);

		//$pdf->Cell(100, 1, '', '', 1);

 
      
 //$pdf->Cell(100, 50, '', '', 1);
  if(($order->invoicetype==1) || ($order->invoicetype==2))
  {
	$note = "../images/note" . ".png";
	if (!file_exists($note))
		$note = "../images/note.png";
	if (file_exists($note)) {
		$pdf->Image($note,2,280);
	}
  }
  $rs = query("select text from invoice_footer order by rowno");
		while ($row = fetch($rs)) {
			$pdf->Cell(200, ROWHEIGHT, ccs($row->text), '', 1);
		}
	//}

	$dest = '';
	if (!isEmpty($filename)) {
		$dest = 'F';
	}
	$pdf->Output($filename, $dest);
}

?>