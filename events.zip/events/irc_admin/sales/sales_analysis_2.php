<?php
	include('include.php');

    $model = getParam('model');
    $locationid = getParam('locationid');
	$type = getParam('type', TYPE_MONTHS);
	if ($type == TYPE_MONTHS)
		$start = getMonthStepperDate();
	else
		$start = getYearStepperDate();
	$end = addTime($start, $type);



	$locationSQL = "1=1";
	if (!isEmpty($locationid)) {
		$locationSQL = "locationid=$locationid";
	}   	
  //,sum(soi.other_disc), sum(soi.bonus_qnt), sum(soi.sample_qnt)	 
	$selectSQL = "
	select
	    p.productid,
	    model,
	    (select sum(soi.quantity)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and orderdate >= from_unixtime($start) and orderdate < from_unixtime($end)
	     where soi.productid=p.productid and $locationSQL) as quantity,
	     
	     (select sum(soi.other_disc)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and orderdate >= from_unixtime($start) and orderdate < from_unixtime($end)
	     where soi.productid=p.productid and $locationSQL) as other_disc,
	     
	     (select sum(soi.bonus_qnt)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and orderdate >= from_unixtime($start) and orderdate < from_unixtime($end)
	     where soi.productid=p.productid and $locationSQL) as bonus_qnt,
	     
	     (select sum(soi.sample_qnt)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and orderdate >= from_unixtime($start) and orderdate < from_unixtime($end)
	     where soi.productid=p.productid and $locationSQL) as sample_qnt,
	     
	    (select sum(soi.quantity*soi.unitprice)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and orderdate >= from_unixtime($start) and orderdate < from_unixtime($end)
	     where soi.productid=p.productid and $locationSQL) as revenue
	     from product p
	where model like '$model%'
	and productid not in (" . PRODUCTID_UNSPECIFIED . ", " . PRODUCTID_ROUNDING . ")
	";
	 
	$locations = rs2array(query("select locationid, name from location"));	
	$product = rs2array(query("select productid, model from product"));

?>

<head>
<title>ICS System Solutions - <?php etr("Sales analysis") ?></title>
<?php
styleSheet();
?>
</head>

<body>

<?php menubar('index.php') ?>
<?php title(tr("Sales analysis")) ?>

<form name=searchform action="sales_analysis.php" method="GET">
<div class="border">
<center>
<table class='main'>
<tr>
<td><?php etr("Product") ?>:</td><td><?php combobox('model',$product, $model) ?></td><td width=20/>
<td><?php etr("Channel") ?>:</td><td><?php combobox('locationid', $locations, $locationid, true) ?></td>
<td><?php etr("Warehouse") ?>:</td><td><?php combobox('locationid', $locations, $locationid, true) ?></td>
<td><?php searchButton() ?></td>
</tr>
<tr>
<td><br></td>
</tr>
</table>
<?php 
$yearsChecked = '';
$monthsChecked = '';
if ($type == TYPE_YEARS) {
	yearStepper($start);
	$yearsChecked = 'checked';
} else {
	monthStepper($start); 
	$monthsChecked = 'checked';
}
echo "<input type=radio name=type value='" . TYPE_DATE . "' $yearsChecked onClick='document.searchform.submit()'>" . tr("Date") . "</input>";
echo "<input type=radio name=type value='" . TYPE_YEARS . "' $yearsChecked onClick='document.searchform.submit()'>" . tr("Years") . "</input>";
echo "<input type=radio name=type value='" . TYPE_MONTHS . "' $monthsChecked onClick='document.searchform.submit()'>" . tr("Months") . "</input>";
?>
</center>
</div>
</form>
&nbsp;

<center>
<input type=hidden name=orderid value='<?php echo $orderid ?>'/>
<table class='main'>
<th><?php etr("Productno") ?></th>
<th><?php etr("Product") ?></th>
<th><?php etr("Quantity") ?></th>
<!--
<th><?php etr("Total Discount") ?></th>
<th><?php etr("Bonus Quantity") ?></th>
<th><?php etr("Sample Quantity") ?></th>
-->
<th><?php etr("Revenue") ?></th>

<?php
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
    	$href = "../erp/product.php?productid=$row->productid";
        echo "<tr class='$class'>";
        echo "<td>$row->productid</td>";
        echo "<td><a href='$href'>$row->model</a></td>";
		$href = "sales.php?productid=$row->productid&starttime=$start&endtime=$end";
        echo "<td align=right><a href='$href'>$row->quantity</a></td>";
  /*         
           echo "<td align=right><a href='$href'>$row->other_disc</a></td>";
           echo "<td align=right><a href='$href'>$row->bonus_qnt</a></td>";
           echo "<td align=right><a href='$href'>$row->sample_qnt</a></td>";
    */             
        echo "<td align=right><a href='$href'>" . formatMoney($row->revenue) . "</a></td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table>
</center>
 


<?php bottom(); // menupage_end() 
 
?>
<?php //menupage_end() ?>
</div>
</body>
