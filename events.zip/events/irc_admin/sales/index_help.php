<?php include('include.php') ?>
<head>
<title>ICS System Solutions - <?php etr("Help - Sales") ?></title>
<?php styleSheet() ?>
</head>
<body>
<?php menubar('index_help.php', 'index_help.php') ?>

<h1>Sales</h1>

</body></html>
