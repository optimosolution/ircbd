<?php
	include('include.php');

    $customerid = getParam('customerid');
	
	$sql = "
	select
	    receiptid,
	    unix_timestamp(transtime) as receiptdate,
	    name as customername,
	    p.transactionid,
	    companyname,
	    moneyreceiptno,
		amount
	from receipt p
	join customer c on c.customerid=p.customerid
	join transaction t on t.transactionid=p.transactionid
	where c.customerid like '$customerid%'";
	$sql .= " order by receiptid desc";

    $rs = query($sql);
	$customers = rs2array(query("select customerid, companyname from customer order by companyname asc"));
?>

<head>
<title>ICS System Solutions - <?php etr("Receipts") ?></title>
<?php styleSheet() ?>
</head>

<body>

<?php menubar("index.php") ?>
<?php title(tr("Receipts")) ?>

<form action="receipts.php" method="GET">
<div class="border">
<table>
<tr><td><?php etr("Customer") ?>:</td><td><?php comboBox('customerid', $customers, $customerid, true) ?></td>
<tr><td><input type="submit" name="search" value="<?php etr("Search") ?>" /></td></tr>
</tr>
</table>
</div>
</form>
&nbsp;

<form action="receipts.php" method=POST>
<table>
<th><?php etr("Delete") ?></th>
<th><?php etr("Id") ?></th>
<th><?php etr("Company Name") ?></th>
<th><?php etr("Date") ?></th>
<th><?php etr("Amount") ?></th> 
<th><?php etr("Money Receipt No.") ?></th> 
<th><?php etr("Sales Order ID") ?></th> 
<?php
    $class = "odd";
    $i = 0;
    while ($row = fetch_object($rs)) {
        echo "<tr class='$class'>";
    	echo "<td align=center><input type=checkbox name='del_$i' value=1/></td>";
        echo "<td><a href='receipt.php?receiptid=$row->receiptid'>$row->receiptid</a></td>";
        echo "<td>$row->companyname, $row->customername</td>";
        echo "<td>" . date(DATE_PATTERN, $row->receiptdate) . "</td>";
		echo "<td align=right>" . formatMoney($row->amount) . "</td>";
				echo "<td align=right>$row->moneyreceiptno</td>";
				echo "<td align=right>";
        
          $rs_id=query("SELECT `orderid` FROM `receipt_allocation` WHERE `receiptid`=$row->receiptid");
             while ($row2 = fetch_object($rs_id)) {
                   echo $row2->orderid;
                   echo " |";
             }
       
        echo "</td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
        $i++;
    }
?>
</table>
<table>
<tr>
<td><?php newButton("customers.php?mode=receipt") ?></td>
<td><?php saveButton() ?></td>
</tr>
</table>
</form>
<?php bottom() ?>
</body>
