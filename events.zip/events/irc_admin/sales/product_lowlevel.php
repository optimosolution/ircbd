<?php include("include.php") ?>

<head>
<title>ICS System Solutions - <?php etr("Sales") ?></title>
<?php styleSheet() ?>
</head>

<body>

<div class=main>
<table width="100%" cellspacing=0 cellpadding=0  class='main'>
<tr class=menubar><td style="padding: 2"></td></tr>
</table>
<?php 

menubar('index.php', 'index_help.php');
//menupage_begin();
?>
  <br>
  <h3>Low level Product List</h3>

<table border="0"  class='main'>
  <tr><th bgcolor="#000000"><span class="style1">Product No</span></th>
<th bgcolor="#000000"><span class="style1">Product</span></th>
<th bgcolor="#000000"><span class="style1">Pack Size</span></th>
<th bgcolor="#000000"><span class="style1">Available Quantity </span></th>
<th bgcolor="#000000"><span class="style1">Lowlevel Quantity </span></th>
<tr class='even'><td>1007</td><td><a href='product.php?productid=1007'>Amicox-1 kg </a></td><td align=right>50 gm</td>
  <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1007&locationid=' class=sum>13</a></div></td>
  <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a></td>
  </tr><tr class='odd'><td bgcolor="#CCCCCC">1006</td><td bgcolor="#CCCCCC"><a href='product.php?productid=1006'>Amicox-100 gm </a></td><td align=right bgcolor="#CCCCCC">50 gm</td>
    <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1006&locationid=' class=sum>9</a></div></td>
    <td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1006&amp;locationid=' class="sum">20</a></td>
    </tr><tr class='even'><td>1008</td><td><a href='product.php?productid=1008'>Caldivet D3-100 gm </a></td><td align=right>50 gm</td>
      <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1008&locationid=' class=sum>15</a></div></td>
      <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1008&amp;locationid=' class="sum"></a></td>
      </tr><tr class='odd'><td bgcolor="#CCCCCC">1009</td><td bgcolor="#CCCCCC"><a href='product.php?productid=1009'>Caldivet D4-1 kg </a></td><td align=right bgcolor="#CCCCCC">50 gm</td>
        <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1009&locationid=' class=sum>16</a></div></td>
        <td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1009&amp;locationid=' class="sum"></a></td>
        </tr><tr class='even'><td>1013</td><td><a href='product.php?productid=1013'>Calphovet Liquid-1 lt </a></td><td align=right>50 gm</td>
          <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1013&locationid=' class=sum>13</a></div></td>
          <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1013&amp;locationid=' class="sum"></a></td>
          </tr><tr class='odd'><td bgcolor="#CCCCCC">1010</td><td bgcolor="#CCCCCC"><a href='product.php?productid=1010'>Calphovet Liquid-100 ml </a></td><td align=right bgcolor="#CCCCCC">50 gm</td>
            <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1010&locationid=' class=sum>11</a></div></td>
            <td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1010&amp;locationid=' class="sum"></a></td>
            </tr><tr class='even'><td>1011</td><td><a href='product.php?productid=1011'>Calphovet Liquid-250 ml </a></td><td align=right>50 gm</td>
              <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1011&locationid=' class=sum>13</a></div></td>
              <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1011&amp;locationid=' class="sum"></a></td>
              </tr><tr class='odd'><td bgcolor="#CCCCCC">1012</td>
              <td bgcolor="#CCCCCC"><a href='product.php?productid=1012'>Calphovet Liquid-500ml </a></td>
              <td align=right bgcolor="#CCCCCC">50 gm</td>
                <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1012&locationid=' class=sum>14</a></div></td>
                <td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1012&amp;locationid=' class="sum"></a></td>
                </tr><tr class='even'><td>1017</td><td><a href='product.php?productid=1017'>Calphovet plus-1lt </a></td><td align=right>50 gm</td>
                  <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1017&locationid=' class=sum>10</a></div></td>
                  <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1017&amp;locationid=' class="sum"></a></td>
                  </tr><tr class='odd'><td bgcolor="#CCCCCC">1015</td>
                  <td bgcolor="#CCCCCC"><a href='product.php?productid=1015'>Calphovet plus-250 ml </a></td>
                  <td align=right bgcolor="#CCCCCC">50 gm</td>
                    <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1015&locationid=' class=sum>9</a></div></td>
                    <td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1015&amp;locationid=' class="sum"></a></td>
                    </tr><tr class='even'><td>1016</td><td><a href='product.php?productid=1016'>Calphovet plus-500ml </a></td><td align=right>50 gm</td>
                      <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1016&locationid=' class=sum>9</a></div></td>
                      <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1016&amp;locationid=' class="sum"></a></td>
                      </tr><tr class='odd'><td bgcolor="#CCCCCC">1021</td>
                      <td bgcolor="#CCCCCC"><a href='product.php?productid=1021'>CF - 10 Liquid-1 lt </a></td>
                      <td align=right bgcolor="#CCCCCC">50 gm</td>
                        <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1021&locationid=' class=sum>14</a></div></td>
                        <td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1021&amp;locationid=' class="sum"></a></td>
                        </tr><tr class='even'><td>1019</td><td><a href='product.php?productid=1019'>CF - 10 Liquid-100ml </a></td><td align=right>50 gm</td>
                          <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1019&locationid=' class=sum>12</a></div></td>
                          <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1019&amp;locationid=' class="sum"></a></td>
                          </tr><tr class='odd'><td bgcolor="#CCCCCC">1020</td>
                          <td bgcolor="#CCCCCC"><a href='product.php?productid=1020'>CF - 10 Liquid-500ml </a></td>
                          <td align=right bgcolor="#CCCCCC">50 gm</td>
                            <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1020&locationid=' class=sum>8</a></div></td>
                            <td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1020&amp;locationid=' class="sum"></a></td>
                            </tr><tr class='even'><td>1018</td><td><a href='product.php?productid=1018'>CF - 10 Powder-100gm </a></td><td align=right>50 gm</td>
                              <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1018&locationid=' class=sum>5</a></div></td>
                              <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1018&amp;locationid=' class="sum"></a></td>
                              </tr><tr class='odd'><td bgcolor="#CCCCCC">1023</td>
                              <td bgcolor="#CCCCCC"><a href='product.php?productid=1023'>Cinavet-1 lt </a></td>
                              <td align=right bgcolor="#CCCCCC">50 gm</td>
                                <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1023&locationid=' class=sum>5</a></div></td>
                                <td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a></td>
                                </tr><tr class='even'><td>1022</td><td><a href='product.php?productid=1022'>Cinavet-100ml </a></td><td align=right>50 gm</td>
                                  <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1022&locationid=' class=sum>3</a></div></td>
                                  <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1022&amp;locationid=' class="sum"></a></td>
                                  </tr><tr class='odd'><td bgcolor="#CCCCCC">1026</td>
                                  <td bgcolor="#CCCCCC"><a href='product.php?productid=1026'>Coccivet Liquido-1 lt </a></td>
                                  <td align=right bgcolor="#CCCCCC">50 gm</td>
                                    <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1026&locationid=' class=sum>7</a></div></td>
                                    <td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1026&amp;locationid=' class="sum"></a></td>
                                    </tr><tr class='even'><td>1024</td><td><a href='product.php?productid=1024'>Coccivet Liquido-100 ml </a></td><td align=right>50 gm</td>
                                      <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1024&locationid=' class=sum>9</a></div></td>
                                      <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1024&amp;locationid=' class="sum"></a></td>
                                      </tr><tr class='odd'><td bgcolor="#CCCCCC">1025</td>
                                      <td bgcolor="#CCCCCC"><a href='product.php?productid=1025'>Coccivet Liquido-250 ml </a></td>
                                      <td align=right bgcolor="#CCCCCC">50 gm</td>
                                        <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1025&locationid=' class=sum>13</a></div></td>
                                        <td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1025&amp;locationid=' class="sum"></a></td>
                                        </tr><tr class='even'><td>1014</td><td><a href='product.php?productid=1014'>DCP -25kg </a></td><td align=right>50 gm</td>
                                          <td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1014&locationid=' class=sum>7</a></div></td>
                                          <td align="right"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1014&amp;locationid=' class="sum"></a></td>
                                          </tr><tr class='odd'><td bgcolor="#CCCCCC">1333</td>
                                          <td bgcolor="#CCCCCC"><a href='product.php?productid=1333'>dfdcfd </a></td>
                                          <td align=right bgcolor="#CCCCCC">50 gm</td>
<td align=right bgcolor="#F39F6D"><div align="center"><a href='stockmoves.php?productid=1333&locationid=' class=sum>8</a></div></td>
<td align="right" bgcolor="#CCCCCC"><a href='stockmoves.php?productid=1007&amp;locationid=' class="sum">20</a><a href='stockmoves.php?productid=1333&amp;locationid=' class="sum"></a></td>
</tr></table>


<?php bottom(); // menupage_end() 
 
?>
<?php //menupage_end() ?>
</div>
</body>