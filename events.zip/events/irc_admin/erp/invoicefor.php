<?php
	include('include.php');

	checkPermission(PERMISSIONID_MANAGE_PRODUCTS);
	
	$id = getParam('id');
	$new = true;
	if (isSave()) {
		$id = getParam('id');
		$name = getParam('name');
		$description = getParam('description');
		if (isNew()) {
			$sql = "insert into invoicefor (name, description)  
			        values ('$name', '$description')";
			sql($sql);
			$id = insert_id();
		} else {
            $updateSQL =
    			"update invoicefor set
    				name='$name',
    			    description=$description
                where id='$id'";
    		sql($updateSQL);
		}
	}
	if (isDelete()) {
		sql("delete from invoicefor where id='$id'");
		$id = null;
	}

	$rec = new Dummy();
	if (!isEmpty($id)) {
	    $selectSQL =
  		"select id,
  		       name,
			   description
		from invoicefor
		where id='$id'
		";
		$rec = find($selectSQL);
		if ($rec != null) {
			$new = false;
		}
	}

?>
<head>
<title>ICS System Solutions - <?php etr("Invoice For") ?></title>
<?php styleSheet() ?>
</head>

<body>
<?php menubar('configuration.php') ?>
<?php title("<a href='invoicefors.php'>" . tr("Invoice for") . "</a> > $rec->name") ?>

<form action="invoicefor.php" method="POST">
<table>
<tr><td>Id:</td>
<td>
<?php
	if ($new) {
	} else {
		echo $id;
		echo "<input type='hidden' name='id' value='$id'/>";
	}
?>
</td>
<tr><td><?php etr("Name") ?>:</td><td><input type="text" name="name" value="<?php echo $rec->name ?>"/></td>
<tr><td><?php etr("description") ?>:</td><td><?php textbox("description", $rec->description) ?></td>

<tr>
<td colspan=2>
<?php 
saveButton();
echo "&nbsp;";
deleteButton();
?>
&nbsp;
</td>
</tr>
</table>
<input type="hidden" name="new" value="<?php echo $new ?>"/>
</form>
<?php bottom() ?>
</body>
