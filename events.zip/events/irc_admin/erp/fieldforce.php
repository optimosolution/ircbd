<?php
	include('include.php');

	$locationid = getParam('fieldforceid');
	$name = '';
	$streetaddress = '';
	$city = '';
	$zipcode = '';
	$new = true;
	if (isSave()) {
		$name = getParam('name');
		$streetaddress = getParam('streetaddress');
		$city = getParam('city');
		$zipcode = getParam('zipcode');
		if (isNew()) {
			$sql = "insert into fieldforce (name, streetaddress, city, zipcode)  
			        values ('$name', '$streetaddress', '$city', '$zipcode')";
			sql($sql);
			$locationid = insert_id();
		} else {
			$updateSQL =
				"update fieldforce set
					name='$name',
					streetaddress='$streetaddress',
					city='$city',
					zipcode='$zipcode'
				where fieldforceid=$fieldforceid";
			sql($updateSQL);
		}
	}

	if (!isEmpty($fieldforceid)) {
	    $selectSQL =
  		"select fieldforceid,
		       name,
			   streetaddress,
			   city,
			   zipcode
		from fieldforce
		where fieldforceid=$fieldforceid
		";
		$rec = find($selectSQL);
		if ($rec != null) {
			$fieldforceid = $rec->fieldforceid;
			$name = $rec->name;
			$streetaddress = $rec->streetaddress;
			$city = $rec->city;
			$zipcode = $rec->zipcode;
			$new = false;
		}
	}

?>
<head>
<title>ICS System Solutions - <?php echo tr("Field Force") ?></title>
<?php styleSheet() ?>
</head>

<body>
<?php menubar("configuration.php") ?>
<?php
$title = "<a href='fieldforces.php'>" . tr("Field Force") . "</a> > $name";
title($title);
?>

<form action="fieldforce.php" method="POST">
<input type=hidden name=fieldforceid value='<?php echo $fieldforceid ?>'/>
<table>
<tr><td><?php echo tr("Name") ?>:</td><td><input type="text" name="name" value="<?php echo $name ?>"/></td>
<tr><td><?php echo tr("Street address") ?>:</td><td><input type="text" name="streetaddress" value="<?php echo $streetaddress ?>"/></td>
<tr><td><?php echo tr("City") ?>:</td><td><input type="text" name="city" value="<?php echo $city ?>"/></td>
<tr><td><?php echo tr("Zip code") ?>:</td><td><input type="text" name="zipcode" value="<?php echo $zipcode ?>"/></td>

<tr>
<td colspan=2>
<input type="submit" name="save" value="Save"/>
&nbsp;
</td>
</tr>
</table>
<input type="hidden" name="new" value="<?php echo $new ?>"/>
</form>
<?php bottom() ?>

</body>
