<?php
	include('include.php');

	$packsizeid = getParam('packsizeid');
	$name = '';
	$comments = '';
 
	$new = true;
	if (isSave()) {
		$name = getParam('name');
		$comments = getParam('comments');
 
		if (isNew()) {
			$sql = "insert into packsize (name, comments)  
			        values ('$name', '$comments')";
			sql($sql);
			$packsizeid = insert_id();
		} else {
			$updateSQL =
				"update location set
					name='$name',
					comments='$comments'
				where packsizeid=$packsizeid";
			sql($updateSQL);
		}
	}

	if (!isEmpty($packsizeid)) {
	    $selectSQL =
  		"select packsizeid,
		       name,
			   comments
		from packsize
		where packsizeid=$packsizeid
		";
		$rec = find($selectSQL);
		if ($rec != null) {
			$packsizeid = $rec->packsizeid;
			$name = $rec->name;
			$comments = $rec->comments;
	 
			$new = false;
		}
	}

?>
<head>
<title>ICS System Solutions - <?php echo tr("Packsize") ?></title>
<?php styleSheet() ?>
</head>

<body>
<?php menubar("configuration.php") ?>
<?php
$title = "<a href='packsizes.php'>" . tr("Packsize") . "</a> > $name";
title($title);
?>

<form action="packsize.php" method="POST">
<input type=hidden name=packsizeid value='<?php echo $packsizeid ?>'/>
<table>
<tr><td><?php echo tr("Name") ?>:</td><td><input type="text" name="name" value="<?php echo $name ?>"/></td>
<tr><td><?php echo tr("Commance") ?>:</td><td><input type="text" name="comments" value="<?php echo $comments ?>"/></td>
 
<tr>
<td colspan=2>
<input type="submit" name="save" value="Save"/>
&nbsp;
</td>
</tr>
</table>
<input type="hidden" name="new" value="<?php echo $new ?>"/>
</form>
<?php bottom() ?>

</body>
