<?php
	include('include.php');

	$productid = getParam('productid');
	$locationid = getParam('locationid');
	$salesorderid = getParam('salesorderid');
	$purchaseorderid = getParam('purchaseorderid');
	$productionorderid = getParam('productionorderid');
	$date = getMonthStepperDate();

	
 	
	$starttime = parseDate(getParam('starttime'));
	if (isEmpty($starttime))
		$starttime = roundTime(time(), TYPE_MONTHS);
	$endtime = parseDate(getParam('endtime'));
	if (isEmpty($endtime))
		$endtime = addTime($starttime, TYPE_MONTHS);
		
		
	$locationSQL = '';
	if (!isEmpty($locationid)) {
		$locationSQL = " and a.locationid=$locationid ";
	}
  	if (!isEmpty($productid)) 
		$srproductid = " and a.productid=$productid ";
  
  	
	$sql = "
SELECT a.productid as productid, 
b.model AS productname, 
SUM( a.opening_qty ) AS opening_qty, 
SUM( a.moved_in ) AS moved_in, 
SUM( a.moved_out ) AS moved_out, 
SUM( a.closing_qty ) AS closing_qty
FROM (

SELECT a.productid, SUM( if( date_format( b.transtime, '%Y-%m-%e' ) < from_unixtime($starttime), a.diff, 0 ) ) AS opening_qty, SUM( if( date_format( b.transtime, '%Y-%m-%e' ) < from_unixtime($starttime), 0, if( a.diff >0, a.diff, 0 ) ) ) AS moved_in, SUM( if( date_format( b.transtime, '%Y-%m-%e' ) < from_unixtime($starttime), 0, if( a.diff >0, 0, a.diff ) ) ) AS moved_out, SUM( a.diff ) AS closing_qty
FROM stockmove AS a
LEFT JOIN transaction AS b ON a.transactionid = b.transactionid
WHERE date_format( b.transtime, '%Y-%m-%e' ) <= from_unixtime($endtime) $locationSQL   $srproductid 
GROUP BY a.productid
) AS a
LEFT JOIN product AS b ON a.productid = b.productid

	";

		
   
	$sql .= "GROUP BY a.productid"; 
    	
/*	if (!isEmpty($salesorderid))
		$sql .= "join salesorder so on so.orderid=m.salesorderid and so.orderid=$salesorderid ";
	if (!isEmpty($purchaseorderid))
		$sql .= "join purchaseorder po on po.orderid=m.purchaseorderid and po.orderid=$purchaseorderid ";
	if (!isEmpty($productionorderid))
		$sql .= "join productionorder pro on pro.orderid=m.productionorderid and pro.orderid=$productionorderid ";

		
	$startBalance = findValue("select sum(diff)
		                           from stockmove m
		                           join transaction t on t.transactionid=m.transactionid
		                           where productid=$productid and t.transtime < from_unixtime($date) $locationSQL");
		$endBalance = findValue("select sum(diff)
		                           from stockmove m
		                           join transaction t on t.transactionid=m.transactionid
		                           where productid=$productid and t.transtime < from_unixtime($endtime) $locationSQL");
	}
	$sql .= $locationSQL;
	$sql .= "order by moveid desc";
 */   $rs = query($sql);
 	
	$products = rs2array(query("select productid, model from product"));
	$locations = rs2array(query("select locationid, name from location"));	

?>

<head>
<title>ICS System Solutions - <?php etr("Stock moves") ?></title>
<?php 
styleSheet();
include_datebox();
 ?>
</head>

<body>

<?php include("menubar.php") ?>
 
<?php
$title = '';
if (!isEmpty($salesorderid))
	$title = tr("Sales orders") . " > <a href='salesorder.php?orderid=$salesorderid'>$salesorderid</a> > ";
else if (!isEmpty($productid)) {
	$model = findValue("select model from product where productid=$productid");
	$title = tr("Products") . " > <a href='product.php?productid=$productid'>$model</a> > ";
}
$title .= tr("Stock moves");
title($title);
?>

<?php
	echo "<form action='stockmovesallitems.php' method=GET>";
	echo "<div class=border>";
	if (!isEmpty($productid))
		monthStepper($date);
	echo "<center>";

	echo "<table>";

	if (!isEmpty($salesorderid)) {
		echo "<tr><td>" . tr("Sales order") . ":</td><td><a href='salesorder.php?orderid=$salesorderid'>$salesorderid</a></td></tr>";
	} else if (!isEmpty($purchaseorderid)) {
		echo "<tr><td>" . tr("Purchase order") . ":</td><td><a href='purchaseorder.php?orderid=$purchaseorderid'>$purchaseorderid</a></td></tr>";
	} else {
		echo "<tr><td>" . tr("Product") . ":</td>";
		echo "<td>";
		combobox('productid', $products, $productid, true);
		echo "</td>";
		echo "</tr>";
		echo "<tr><td>";
		echo tr("Location") . ":</td>";
		echo "<td>";
		combobox('locationid', $locations, $locationid, true);
		echo "</td></tr>";
?>		
<tr>
	<td><?php etr("Interval") ?>:</td>
	<td>
		<?php datebox("starttime", formatDate($starttime)) ?>
		<?php datebox("endtime", formatDate($endtime)) ?>
	</td>
</tr>
<?php
		echo "<tr><td align=center colspan=2>";
		searchButton();
		echo "</td></tr>";
	}
	echo "</table>";
	echo "</center>";
	echo "</div>";
	echo "</form>";
?>
&nbsp;

<center>
<form action="stockmoves.php" method=POST>
<?php
if (!isEmpty($productid)) {
	echo "<font>" . tr("Starting quantity") . ": $startBalance</font><br><br>";
}
?>        
<table class='main'>
<th><?php etr("Product Id") ?></th>
<th><?php etr("Product Name") ?></th>
<th><?php etr("Opening qty") ?></th>
<th><?php etr("Moved in") ?></th>
<th><?php etr("Moved out") ?></th>
<th><?php etr("Closing qty") ?></th>
<?php
	if (!isEmpty($productid)) {
		echo "<th>" . tr("Order") . "</th>";
	}
  $class = "odd";
    $i = 0;
    while ($row = fetch_object($rs)) {
        echo "<tr class='$class'>";
		echo "<td>$row->productid</td>";
        echo "<td>$row->productname</td>";
		echo "<td>$row->opening_qty</td>";
		echo "<td align=right>$row->moved_in</td>";
		echo "<td align=right>$row->moved_out</td>";
        echo "<td align=right><a href='stockmoves.php?productid=$row->productid&locationid=$locationid'>$row->closing_qty</a></td>";
		 
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
        $i++;
    }
?>
</table>
 
 
 
<br/>  
</form>
</center>
<?php bottom() ?>
</body>
