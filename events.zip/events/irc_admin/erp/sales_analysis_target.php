<?php
	include('include.php');

    $model = getParam('model');
    $locationid = getParam('locationid');
	$type = getParam('type', TYPE_MONTHS);
	if ($type == TYPE_MONTHS)
		$start = getMonthStepperDate();
	else
		$start = getYearStepperDate();
	$end = addTime($start, $type);



	$locationSQL = "1=1";
	if (!isEmpty($locationid)) {
		$locationSQL = "locationid=$locationid";
	}   	
  //,sum(soi.other_disc), sum(soi.invoice_qty), sum(soi.sample_qnt)	 
/*
	$selectSQL = "
SELECT c.categoryid, c.description AS category, p.productid, p.description AS productname, si.orderid, orderdate, sum( si.quantity ) AS quantity, unitprice, sum( si.quantity * unitprice ) AS order_amt, (
si.quantity * unitprice * ( - discountprice /100 ) - other_disc - ( si.quantity * unitprice * ( 1 - discountprice /100 ) - other_disc ) * discount /100
) AS total_discount, (
si.quantity * unitprice * ( 1 + vat /100 - discountprice /100 ) - other_disc - ( si.quantity * unitprice * ( 1 - discountprice /100 ) - other_disc ) * discount /100
) AS net_amt
FROM category c
LEFT JOIN product p ON c.categoryid = p.categoryid
LEFT JOIN (
salesorder_item si
INNER JOIN salesorder so ON si.orderid = so.orderid
) ON p.productid = si.productid
GROUP BY c.categoryid, p.productid, si.orderid
	";
*/

  $selectSQL2 = "
SELECT c.categoryid, c.description AS category,  
sum(pi.quantity ) AS quantity, sum(pi.quantity * unitprice) AS order_amt, 
sum(pi.quantity * unitprice * vat /100) AS vat_amt, sum(pi.quantity * unitprice * ( 1 + vat /100)) AS net_amt
FROM category c
LEFT JOIN product p ON c.categoryid = p.categoryid
LEFT JOIN purchaseorder_item pi ON p.productid = pi.productid
GROUP BY c.categoryid HAVING sum(pi.quantity * unitprice)<>0";
	
	$rs2 = query($selectSQL2);
	
/*	
	  $selectSQLproduct = "
	select
	    productid, model 
	from product";
*/
 


	
#	purchaseorder  -  orderid  supplierid  orderdate  cancelled  payableid  locationid  createdby  
# purchaseorder_item - orderid  no  productid  quantity  unitprice  vat  accountid  comment  received_quantity  

	 
	$locations = rs2array(query("select locationid, name from location"));	

?>

<head>
<title>ICS System Solutions - <?php etr("Sales analysis") ?></title>
<?php
styleSheet();
?>
</head>

<body>

<?php menubar('index.php') ?>
 
<?php title(tr("Sales analysis")) ?>

<form name=searchform action="purchase_analysis_category.php" method="GET">
<div class="border">
<center>
<table class='main'>
<tr>
<td><?php etr("Product") ?>:</td><td><?php textbox('model', $model) ?></td><td width=20/>
<td><?php etr("Location") ?>:</td><td><?php combobox('locationid', $locations, $locationid, true) ?></td>
<td><?php searchButton() ?></td>
</tr>
</table>
<?php 
$yearsChecked = '';
$monthsChecked = '';
if ($type == TYPE_YEARS) {
	yearStepper($start);
	$yearsChecked = 'checked';
} else {
	monthStepper($start); 
	$monthsChecked = 'checked';
}
echo "<input type=radio name=type value='" . TYPE_YEARS . "' $yearsChecked onClick='document.searchform.submit()'>" . tr("Years") . "</input>";
echo "<input type=radio name=type value='" . TYPE_MONTHS . "' $monthsChecked onClick='document.searchform.submit()'>" . tr("Months") . "</input>";
?>
</center>
</div>
</form>
&nbsp;


<a href=sales_analysis_category.php> Category wise </a>

<center>
<input type=hidden name=orderid value='<?php echo $orderid ?>'/>
<table class='main'>
<th><?php etr("Date") ?></th>
<th><?php etr("Day") ?></th>
 <th><?php etr("Shop") ?></th>
<th><?php etr("Product Category") ?></th>
 
<th><?php etr("Achived") ?></th>
<th><?php etr("Target") ?></th>
<th><?php etr("Differ") ?></th>
<th><?php etr("Remarks") ?></th>

<?php  

   while($row2 = fetch_object($rs2)){
      	echo "<tr class='$class'>"; 
        echo "<td  colspan='4'  bgcolor='#FFFFFF'>";
        echo "<b>200$row2->categoryid - $row2->category</b>";
        echo "</td>"; 
        echo "<td  bgcolor='#FFFFFF'>";
        echo "<b>Tk.";
        echo  formatMoney($row2->order_amt);
        echo "</b>";
        echo "</td>      
        </tr>";
        
        $selectSQLproduct = "
SELECT p.productid, p.model  
FROM product p
INNER JOIN purchaseorder_item pi ON p.productid = pi.productid
where p.categoryid =$row2->categoryid
GROUP BY p.productid HAVING sum(pi.quantity * unitprice)<>0";

	
	$rs2product = query($selectSQLproduct);
 
        
                                      
         while($row2product = fetch_object($rs2product)){
                
          //     if($row->quantity>0) {
  	echo "<tr class='$class'>"; 
                  	echo "<td  bgcolor='#FFFFCC'><b>$row2product->productid</b></td>";
                    echo "<td  colspan='6'  bgcolor='#FFFFCC'>";
                    echo "<b>$row2product->model</b>";
             
                    echo "</td></tr>";   
                  
        
        
$selectSQL = "
SELECT c.categoryid, c.description AS category, p.productid, p.model AS productname, pi.orderid, orderdate, 
sum(pi.quantity ) AS quantity, unitprice, sum(pi.quantity * unitprice) AS order_amt, 
sum(pi.quantity * unitprice * vat /100) AS vat_amt, sum(pi.quantity * unitprice * ( 1 + vat /100)) AS net_amt
FROM category c
LEFT JOIN product p ON c.categoryid = p.categoryid
LEFT JOIN (
purchaseorder_item pi
INNER JOIN purchaseorder po ON pi.orderid = po.orderid
) ON p.productid = pi.productid
where  p.categoryid=$row2->categoryid  and p.productid=$row2product->productid  
GROUP BY c.categoryid, p.productid, pi.orderid";
  
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
    
 
     
           
?>  
<?php    


    	$href = "product.php?productid=$row->categoryid";
        echo "<tr class='$class'>";
         echo "<td align=right><a href='$href'>" . $row->orderdate . "</a></td>";
           echo "<td align=right><a href='$href'>" . $row->orderid . "</a></td>";

       // echo "<td><a href='$href'>$row->productid</a></td>";
		       // echo "<td align=right><a href='$href'>$row->productname</a></td>"; 
    
    $href = "sales.php?productid=$row->productid&starttime=$start&endtime=$end";
		
       // echo "<td align=right><a href='$href'>$row->invoice_qty</a></td>";
     //Cat Cat id Productno Product Invoice Quantity Sight Quantity Diff (%) Revenue 
     // c.categoryid,  category, p.productid,  productname, si.orderid, orderdate, quantity, unitprice, order_amt       
         echo "<td align=right><a href='$href'>" . $row->quantity . "</a></td>";
                     echo "<td align=right><a href='$href'>" . $row->unitprice . "</a></td>";
        echo "<td align=right><a href='$href'>" . $row->order_amt . "</a></td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
      //}  
    }  //products
    }//product  group
   } //cat
?>
</table>
</center>
<?php bottom() ?>
</body>
