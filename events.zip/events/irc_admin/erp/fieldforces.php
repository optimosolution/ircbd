<?php
	include('include.php');

    $name = getParam('name');

	$selectSQL = "
	select
	    fieldforceid,
	    name
	from fieldforce
	where name like '$name%'";

?>

<head>
<title>ICS System Solutions - <?php etr("Field Force") ?></title>
<?php styleSheet() ?>
</head>

<body>

<?php menubar('configuration.php') ?>
<?php title(tr("Field Force")) ?>

<form action="fieldforces.php" method="GET">
<div class="border">
<table>
<tr>
	<td><?php etr("Name") ?>:</td>
	<td><?php textbox('name', $name) ?></td>
<tr><td><?php searchButton() ?></td></tr>
</tr>
</table>
</div>
</form>
&nbsp;

<form action="fieldforces.php" method=POST>
<table>
<th><?php etr("Id") ?></th>
<th><?php etr("Name") ?></th>
<?php
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
    	$href = "fieldforce.php?fieldforceid=$row->fieldforceid";
        echo "<tr class='$class'>";
        echo "<td>$row->fieldforceid</td>";
        echo "<td><a href='$href'>$row->name</a></td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table>
<table>
<tr>
<td><?php newButton("fieldforce.php") ?></td>
<td><?php saveButton() ?></td>
</tr>
</table>
</form>
<?php bottom() ?>
</body>
