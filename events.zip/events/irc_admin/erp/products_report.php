<?php
	include('include_report.php');

    $model = getParam('model');
    $locationid = getParam('locationid');
    $supplierid = getParam('supplierid');

 
	$selectSQL = "
	select
	    p.productid,
	    model,
	    unittype,
	    (select sum(diff) from stockmove m where m.productid=p.productid $locationSQL) as quantity,
	    (select sum(soi.quantity)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and so.invoice_transid is null
	     where soi.productid=p.productid $locationSQL) as so_quantity,
	    (select sum(poi.quantity-poi.received_quantity)
	     from purchaseorder_item poi
	     join purchaseorder po on po.orderid=poi.orderid
	     where poi.productid=p.productid $locationSQL) as po_quantity
	from product p 
  where p.productid>=10";
 
 

?>

<head>
<title>ICS System Solutions - <?php etr("Products") ?></title>
<?php
styleSheet();
?>
<style type="text/css">
<!--
.style1 {font-family: Arial, Helvetica, sans-serif}
-->
</style>
</head>

<body>
 
 
<h1><img src="../images/logo.gif" width="564" height="89"><br>
  <fieldset>
  <legend class="style1">Our all Products and Price list</legend>
</h1>
<form action="products.php" method=POST>
<input type=hidden name=mode value='<?php echo $mode ?>'/>
<input type=hidden name=orderid value='<?php echo $orderid ?>'/>
<table border=1>
<th><?php etr("Serial No") ?></th>
<th><?php etr("Productno") ?></th>
<th><?php etr("Product") ?></th>
<th><?php etr("Pack Size") ?></th>
<th><?php etr("Trade Price") ?></th>
 
<?php

 
 

$rs = query($selectSQL);
$class = "odd";
$i=1;
while ($row = fetch_object($rs)) {
	$href = "product.php?productid=$row->productid";
	if ($mode == 'selectproduct')
		$href = "../sales/salesorder.php?orderid=$orderid&productid=$row->productid";
	else if ($mode == 'selectpurchase')
		$href = "purchaseorder.php?orderid=$orderid&productid=$row->productid";
	else if ($mode == 'selectproduction')
		$href = "../manufacturing/productionorder.php?orderid=$orderid&productid=$row->productid";
	echo "<tr class='$class'>";
	
   	echo "<td align=center>$i</td>";
	
	echo "<td>$row->productid</td>";
	echo "<td><a href='$href'>$row->model </a></td>";
	echo "<td align=right>";
  
  $packsizename=findValue("SELECT description 
FROM `unittype` where unittype='$row->unittype'");
echo $packsizename;
  
  echo "</td>";
   		echo "<td align=right><class=sum>";
       $productprice=findValue("SELECT  price   
FROM `sales_price` where productid=$row->productid");
echo formatMoney($productprice); 
      echo "</td>";
 
	echo "</tr>";
	$class = ($class == "odd" ? "even" : "odd");
	$i++;
}
?>
</table>
<br/>
</form>
</body>
