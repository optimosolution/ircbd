<?php
	include('include.php');
	//include('salesorder.inc.php');

    $name = getParam('name');
	$recur = getParam('recur');
	//$lcno = getParam("lcno");
	$del_productid = getParam("del_productid");
	if (!isEmpty($del_productid)) {
		sql("delete from mnf_productrecipe where productid=$del_productid");
		//sql("delete from customer where customerid=$del_customerid");
	}

	$selectSQL = "SELECT
		product.productid,
		product.model,
		product.quantity,
		product.reorder_level
		FROM
		product
		";

	$mode = getParam('mode');

?>

<head>
<title>ICS System Solutions - Product Lowlevel Information</title>
<?php styleSheet() ?>
</head>

<body>

<?php menubar('customers.php') ?>
<?php
	title(tr("Product Lowlevel Information"))
?>

<form action="product_lowlevel.php" method="GET">
<input type=hidden name=mode value='<?php echo $mode ?>'/>
<div class="border">
<table>
<tr><td><?php etr("Product Name") ?>:</td><td><input type="text" name="productid" value="<?php echo $productid ?>"/></td>
<tr><td><?php searchButton() ?></td></tr>
</tr>
</table>
</div>
</form>

<form action="product_lowlevels.php" method=POST>
<table width='100%'>
<!--<th><?php etr("Delete") ?></th>-->
<!-- <th><?php etr("Update") ?></th> -->
<th><?php etr("Product Name") ?></th>
<th><?php etr("Available Quantity") ?></th>
<th><?php etr("Reorder Level") ?></th>

<?php
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
		$href = "salesorder_refund.php?productid=$row->productid";
        echo "<tr class='$class'>";
		
		//deleteColumn("salesorder_refunds.php?del_productid=$row->productid");
		//deleteColumn("lcbuyerinfo.php?buyerid=$row->buyerid");
		//if ($mode == 'update')
		$href = "product_lowlevel.php?productid=$row->productid";
		
		$a = $row->quantity;
		$b = $row->reorder_level;
		$productmodel = findValue("select model from product where productid=$row->productid");
		
		//echo "<td>$row->productid</td>";
		if ($a <= $b)
		{
			if ( $row->productid != 2) 
			{
	
				echo "<td>$productmodel</td>";
				echo "<td><font color=\"#FF0000\">$row->quantity</font></td>";
				echo "<td>$row->reorder_level</td>";

				$class = ($class == "odd" ? "even" : "odd");

			}
		}

		echo "</tr>";

    }
?>
</form>
<?php bottom() ?>
</body>
