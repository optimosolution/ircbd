<?php
	include('include.php');

	checkPermission(PERMISSIONID_MANAGE_PRODUCTS);
	
	$discountpriceid = getParam('discountpriceid');
	$new = true;
	if (isSave()) {
		$discountpriceid = getParam('discountpriceid');
		$description = getParam('description');
		$percent = getParam('percent');
		if (isNew()) {
			$sql = "insert into discountprice (description, dis_percent)  
			        values ('$description', $percent)";
			sql($sql);
			$discountpriceid = insert_id();
		} else {
            $updateSQL =
    			"update discountprice set
    				description='$description',
    			    dis_percent=$percent
                where discountpriceid='$discountpriceid'";
    		sql($updateSQL);
		}
	}
	if (isDelete()) {
		sql("delete from discountprice where discountpriceid='$discountpriceid'");
		$discountpriceid = null;
	}

	$rec = new Dummy();
	if (!isEmpty($discountpriceid)) {
	    $selectSQL =
  		"select discountpriceid,
  		       description,
			   dis_percent
		from discountprice
		where discountpriceid='$discountpriceid'
		";
		$rec = find($selectSQL);
		if ($rec != null) {
			$new = false;
		}
	}

?>
<head>
<title>ICS System Solutions - <?php etr("Discount Price") ?></title>
<?php styleSheet() ?>
</head>

<body>
<?php menubar('configuration.php') ?>
<?php title("<a href='discountprices.php'>" . tr("Discount Price") . "</a> > $rec->description") ?>                                                   

<form action="discountprice.php" method="POST">
<table>
<tr><td>Id:</td>
<td>
<?php
	if ($new) {
	} else {
		echo $discountpriceid;
		echo "<input type='hidden' name='discountpriceid' value='$discountpriceid'/>";
	}
?>
</td>
<tr><td><?php etr("Description") ?>:</td><td><input type="text" name="description" value="<?php echo $rec->description ?>"/></td>
<tr><td><?php etr("Percent") ?>:</td><td><?php numberbox("percent", $rec->dis_percent) ?></td>

<tr>
<td colspan=2>
<?php 
saveButton();
echo "&nbsp;";
deleteButton();
?>
&nbsp;
</td>
</tr>
</table>
<input type="hidden" name="new" value="<?php echo $new ?>"/>
</form>
<?php bottom() ?>
</body>
