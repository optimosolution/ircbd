<?php
	include('include.php');

    $model = getParam('model');
    $locationid = getParam('locationid');
    $supplierid = getParam('supplierid');

    $del_productid = getParam("del_productid");
    if (!isEmpty($del_productid)) {
		deleteProduct($del_productid);
    }

	$locationSQL = '';
	
  $selectSQL2 = "
	select
	    categoryid, description 
	from category ";
	
	$rs2 = query($selectSQL2);
	
  if (!isEmpty($locationid))
		$locationSQL = " and locationid=$locationid ";
	
	
	if($_POST['sortBy'] && $_POST['sortIn'])
	$selectSQL .="ORDER BY p.$_POST[sortBy] $_POST[sortIn]";
	//echo $selectSQL;
	$mode = getParam('mode');
	$orderid = getParam('orderid');

		$categories = rs2array(query("select categoryid, description from category"));
    $locations = rs2array(query("select locationid, name from location"));
	$suppliers = rs2array(query("select supplierid, name from supplier"));

?>

<head>
<title>ICS System Solutions - <?php etr("Products") ?></title>
<?php
styleSheet();
?>
</head>

<body>

<?php menubar('products.php') ?>
 
<?php title(tr("Products")) ?>
<span class="style1">Click here to  <a href="products_report.php" target=_blank> Print Product List</a></span></p>
<table width="100%" border="0">
  <tr>
    <td width="51%">
    
    <form action="products_withcategory.php" method="GET">
<fieldset><legend>Search</legend>

<table class='main'>
  <tr>
    <td><?php etr("Product Name") ?>
      :</td>
    <td><?php textbox('model', $model) ?></td>
	 <td><?php etr("Supplier") ?>
      :</td>
    <td><?php combobox('supplierid', $suppliers, $supplierid, true) ?></td>
  </tr>
  <tr>
    <td><?php etr("Godown/ Showroom") ?>
      :</td>
    <td><?php combobox('locationid', $locations, $locationid, true) ?></td>   <td class=label><?php etr("Category") ?>:</td><td><?php comboBox("categoryid", $categories, $rec->categoryid, false) ?></td>
	<td><?php searchButton() ?></td>
 
    
  </tr>
</table>
</fieldset>
 
</form>
 <!--   
    <fieldset><legend>Sort</legend>
<form action="products.php" method=POST>
<label>sort By</label>
<select name="sortBy">
<option value=""></option>
<option value="productid">productid</option>
<option value="quantity">quantity</option>
</select>



<label>sort In</label>
<select name="sortIn">
<option value=""></option>
<option value="asc">ASC</option>
<option value="desc">DESC</option>
</select>
<?php searchButton() ?>
</form>
</fieldset>
-->


  </tr>
</table>
<form action="products_withcategory.php" method=POST>
<input type=hidden name=mode value='<?php echo $mode ?>'/>
<input type=hidden name=orderid value='<?php echo $orderid ?>'/>
<table class='main'>
<th><?php etr("Productno") ?></th>
<th><?php etr("Product") ?></th>
<th><?php etr("Pack Size") ?></th>
<th><?php etr("Trade Price") ?></th>
 
<?php

	echo "<th>" . tr("Quantity") . "</th>";
if (isEmpty($mode)) {
	echo "<th>" . tr("Ordered qty, sales") . "</th>";
	echo "<th>" . tr("Ordered qty, purchase") . "</th>";
}


$class = "odd";

   while($row2 = fetch_object($rs2)){
      	echo "<tr class='$class'>"; 
        echo "<td>";
        echo "<b>$row2->description</b>";
        echo "</td></tr>";
        
      $selectSQL = "
	select
	    p.categoryid, 
      p.productid,
	    model,
	    unittype,
	    (select sum(diff) from stockmove m where m.productid=p.productid $locationSQL) as quantity,
	    (select sum(soi.quantity)
	     from salesorder_item soi
	     join salesorder so on so.orderid=soi.orderid and so.invoice_transid is null
	     where soi.productid=p.productid $locationSQL) as so_quantity,
	    (select sum(poi.quantity-poi.received_quantity)
	     from purchaseorder_item poi
	     join purchaseorder po on po.orderid=poi.orderid
	     where poi.productid=p.productid $locationSQL) as po_quantity
	from product p where categoryid=$row2->categoryid";

                                $rs = query($selectSQL);
        
while ($row = fetch_object($rs)) {
	$href = "product.php?productid=$row->productid";
	if ($mode == 'selectproduct')
		$href = "../sales/salesorder.php?orderid=$orderid&productid=$row->productid";
	else if ($mode == 'selectpurchase')
		$href = "purchaseorder.php?orderid=$orderid&productid=$row->productid";
	else if ($mode == 'selectproduction')
		$href = "../manufacturing/productionorder.php?orderid=$orderid&productid=$row->productid";
	echo "<tr class='$class'>";
	
 
  echo "<td>$row->productid</td>";
	echo "<td><a href='$href'>$row->model </a></td>";
	echo "<td align=right>";
  
  $packsizename=findValue("SELECT description 
FROM `unittype` where unittype='$row->unittype'");
echo $packsizename;
  
  echo "</td>";
   		echo "<td align=right><class=sum>";
       $productprice=findValue("SELECT  price   
FROM `sales_price` where productid=$row->productid");
echo formatMoney($productprice); 
      echo "</td>";

		$href = "stockmoves.php?productid=$row->productid&locationid=$locationid";
		echo "<td align=right><a href='$href' class=sum>$row->quantity</a></td>";
		if (isEmpty($mode)) {
   	$href = "sales.php?productid=$row->productid&uninvoiced=1";
		echo "<td align=right><a href='$href' class=sum>$row->so_quantity</a></td>";
		$href = "purchaseorders.php?productid=$row->productid";
		echo "<td align=right><a href='$href' class=sum>$row->po_quantity</a></td>";  

	}
	echo "</tr>";
	$class = ($class == "odd" ? "even" : "odd");
	
	}
	echo "<tr><td>&nbsp;</td></tr>";
  }
?>
</table>
<br/>
<?php button("Add product", "add", "product.php") ?>
</form>
<?php bottom() ?>
</body>
