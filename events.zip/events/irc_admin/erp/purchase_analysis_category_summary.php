<?php
	include('include.php');

    $model = getParam('model');
    $locationid = getParam('locationid');
	$type = getParam('type', TYPE_MONTHS);
	if ($type == TYPE_MONTHS)
		$start = getMonthStepperDate();
	else
		$start = getYearStepperDate();
	$end = addTime($start, $type);



	$locationSQL = "1=1";
	if (!isEmpty($locationid)) {
		$locationSQL = "locationid=$locationid";
	}   	
  //,sum(soi.other_disc), sum(soi.invoice_qty), sum(soi.sample_qnt)	 
/*
	$selectSQL = "
SELECT c.categoryid, c.description AS category, p.productid, p.description AS productname, pi.orderid, orderdate, 
sum(pi.quantity ) AS quantity, unitprice, sum(pi.quantity * unitprice) AS order_amt, 
sum(pi.quantity * unitprice * vat /100) AS vat_amt, sum(pi.quantity * unitprice * ( 1 + vat /100)) AS net_amt
FROM category c
LEFT JOIN product p ON c.categoryid = p.categoryid
LEFT JOIN (
purchaseorder_item pi
INNER JOIN purchaseorder po ON pi.orderid = po.orderid
) ON p.productid = pi.productid
GROUP BY c.categoryid, p.productid, pi.orderid";
*/

	$selectSQL = "
SELECT c.categoryid, c.description AS category,  
sum(pi.quantity ) AS quantity, sum(pi.quantity * unitprice) AS order_amt, 
sum(pi.quantity * unitprice * vat /100) AS vat_amt, sum(pi.quantity * unitprice * ( 1 + vat /100)) AS net_amt
FROM category c
LEFT JOIN product p ON c.categoryid = p.categoryid
LEFT JOIN purchaseorder_item pi ON p.productid = pi.productid
GROUP BY c.categoryid";

	
#	purchaseorder  -  orderid  supplierid  orderdate  cancelled  payableid  locationid  createdby  
# purchaseorder_item - orderid  no  productid  quantity  unitprice  vat  accountid  comment  received_quantity  

	 
	$locations = rs2array(query("select locationid, name from location"));	

?>

<head>
<title>ICS System Solutions - <?php etr("Sales analysis") ?></title>
<?php
styleSheet();
?>
</head>

<body>

<?php menubar('index.php') ?>
 
<?php title(tr("Purchase analysis")) ?>

<form name=searchform action="purchase_analysis_category_summary.php" method="GET">
<div class="border">
<center>
<table class='main'>
<tr>
<td><?php etr("Product") ?>:</td><td><?php textbox('model', $model) ?></td><td width=20/>
<td><?php etr("Location") ?>:</td><td><?php combobox('locationid', $locations, $locationid, true) ?></td>
<td><?php searchButton() ?></td>
</tr>
</table>
<?php 
$yearsChecked = '';
$monthsChecked = '';
if ($type == TYPE_YEARS) {
	yearStepper($start);
	$yearsChecked = 'checked';
} else {
	monthStepper($start); 
	$monthsChecked = 'checked';
}
echo "<input type=radio name=type value='" . TYPE_YEARS . "' $yearsChecked onClick='document.searchform.submit()'>" . tr("Years") . "</input>";
echo "<input type=radio name=type value='" . TYPE_MONTHS . "' $monthsChecked onClick='document.searchform.submit()'>" . tr("Months") . "</input>";
?>
</center>
</div>
</form>
&nbsp;


<a href=sales_analysis_category.php> Category wise </a>

<center>

<table class='main'>
<th><?php etr("Category ID") ?></th>
 
<th><?php etr("Category Name") ?></th>
 
<th><?php etr("Quantity") ?></th>

<th><?php etr("Total") ?></th>

<?php
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
    
    	$href = "product.php?productid=$row->categoryid";
        echo "<tr class='$class'>";
  echo "<td align=right><a href='$href'>200" . $row->categoryid . "</a></td>";
 
        echo "<td>$row->category</td>";
 
    
    $href = "sales.php?productid=$row->productid&starttime=$start&endtime=$end";
		
       // echo "<td align=right><a href='$href'>$row->invoice_qty</a></td>";
     //Cat Cat id Productno Product Invoice Quantity Sight Quantity Diff (%) Revenue 
     // c.categoryid,  category, p.productid,  productname, si.orderid, orderdate, quantity, unitprice, order_amt            
        echo "<td align=right><a href='$href'>" . $row->quantity . "</a></td>";
        echo "<td align=right><a href='$href'>Tk." . formatMoney($row->order_amt) . "</a></td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table>
</center>
<?php bottom() ?>
</body>
