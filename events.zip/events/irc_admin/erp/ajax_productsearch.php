<?php
include('../conf/config.php');
$connection = @mysql_connect(DBHOST, DBUSER, DBPWD) or die("Couldn't connect to server. " . mysql_error());
$db = @mysql_select_db(DBNAME, $connection) or die("Couldn't select database");

$q = strtolower($_GET["q"]);
if (!$q) return;

$query="select  productid, model from product";
$res=mysql_query($query) or die(mysql_error());
while($row=mysql_fetch_array($res))
 {
    $genvalue=substr(strtolower($row['model']),0,count($q));
    if (strtolower($genvalue) == strtolower($q)) {
                $value=$row['productid'];
                $key=$row['model'];
		echo "$key|$value\n";
	}
}

?>