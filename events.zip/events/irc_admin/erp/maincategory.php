<?php
	include('include.php');

	checkPermission(PERMISSIONID_MANAGE_PRODUCTS);

	$maincategoryid = getParam('maincategoryid');
	$new = true;
	if (isSave()) {
		$maincategoryid = getParam('maincategoryid');
		$accountid = getParam('accountid');
		$name = getParam('name');
	
		if (isNew()) {
			$sql = "insert into maincategory (name)
			        values ('$name')";
			sql($sql);
			$maincategoryid = insert_id();
		} else {
            $updateSQL =
    			"update maincategory set
    				name='$name'
                where maincategoryid='$maincategoryid'";
    		sql($updateSQL);
		}
	}
	if (isDelete()) {
		sql("delete from maincategory where maincategoryid='$maincategoryid'");
		$maincategoryid = null;
	}

	$rec = new Dummy();
	if (!isEmpty($maincategoryid)) {
	    $selectSQL =
  		"select maincategoryid,
  		       name
		from maincategory
		where maincategoryid='$maincategoryid'
		";
		$rec = find($selectSQL);
		if ($rec != null) {
			$new = false;
		}
	}

	

?>
<head>
<title>ICS System Solutions - <?php etr("Main Category") ?></title>
<?php styleSheet() ?>
</head>

<body>
<?php menubar('configuration.php') ?>
<?php title("<a href='maincategories.php'>" . tr("Main Categories") . "</a> > $rec->name") ?>

<form action="maincategory.php" method="POST">
<table>
<tr><td>Id:</td>
<td>
<?php
	if ($new) {
	} else {
		echo $maincategoryid;
		echo "<input type='hidden' name='maincategoryid' value='$maincategoryid'/>";
	}
?>
</td>
<tr><td><?php etr("name") ?>:</td><td><input type="text" name="name" value="<?php echo $rec->name ?>"/></td>

<tr>
<td colspan=2>
<?php
saveButton();
echo "&nbsp;&nbsp;";
deleteButton();
?>
&nbsp;
</td>
</tr>
</table>
<input type="hidden" name="new" value="<?php echo $new ?>"/>
</form>
<?php bottom() ?>
</body>
