<?php include("include.php") ?>

<head>
<title>ICS System Solutions - <?php etr("Sales") ?></title>
<?php styleSheet() ?>
</head>

<body>

<div class=main>
<table width="100%" cellspacing=0 cellpadding=0>
<tr class=menubar><td style="padding: 2"></td></tr>
</table>
<?php 

menubar('index.php', 'index_help.php');
//menupage_begin();
?>


<table border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" id="AutoNumber1">
  <tr>
    <td width="20%"valign='top'>
    <?php
    include('../res/calendar_code.php');
    ?>
    
   
    <br><br><br><br>
    
    </td>
    <td width="80%">

<ul>
<li class=menupage>
<a href='products_report.php' id='newcacheorder' tabindex=1 accesskey='C' class=menupage
	title='<?php etr("Print Product List")?>'>
<?php etr("Print Product List") ?>
</a>
</li>
<script>document.getElementById('newcacheorder').focus();</script>
<li class=menupage>
<a href='purchase_analysis_category.php' tabindex=2 accesskey='O' class=menupage
   title='<?php etr("Purchase Details Report")?>'>
<?php etr("Purchase Details Report") ?>
</a>
</li>
  
<li class=menupage>
<a href='stockmovesallitems.php' class=menupage>
<?php etr("Stock Moves all Items") ?>
</a>
</li>
 
<li class=menupage>
<a href='purchase_analysis_category_summary.php' tabindex=3 class=menupage
	title='<?php etr("purchase summarized report")?>'>
<?php etr("purchase summarized report") ?>
</a>
</li>

<li class=menupage>
<a href='products_withcategory.php' class=menupage title='<?php etr("products_withcategory")?>'>
<?php etr("products_withcategory") ?>
</a>
</li>
 
 
</ul>

 
    
    </td>
  </tr>
</table>


<?php bottom(); // menupage_end() 
 
?>
<?php //menupage_end() ?>
</div>
</body>
