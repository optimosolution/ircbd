<?php
	include('include.php');

    $name = getParam('name');

	$selectSQL = "
	select
	    maincategoryid,
	    name
	from maincategory
	where name like '$name%'";

?>

<head>
<title>ICS System Solutions - <?php etr("Main Categories") ?></title>
<?php styleSheet() ?>
</head>

<body>

<?php menubar('configuration.php') ?>
<?php title(tr("Main Categories")) ?>

<form action="maincategories.php" method="GET">
<div class="border">
<table class='main'>
<tr>
	<td><?php etr("Search Category") ?>:</td>
	<td><?php textbox('name', $name) ?></td>
<tr><td><?php searchButton() ?></td></tr>
</tr>
</table>
</div>
</form>
&nbsp;

<form action="maincategories.php" method=POST>
<table class='main'>
<th><?php etr("Id") ?></th>
<th><?php etr("Name") ?></th>
<?php
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
    	$href = "maincategory.php?maincategoryid=$row->maincategoryid";
        echo "<tr class='$class'>";
        echo "<td>$row->maincategoryid</td>";
        echo "<td><a href='$href'>$row->name</a></td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table>
<table class='main'>
<tr>
<td><?php newButton("maincategory.php") ?></td>
<td><?php saveButton() ?></td>
</tr>
</table>
</form>
<?php bottom() ?>
</body>
