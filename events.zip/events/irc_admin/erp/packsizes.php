<?php
	include('include.php');

    $name = getParam('name');

	$selectSQL = "
	select
	    packsizeid,
	    name
	from packsize
	where name like '$name%'";

?>

<head>
<title>ICS System Solutions - <?php etr("Packsize") ?></title>
<?php styleSheet() ?>
</head>

<body>

<?php menubar('configuration.php') ?>
<?php title(tr("Packsizes")) ?>

<form action="packsizes.php" method="GET">
<div class="border">
<table>
<tr>
	<td><?php etr("Name") ?>:</td>
	<td><?php textbox('name', $name) ?></td>
<tr><td><?php searchButton() ?></td></tr>
</tr>
</table>
</div>
</form>
&nbsp;

<form action="packsizes.php" method=POST>
<table>
<th><?php etr("Id") ?></th>
<th><?php etr("Name") ?></th>
<?php
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
    	$href = "packsize.php?packsizeid=$row->packsizeid";
        echo "<tr class='$class'>";
        echo "<td>$row->packsizeid</td>";
        echo "<td><a href='$href'>$row->name</a></td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table>
<table>
<tr>
<td><?php newButton("packsize.php") ?></td>
<td><?php saveButton() ?></td>
</tr>
</table>
</form>
<?php bottom() ?>
</body>
