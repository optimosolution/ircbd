<?php
	include('include.php');

    $name = getParam('name');
    $description = getParam('description');

	$selectSQL = "
	select
	    id,
	    name,
	    description
	from invoicetype
	where description like '$description%'";

?>

<head>
<title>ICS System Solutions - <?php etr("Invoice Type") ?></title>
<?php styleSheet() ?>
</head>

<body>

<?php menubar('configuration.php') ?>
<?php title(tr("Invoice Type")) ?>

<form action="invoicetypes.php" method="GET">
<div class="border">
<table>
<tr><td><?php etr("Name") ?>:</td><td><input type="text" model="name" value="<?php echo $name ?>"/></td>
<tr><td><input type="submit" model="search" value="<?php etr("Search") ?>" /></td></tr>
</tr>
</table>
</div>
</form>
&nbsp;

<form action="invoicetypes.php" method=POST>
<table>
<th><?php etr("Id") ?></th>
<th><?php etr("Name") ?></th>
<th><?php etr("Description") ?></th>
<?php
    $rs = query($selectSQL);
    $class = "odd";
    while ($row = fetch_object($rs)) {
    	$href = "invoicetype.php?id=$row->id";
        echo "<tr class='$class'>";
        echo "<td>$row->id</td>";
        echo "<td><a href='$href'>$row->name</a></td>";
        echo "<td align=right>$row->description</td>";
        echo "</tr>";
        $class = ($class == "odd" ? "even" : "odd");
    }
?>
</table>
<table>
<tr>
<td><?php newButton("invoicetype.php") ?></td>
<td><?php saveButton() ?></td>
</tr>
</table>
</form>
<?php bottom() ?>
</body>
