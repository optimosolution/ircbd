<?php 
    include('include.php'); 
    include('salesorder.inc.php');
    
    if(isSave()){

        $rsc_for = getParam('rsc_for');
        
        $sql = "INSERT INTO
            resource_for 
                SET
            resource_for = '$rsc_for'";
        
        sql($sql);
        $success = "<div style='text-align:center; color:green; padding:10px; border:1px solid green;margin-bottom: 10px;'>Saving Successfull</div>";
    }

    menubar(''); 


?>
<?php
    if(!empty($success)){echo $success;}
?>
<form action="" method="POST"  enctype="multipart/form-data"> 
<table align="center">
    <tr><td class=label><?php echo tr("Resource for") ?>:</td><td><input type="text" name="rsc_for" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"/>*</td></tr>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <tr><td class=label></td><td><?php saveButton() ?></td></tr>
</table>
</form>
<script> $.validate(); </script>
