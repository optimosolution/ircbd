<?php
include('conn/db_connect.php');

//$place = $_POST['curier_name'];
$au = "";
mysql_query("set names 'utf8'");
$au = mysql_query("select author_id, author_name from author_info");

while ($authors = mysql_fetch_assoc($au)){
    $auth .= "'".au['author_name']."',";
            
}
echo $auth;

?>

