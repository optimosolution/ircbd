<?php 
    include('include.php'); 
    include('salesorder.inc.php');
    menubar(''); 
    
    $resource_category = rs2array(query("select resource_category_id, resource_category from resource_category"));
    $resource_for = rs2array(query("select resource_for_id, resource_for from resource_for"));
    $resource_type = rs2array(query("select resource_type_id, resource_type from resource_type"));
    $author = rs2array(query("select author_id, author_name from author_info"));
    $resource = rs2array(query("select resource_id, resource_title from resources"));
    
    if(isDelete()){
        
        $resource_value = getParam('delete');

        if($resource_value == 'Delete Resource'){
              $val = getParam('resource');
              $sql="DELETE FROM resources WHERE resource_id='$val'";
        }
        elseif($resource_value == 'Delete Category'){
             $val = getParam('resource_category');
             $sql="DELETE FROM resource_category WHERE resource_category_id='$val'";
        }
        elseif($resource_value == 'Delete For'){
             $val = getParam('resource_for');
             $sql="DELETE FROM resource_for WHERE resource_for_id='$val'";
        }
        elseif($resource_value == 'Delete Type'){
             $val = getParam('resource_type');
             $sql="DELETE FROM resource_type WHERE resource_type_id='$val'";
        }
        else{
             $val = getParam('author');
             $sql="DELETE FROM author_info WHERE author_id='$val'";
        }
        sql($sql);
        header('location:delete.php');
    }

?>
<style>select{width:350px !important;}</style>
<table align="left">
    <form action="" method="POST"><tr><td><?php combobox("resource", $resource, $rec->resource, true) ?></td><td class=label><?php button("Delete Resource","delete"); ?></td></tr></form>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <form action="" method="POST"> <tr><td><?php combobox("resource_category", $resource_category, $rec->resource_category, true) ?></td><td class=label><?php button("Delete Category","delete"); ?></td></tr></form>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <form action="" method="POST">  <tr><td><?php combobox("resource_for", $resource_for, $rec->resource_for, true) ?></td><td class=label><?php button("Delete For","delete"); ?></td></tr></form>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <form action="" method="POST"> <tr><td><?php combobox("resource_type", $resource_type, $rec->resource_type, true) ?></td><td class=label><?php button("Delete Type","delete"); ?></td></tr></form>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <form action="" method="POST"> <tr><td><?php combobox("author", $author, $rec->author, true) ?></td><td class=label><?php button("Delete Author","delete"); ?></td></tr></form>
    <tr><td class=label></td><td>&nbsp;</td></tr>
</table>

<table align="right">
    <form action="" method="GET"><tr><td><?php combobox("e_resource", $resource, $rec->resource, true) ?></td><td class=label><?php button("Edit Resource","Edit"); ?></td></tr></form>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <form action="" method="GET"> <tr><td><?php combobox("e_resource_category", $resource_category, $rec->resource_category, true) ?></td><td class=label><?php button("Edit Category","Edit"); ?></td></tr></form>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <form action="" method="GET">  <tr><td><?php combobox("e_resource_for", $resource_for, $rec->resource_for, true) ?></td><td class=label><?php button("Edit For","Edit"); ?></td></tr></form>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <form action="" method="GET"> <tr><td><?php combobox("e_resource_type", $resource_type, $rec->resource_type, true) ?></td><td class=label><?php button("Edit Type","Edit"); ?></td></tr></form>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <form action="add_author.php" method="GET"> <tr><td><?php combobox("e_author", $author, $rec->author, true) ?></td><td class=label><?php button("Edit Author","Edit"); ?></td></tr></form>
    <tr><td class=label></td><td>&nbsp;</td></tr>
</table>