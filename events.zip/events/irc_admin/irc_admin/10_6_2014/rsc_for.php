<?php 
    include('include.php'); 
    include('salesorder.inc.php');
    
    if(isSave()){

        $rsc_for = getParam('rsc_for');
        mysql_query("set names 'utf8'");
        $sql = "INSERT INTO
            resource_for 
                SET
            resource_for = '$rsc_for'";
        
        sql($sql);
        $resource_for_id = insert_id();
    }

    menubar(''); 


?>
<form action="" method="POST"  enctype="multipart/form-data"> 
<table align="center">
    <tr><td class=label><?php echo tr("Resource for") ?>:</td><td><input type="text" name="rsc_for" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"/>*</td></tr>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <tr><td class=label></td><td><?php saveButton() ?></td></tr>
</table>
</form>
<script> $.validate(); </script>