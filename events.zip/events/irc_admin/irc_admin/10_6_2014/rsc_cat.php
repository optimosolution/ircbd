<?php 
    include('include.php'); 
    include('salesorder.inc.php');
    
    if(isSave()){

        $category_name = getParam('category_name');
        $slug = getParam('slug');
        $sort = getParam('sort');
        mysql_query("set names 'utf8'");
        $sql = "INSERT INTO
            resource_category 
                SET
            resource_category = '$category_name',
            slug = '$slug',
            _sort = '$sort'";
        
        sql($sql);
        $resource_category = insert_id();
    }

    menubar(''); 


?>
<form action="" method="POST"  enctype="multipart/form-data"> 
<table align="center">
    <tr><td class=label><?php echo tr("Category Name") ?>:</td><td><input type="text" name="category_name" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"/>*</td></tr>
    <tr><td class=label><?php echo tr("Slug") ?>:</td><td><input type="text" name="slug"/></td></tr>
    <tr><td class=label><?php echo tr("Sorting") ?>:</td><td><input type="text" name="sort"/></td></tr>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <tr><td class=label></td><td><?php saveButton() ?></td></tr>
</table>
</form>
<script> $.validate(); </script>