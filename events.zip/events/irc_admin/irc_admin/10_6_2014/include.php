<link rel="stylesheet" type="text/css" href="../css/main.css"/>
<link rel="stylesheet" type="text/css" href="../css/ics._onebook.css"/>
<script type="text/javascript" src="jquery-1.7.2.min.js"></script>
<script type="text/javascript" src="jquery.form-validator.min.js"></script>



<?php
include('../include/therp_include.php');

define('METHOD_CASH', 1);
define('METHOD_CARD', 2);

function menubar($currentHref = null, $helpUrl = 'http://icsss.co.uk/acconline')
{
	top0("");
	echo "<table width='100%' cellspacing=0 cellpadding=20 >";
	echo "<tr>";
	echo "<td>";
	echo "<table width='100%' class=menubar cellpadding=10>";
		echo "<tr>";
			$percent = 10;
                        $percent1 = 20;
			menu('add_resource.php', 'Add Resource', $percent, true, $currentHref);
                        menu('rsc_type.php', 'Add Resource Type', $percent, true, $currentHref);
                        menu('rsc_for.php', 'Add Resource For', $percent, true, $currentHref);
                        menu('rsc_cat.php', 'Add Resource Category', $percent, true, $currentHref);
                        menu('add_author.php', 'Add Author', $percent, true, $currentHref);
                        menu('delete.php', 'Resource Record Modification', $percent1, true, $currentHref);
		echo "</tr>";
	echo "</table>";
	echo "</td>";
	echo "</tr>";
	echo "</table>";
	//showUpgrade();
}

?>