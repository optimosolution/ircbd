<?php 
    include('include.php'); 
    include('salesorder.inc.php');
    menubar(''); 
    
    
    if(isSave()){
        $rsc_type = getParam('rsc_type');
		mysql_query("set names 'utf8'");
        $sql = "INSERT INTO
            resource_type 
                SET
            resource_type = '$rsc_type'";
        
        sql($sql);
        $resource_type_id = insert_id();
    }

?>
<form action="" method="POST"  enctype="multipart/form-data"> 
<table align="center">
    <tr><td class=label><?php echo tr("Category Name") ?>:</td><td><input type="text" name="rsc_type"/>*</td></tr>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <tr><td class=label></td><td><?php saveButton() ?></td></tr>
</table>
</form>
<script> $.validate(); </script>