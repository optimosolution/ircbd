<?php 
    include('include.php'); 
    include('salesorder.inc.php');
    
    if(isSave()){

        $resource_code = getParam('resource_code');
        $resource_title = getParam('resource_title');
        $resource_category = getParam('resource_category');
        $resource_for = getParam('resource_for');
        $resource_type = getParam('resource_type');
        $resource_size = getParam('resource_size');
        $author = getParam('author');
        $co_author = getParam('co_author');
        $search_text = getParam('search_text');
        $description = getParam('description');
        $main_source = getParam('main_source');
        $mirror1 = getParam('mirror1');
        $mirror2 = getParam('mirror2');
        $resource_location = getParam('resource_location');
        $sort_by = getParam('sort_by');
        $entry_by = getParam('entry_by');
        
        $errors= array();
        $file_name = $_FILES['image']['name'];
        $file_size =$_FILES['image']['size'];
        $file_tmp =$_FILES['image']['tmp_name'];
        $file_type=$_FILES['image']['type'];   
        $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));

        $expensions= array("jpeg","jpg","png","gif"); 		
        if(in_array($file_ext,$expensions)== false){
                $errors[]="Please choose a JPEG or PNG file.";
        }
        if($file_size > 4097152){
        $errors[]='File size must lower than 4 MB';
        }				
        if(empty($errors)==true){
                move_uploaded_file($file_tmp,"../../images/upload/".$file_name);
                $img_location = "images/upload/".$file_name;
        }else{
            foreach ($errors as $err){$file_error = $err.'<br/>';}
        }      

        mysql_query("set names 'utf8'");
        $chk = mysql_query("SELECT resource_code FROM resources WHERE resource_code='$resource_code'");
        $num_chk = mysql_num_rows($chk);

        if ($num_chk > 0) {
          $duplicate_code = "Duplicate Resource Code";
        }
        else {
            mysql_query("set names 'utf8'");
            $sql = "INSERT INTO
                resources 
                    SET
                resource_code = '$resource_code',
                resource_title = '$resource_title',
                resource_category = '$resource_category',
                resource_for = '$resource_for',
                resource_type = '$resource_type',
                size_info = '$resource_size',
                sort_description = '$description',
                img_location = '$img_location',
                author_id = '$author',
                co_author = '$co_author',
                search_text = '$search_text',
                _sort = '$sort_by',
                main_source = '$main_source',
                mirror1 = '$mirror1',
                mirror2 = '$mirror2',
                resource_location = '$resource_location',
                created_by='$entry_by' ";


            $src = explode(",", $search_text);
            foreach ($src as $search){
                mysql_query("set names 'utf8'");
                $sql1 = mysql_query("INSERT INTO search_text SET search_text='$search'");
            }
            sql($sql);
             $success = "<div style='text-align:center; color:green; padding:10px; border:1px solid green;margin-bottom: 10px;'>Saving Successfull</div>";
        }
    }

    menubar(''); 
  
    $resource_category = rs2array(query("select resource_category_id, resource_category from resource_category"));
    $resource_for = rs2array(query("select resource_for_id, resource_for from resource_for"));
    $resource_type = rs2array(query("select resource_type_id, resource_type from resource_type"));
    $author = rs2array(query("select author_id, author_name from author_info"));

?>
<?php
    if(!empty($success)){echo $success;}
?>
<form action="" method="POST"  enctype="multipart/form-data"> 
<table align="center">  
    <tr>
        <td class=label><?php echo tr("Resource Code") ?>:</td>
        <td>
            <input type="text" name="resource_code" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"/>
            *
            <?php
            if(!empty($duplicate_code)){echo 'Resource Code duplicate';}
            ?>
        </td>
    </tr>
    <tr><td class=label><?php echo tr("Resource Title") ?>:</td><td><input type="text" name="resource_title" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"/>*</td></tr>
    <tr><td class=label><?php echo tr("Resource Category") ?>:</td><td><?php combobox("resource_category", $resource_category, $rec->countrycode, true) ?></td></tr>
    <tr><td class=label><?php echo tr("Resource For") ?>:</td><td><?php combobox("resource_for", $resource_for, $rec->resource_for, true) ?></td></tr>
    <tr><td class=label><?php echo tr("Resource Type") ?>:</td><td><?php combobox("resource_type", $resource_type, $rec->resource_type, true) ?></td></tr>
    <tr><td class=label><?php echo tr("Resource Size") ?>:</td><td><input type="text" name="resource_size"/></td></tr>
    <tr><td class=label><?php echo tr("Author") ?>:</td><td><?php combobox("author", $author, $rec->author, true) ?></td></tr>
    <tr><td class=label><?php echo tr("Co-author") ?>:</td><td><input type="text" name="co_author"/></td></tr>
    <tr><td class=label><?php echo tr("Search Text") ?>:</td><td><input type="text" name="search_text" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"/>*</td></tr>
    <tr><td class=label><?php echo tr("Sort Description") ?>:</td><td><textarea rows="5" type="textarea" name="description" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"></textarea>*</td></tr>
    <tr><td class=label><?php echo tr("Main Source") ?>:</td><td><input type="text" name="main_source"/></td></tr>
    <tr><td class=label><?php echo tr("Mirror 1") ?>:</td><td><input type="text" name="mirror1"/></td></tr>
    <tr><td class=label><?php echo tr("Mirror 2") ?>:</td><td><input type="text" name="mirror2"/></td></tr>
    <tr><td class=label><?php echo tr("Resource Location") ?>:</td><td><input type="text" name="resource_location"/></td></tr>
    <tr><td class=label><?php echo tr("Sort By") ?>:</td><td><input type="text" name="sort_by"/></td></tr>
    <tr><td class=label><?php echo tr("Entry BY") ?>:</td><td><input type="text" name="entry_by" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"/>*</td></tr>
    <tr><td class=label><?php echo tr("Resource Image") ?>:</td><td><input type="file" name="image" /></td></td></tr>
    <tr><td class=label></td><td><?php echo $file_error; ?></td></tr>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <tr><td class=label></td><td><?php saveButton() ?></td></tr>
</table>
</form>
<script> 
    $.validate(); 
</script>