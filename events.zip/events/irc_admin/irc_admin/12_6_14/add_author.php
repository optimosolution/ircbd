<?php 
    include('include.php'); 
    include('salesorder.inc.php');
    $edit_id = $_GET['e_author'];
    $data= find("select * from author_info where author_id='$edit_id'");
    //print_r($data);
    
    if($_POST){
        $author_name = getParam('author_name');
        $author_desc1 = getParam('author_desc1');
        $author_desc2 = getParam('author_desc2');
        $sort = getParam('sort');

        $errors= array();
        $file_name = $_FILES['image']['name'];
        $file_size =$_FILES['image']['size'];
        $file_tmp =$_FILES['image']['tmp_name'];
        $file_type=$_FILES['image']['type'];   
        $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));

        $expensions= array("jpeg","jpg","png","gif"); 		
        if(in_array($file_ext,$expensions)== false){
                $errors[]="extension not allowed, please choose a JPEG or PNG file.";
        }
        if($file_size > 4097152){
        $errors[]='File size must lower than 4 MB';
        }				
        if(empty($errors)==true){
                move_uploaded_file($file_tmp,"../../images/author_info/".$file_name);
                $img_location = "images/author_info/".$file_name;
        }else{
            foreach ($errors as $err){$file_error = $err.'<br/>';}
        }   

           
        
        /************************************/
        mysql_query("set names 'utf8'");
        if($edit_id != ""){
            $sql = "UPDATE
                author_info 
            SET
                author_name = '$author_name',
                author_desc1 = '$author_desc1',
                author_desc2 = '$author_desc2',
                _sort = '$sort',
                author_photo = '$img_location' 
            WHERE 
                author_id='$edit_id'";
        }
        else{
            $sql = "INSERT INTO
                author_info 
            SET
                author_name = '$author_name',
                author_desc1 = '$author_desc1',
                author_desc2 = '$author_desc2',
                _sort = '$sort',
                author_photo = '$img_location' ";
            }
        sql($sql);
        $msg = "Successful";
    }

menubar(''); 
?>
<form action="" method="POST"  enctype="multipart/form-data"> 
<table align="center">
    <tr><td class=label><?php echo tr("Full Name") ?>:</td><td><input value="<?php echo $data->author_name; ?>" type="text" name="author_name" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"/>*</td></tr>
    <tr><td class=label><?php echo tr("Sort Description 1") ?>:</td><td><textarea rows="5" type="textarea" name="author_desc1" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"><?php echo $data->author_desc1; ?></textarea>*</td></tr>
     <tr><td class=label><?php echo tr("Sort Description 2") ?>:</td><td><textarea rows="5" type="textarea" name="author_desc2" data-validation="length" data-validation-length="min1" data-validation-error-msg=" Input required"><?php echo $data->author_desc2; ?></textarea>*</td></tr>
      <tr><td class=label><?php echo tr("Sorting") ?>:</td><td><input value="<?php echo $data->_sort; ?>" type="text" name="sort"/></td></tr>
      <tr><td class=label><?php echo tr("Author Image") ?>:</td><td><input type="file" name="image" /></td></td></tr>
    <tr><td class=label></td><td><?php echo $msg;// echo $file_error; ?></td></tr>
    <tr><td class=label></td><td>&nbsp;</td></tr>
    <tr><td class=label></td><td><?php saveButton() ?></td></tr>
</table>
</form>
<script> $.validate(); </script>