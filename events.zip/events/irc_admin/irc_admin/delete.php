<?php 
    include('include.php'); 
    include('salesorder.inc.php');
    menubar(''); 
?>


    <div style="margin-left: 40px; margin-top: 10px;">
<div id="deldel">        
<?php
    if(isset($_POST["del"])){
       $del_id = $_POST['res_del'];
       //print_r($del_id);
       //echo 'jj';
       foreach($del_id as $delid){
           //echo $delid;
        if(!empty($delid)){
            mysql_query("DELETE FROM resources WHERE resource_id='$delid'");}
        else{
            echo "<div style='width:100%; text-align: center;'>Select a Checkbox to delete<br/><br/></div>";
        }
       }
    }
?>
</div>
    <div style="padding: 10px; border: 1px solid #eee; width: 50%; margin-bottom: 10px;">
        <b>Keyword : &nbsp;</b>
        <input style="width: 70%" type="text" name="src" value=""/>&nbsp;
        <input type="submit" value="Search" name="src_del" />
    </div>



    <form id="fff" action="" method="post">
    <?php mysql_query("set names 'utf8'");
          $resorce = mysql_query("SELECT resource_id,resource_title FROM resources ORDER BY resource_id DESC");
          while($ress = mysql_fetch_assoc($resorce)){ ?>
        
        <input type="checkbox" name="res_del[]" value="<?php echo $ress['resource_id'];?>">&nbsp;
        <?php echo $ress['resource_title'];?><br>
        
    <?php } ?>     
        <input type="submit" value="Delete" id="del" name="del" />
    </form>

</div>
<script>

</script>
