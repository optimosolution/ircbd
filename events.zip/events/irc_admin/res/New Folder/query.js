// Input 0
var counter=0;
var urlOrQuery="";
var Pb=false;
var lastSearchText="";
var fa=false;
var searchText="";
var H="";
var keyPressed="";
var indexOfSelectedItem=-1;
var theIndex=null;
var Z=-1;
var Ia=null;
var Na=5;
var rightSideText="";
var Tb="div";
var Kb="span";
var submitButton=null;
//habib: v2
var theIDField=null;
var theField=null;
var theDroplist=null;
var xb=null;
var W=null;
var la=null;
var za=false;
var cachedResult=new Object();
var ea=1;
var Ma=1;
var va=false;
var aa=false;
var ua=-1;
var gb=(new Date()).getTime();
var P=false;
var theCallerCtrl=null;
var query_url=null;
var query_path=null;
var theFrame=null;
var currentFieldText=null;
var noErrors=false;
var Ua=false;
var leftColWidth=60;
var table_name=null;
var Ha=null;
var timerSpeed=0;
var hb=null;
var ma=null;
var oa=null;
var Ea=false;
var is_focused=false;

//<input autocomplete="off" maxlength=2048 size=55 name=q value="" title="Google Search">
//<input type=submit value="Google Search" name=btnG>
//<form action=/search name=f>
//<SCRIPT>InstallAC(document.f,document.f.q,"search",document.f.btnG,"en");</SCRIPT>

InstallAC=function(fld,_table_name,frm,submit_button,rl,hd,sm,ufn)
{
	tags=fld.parentNode.getElementsByTagName("input")
	for(i=0;i<tags.length;i++)
	{
		if(/_id$/.test(tags[i].id))
		{
			theIDField = tags[i]
			break;
		}
	}

	submitButton=frm;
	theField=fld;
	if(!_table_name)_table_name="search";
	table_name=_table_name;
	var Sb="zh|zh-CN|zh-TW|getCursorPosition|ko|";
	if(!rl||rl.length<1)rl="en";
	la=yb(rl);
	if(Sb.indexOf(la+"|")==-1)
	{
		W=true;
		aa=false;
		va=false;
		noErrors=false
	}
	else
	{
		W=false;
		aa=true;
		if(la.indexOf("zh")==0)va=false;
		noErrors=true
	}
	if(!hd)hd=false;
	Ha=hd;
	if(!sm)sm="query";
	urlOrQuery=sm;
	xb=ufn;
	part_two()
}

;
function refocusTheField()
{
	za=true;
	theField.blur();
	setTimeout("setFocusOnTheField();",10);
	return
}

function triggerCtrlDownArrow()
{
	if(document.createEventObject)
	{
		var Ka=document.createEventObject();
		Ka.ctrlKey=true;
		Ka.keyCode=70;
		document.fireEvent("onkeydown",Ka)
	}

}

function keyDownHandler(h)
{
	if(!h&&window.event)h=window.event;
	if(h)ua=h.keyCode;
	if(h&&h.keyCode==8)
	{
		if(
			W
			&&(
				theField.createTextRange
				&& (
					h.srcElement==theField
					&& (
						getCursorPosition(theField)==0 && qa(theField)==0
		))))
		{
			nc(theField);
			h.cancelBubble=true;
			h.returnValue=false;
			return false
		}

	}

}

function Mb()
{
	if(urlOrQuery=="url")
	{
		resizeTextField()
	}
	position_droplist()
}

function position_droplist()
{
	if(theDroplist)
	{
		theDroplist.style.left=zb(theField)+"px";
		theDroplist.style.top=Yb(theField)+theField.offsetHeight-1+"px";
		theDroplist.style.width=Ta()+"px"
	}

}

function Ta()
{
	if(navigator&&navigator.userAgent.toLowerCase().indexOf("msie")==-1)
	{
		return theField.offsetWidth-ea*2
	}
	else
	{
		return theField.offsetWidth
	}

}

function part_two()
{
	if(httpxmlCtrl())
	{
		P=true
	}
	else
	{
		P=false
	}
	query_path="/wb/erp/";
	query_url=query_path+"query.php?sql="+table_name;
	if(!P)
	{
		ya("qu","",0,query_path,null,null)
	}
	if(submitButton) submitButton.onsubmit=postData;
	theField.autocomplete="off";
	theField.onblur=onBlurHandler;

	if(theField.createTextRange)
		theField.onkeyup=new Function("return okuh(event);");
	else
		theField.onkeyup=okuh;

	theField.onsubmit=postData;
	searchText=theField.value;
	lastSearchText=searchText;
	if(!(theDroplist=document.getElementById("completeDiv")))
	{
		theDroplist=document.createElement("DIV");
		theDroplist.id="completeDiv";
		theDroplist.style.borderRight="black "+ea+"px solid";
		theDroplist.style.borderLeft="black "+ea+"px solid";
		theDroplist.style.borderTop="black "+Ma+"px solid";
		theDroplist.style.borderBottom="black "+Ma+"px solid";
		theDroplist.style.zIndex="1";
		theDroplist.style.paddingRight="0";
		theDroplist.style.paddingLeft="0";
		theDroplist.style.paddingTop="0";
		theDroplist.style.paddingBottom="0";
		theDroplist.style.visibility="hidden";
		theDroplist.style.position="absolute";
		theDroplist.style.backgroundColor="white";
		document.body.appendChild(theDroplist);

		var t=document.createElement("DIV");
		t.style.visibility="hidden";
		t.style.position="absolute";
		t.style.left="-10000";
		t.style.top="-10000";
		t.style.width="0";
		t.style.height="0";
		var L=document.createElement("IFRAME");
		L.completeDiv=theDroplist;
		L.name="completionFrame";
		L.id="completionFrame";
		L.src=query_url;
		t.appendChild(L);
		document.body.appendChild(t);

	}
	ea=1;
	Ma=1;
	position_droplist();
	saveResultInCache("",new Array(),new Array());
	setDroplistCSS(theDroplist);
	if(frames&&(frames["completionFrame"]&&frames["completionFrame"].frameElement))theFrame=frames["completionFrame"].frameElement;
	else theFrame=document.getElementById("completionFrame");
	if(urlOrQuery=="url")
	{
		resizeTextField();
		position_droplist()
	}
	window.onresize=Mb;
	document.onkeydown=keyDownHandler;
	triggerCtrlDownArrow();
	if(noErrors)
	{
		setTimeout("mainLoop()",10);
		if(theField.attachEvent)
		{
			theField.attachEvent("onpropertychange",Zb)
		}

	}
	is_focused=true
	setTimeout("mainLoop2()",calculateTimerDelay(timerSpeed))
}

function onBlurHandler(h)
{
	is_focused=false;
	if(!h && window.event) h = window.event;
	if(!za)
	{
		droplistHide();
		if(ua==9)
		{
			ua=-1
		}

	}
	za=false
	return true
}

okuh=function(e)
{
	if(!Ea)
	{
		Ea=true
	}
	keyPressed=e.keyCode;
	currentFieldText=theField.value;
	readjustSelectedText()
}

setFocusOnTheField=function()
{
	theField.focus()
}

;
function hc(Da)
{
	for(var c=0,wa="",Ib="\n\r";
	c<Da.length;
	c++)if(Ib.indexOf(Da.charAt(c))==-1)wa+=Da.charAt(c);
	else wa+=" ";
	return wa
}

function getTextInHTMLTag(j,oc)
{
	var ia=j.getElementsByTagName(Kb);
	if(ia)
	{
		for(var c=0;
		c<ia.length;
		++c)
		{
			if(ia[c].className==oc)
			{
				var Y=ia[c].innerHTML;
				if(Y=="&nbsp;")return"";
				else
				{
					var A=hc(Y);
					return A
				}

			}

		}

	}
	else
	{
		return""
	}

}

function getAutoCompleteC(j)
{
	if(!j)return null;
	return getTextInHTMLTag(j,"cAutoComplete")
}

function getAutoCompleteD(j)
{
	if(!j)return null;
	return getTextInHTMLTag(j,"dAutoComplete")
}

function droplistHide()
{
	document.getElementById("completeDiv").style.visibility="hidden"
}

function droplistShow()
{
	document.getElementById("completeDiv").style.visibility="visible";
	position_droplist()
}

function saveResultInCache(searchString,completeString,displayString)
{
	cachedResult[searchString]=new Array(completeString,displayString)
}

sendRPCDone=function(fr,searchString,completeString,displayString,prefixString,ids)
{
	if(timerSpeed>0)timerSpeed--;
	var rc=(new Date()).getTime();
	if(!fr)fr=theFrame;
	saveResultInCache(searchString,completeString,displayString);
	var theDroplist=fr.completeDiv;
	theDroplist.completeStrings=completeString;
	theDroplist.displayStrings=displayString;
	theDroplist.prefixStrings=prefixString;
	theDroplist.ids=ids;
	setNewDataForDroplist(theDroplist, theDroplist.completeStrings, theDroplist.displayStrings);
	refreshFieldText(theDroplist,getAutoCompleteC);
	if(Na>0)theDroplist.height=16*Na+4;
	else droplistHide()
}

function readjustSelectedText()
{
//trace("readjustSelectedText")
	if(keyPressed==40||keyPressed==38)refocusTheField();
	var M=qa(theField);
	var cursorPosition=getCursorPosition(theField);
	var unselectedText=theField.value;
	if(W&&keyPressed!=0)
	{
		if(M>0&&cursorPosition!=-1)unselectedText=unselectedText.substring(0,cursorPosition);
		if(keyPressed==13||keyPressed==3)
		{
			var f=theField;
			if(f.createTextRange)
			{
				var u=f.createTextRange();
				u.moveStart("character",f.value.length);
				u.select()
			}
			else if(f.setSelectionRange)
			{
				f.setSelectionRange(f.value.length,f.value.length)
			}
		}
	}
	searchText=unselectedText;
	if(
		droplistKeyProcessor(keyPressed)
		&&
		keyPressed!=0
	) refreshFieldText( theDroplist, getAutoCompleteC)
//	if(theIndex) trace(theIndex)
}

function postData()
{
	return postData2(urlOrQuery)
}

function postData2(urlOrQuery)
{
	fa=true;
	if(!P)
	{
		ya("qu","",0,query_path,null,null)
	}
	droplistHide();
	if(urlOrQuery=="url")
	{
		var Q="";
		if(indexOfSelectedItem!=-1&&theIndex)Q=getAutoCompleteC(theIndex);
		if(Q=="")Q=theField.value;
		if(rightSideText=="")document.title=Q;
		else document.title=rightSideText;
		var dc="window.frames['"+xb+"'].location = \""+Q+'";';
		setTimeout(dc,10);
		return false
	}
	else if(urlOrQuery=="query")
	{
		if(submitButton) submitButton.submit();
		return true
	}
}

newwin=function()
{
	window.open(theField.value);
	droplistHide();
	return false
}

mainLoop=function(e)
{
	if(noErrors)
	{
		if(is_focused)
		{
			eb()
		}
		var db=theField.value;
		if(db!=currentFieldText)
		{
			keyPressed=0;
			readjustSelectedText()
		}
		currentFieldText=db;
		setTimeout("mainLoop()",10)
	}

}

;
function yb(Va)
{
	if(encodeURIComponent)return encodeURIComponent(Va);
	if(escape)return escape(Va)
}

function calculateTimerDelay(Ub)
{
	var I=100;
	for(var p=1;p<=(Ub-2)/2;p++)
	{
		I=I*2
	}
	I=I+50;
	return I
}

mainLoop2=function()
{
	if(!is_focused) return
	if(lastSearchText!=searchText)
	{
//trace("even")
		if(!fa)
		{
			var lb=yb(searchText);
			var ta=cachedResult[searchText];
			if(ta)
			{
				gb=-1;
				sendRPCDone(theFrame,searchText,ta[0],ta[1],theFrame.completeDiv.prefixStrings,theFrame.completeDiv.ids)
			}
			else
			{
				timerSpeed++;
				gb=(new Date()).getTime();
				if(P)
				{
					queryServer(lb)
				}
				else
				{
					ya("qu",lb,null,query_path,null,null);
					frames["completionFrame"].document.location.reload(true)
				}

			}
			theField.focus()
		}
		fa=false
	}
	lastSearchText=searchText;
	setTimeout("mainLoop2()",calculateTimerDelay(timerSpeed))
	return true
}

setTimeout("mainLoop2()",10);

var onSelectionByMouse=function()
{
	setFieldText(getAutoCompleteC(this));
	rightSideText=getAutoCompleteD(this);
	fa=true;
	postData()
}

var Ab=function()
{
	if(theIndex)setDroplistItemStyle(theIndex,"aAutoComplete");
	setDroplistItemStyle(this,"bAutoComplete")
}

;
var pc=function()
{
	setDroplistItemStyle(this,"aAutoComplete")
}

;
function setSelectedItem(D)
{
	searchText=H;
	setFieldText(H);
	rightSideText=H;
	if(!Ia||Z<=0)return;
	droplistShow();
	if(D>=Z)
	{
		D=Z-1
	}
	if(indexOfSelectedItem!=-1&&D!=indexOfSelectedItem)
	{
		setDroplistItemStyle(theIndex,"aAutoComplete");
		indexOfSelectedItem=-1
	}
	if(D<0)
	{
		indexOfSelectedItem=-1;
		theField.focus();
		return
	}
	indexOfSelectedItem=D;
	theIndex=Ia.item(D);
	setDroplistItemStyle(theIndex,"bAutoComplete");
	searchText=H;
	rightSideText=getAutoCompleteD(theIndex);
	setFieldText(getAutoCompleteC(theIndex))
}

function droplistKeyProcessor(keyCode)
{
	if(keyCode==40)
	{
		setSelectedItem(indexOfSelectedItem+1);
		return false
	}
	else if(keyCode==38)
	{
		setSelectedItem(indexOfSelectedItem-1);
		return false
	}
	else if(keyCode==13||keyCode==3)
	{
		return false
	}
	return true
}

function refreshFieldText(theDroplist,Pa)
{
//Habib: v2
//trace("set")

	var f=theField;
	var foundMatchInDroplist=false;
	indexOfSelectedItem=-1;
	var B=theDroplist.getElementsByTagName(Tb);
	var O=B.length;
	Z=O;
	Ia=B;
	Na=O;
	H=searchText;
	if(searchText==""||O==0)
	{
		droplistHide()
	}
	else
	{
		droplistShow()
	}
	var Jb="";
	if(searchText.length>0)
	{
		var c;
		var p;
		for(var c=0;c<O;c++)
		{
			for(p=0;p<theDroplist.prefixStrings.length;p++)
			{
				var cb=theDroplist.prefixStrings[p]+searchText;
				if(
					va || ( !aa && Pa(B.item(c)).toUpperCase().indexOf(cb.toUpperCase() ) == 0
						|| aa && ( c==0 && Pa(B.item(c)).toUpperCase()==cb.toUpperCase() )
				))
				{
					Jb=theDroplist.prefixStrings[p];
					foundMatchInDroplist=true;
					theIDField.value = theDroplist.ids[p]
					break
				}

			}
			if(foundMatchInDroplist)
			{
				break
			}

		}
	}
	if(foundMatchInDroplist)indexOfSelectedItem=c;
	for(var c=0;c<O;c++) setDroplistItemStyle(B.item(c),"aAutoComplete");
	if(foundMatchInDroplist)
	{
		theIndex=B.item(indexOfSelectedItem);
		rightSideText=getAutoCompleteD(theIndex)
	}
	else
	{
		rightSideText=searchText;
		indexOfSelectedItem=-1;
		theIndex=null
	}
	var mb=false;
	switch(keyPressed)
	{
		case 8:case 33:case 34:case 35:case 35:case 36:case 37:case 39:case 45:case 46:
			mb=true;
		break;
		default:
		break
	}
	if(!mb && theIndex)
	{
		var Oa=searchText;
		setDroplistItemStyle(theIndex,"bAutoComplete");
		var A;
		if(foundMatchInDroplist)A=Pa(theIndex).substr(theDroplist.prefixStrings[p].length);
		else A=Oa;
		if(A!=f.value)
		{
			if(f.value!=searchText)return;
			if(W)
			{
				if(f.createTextRange||f.setSelectionRange)setFieldText(A);
				if(f.createTextRange)
				{
					var u=f.createTextRange();
					u.moveStart("character",Oa.length);
					u.select()
				}
				else if(f.setSelectionRange)
				{
					f.setSelectionRange(Oa.length,f.value.length)
				}

			}

		}
	}
	else
	{
		indexOfSelectedItem=-1;
		rightSideText=searchText
	}
}

function zb(s)
{
	return kb(s,"offsetLeft")
}

function Yb(s)
{
	return kb(s,"offsetTop")
}

function kb(s,table_name)
{
	var wb=0;
	while(s)
	{
		wb+=s[table_name];
		s=s.offsetParent
	}
	return wb
}

function ya(z,Y,ab,tb,qb,cc)
{
	var Vb=z+"="+Y+(ab?";expires="+ab.toGMTString():"")+(tb?";path="+tb:"")+(qb?";domain="+qb:"")+(cc?";secure":"");
	document.cookie=Vb
}

function resizeTextField()
{
	var Ga=document.body.scrollWidth-220;
	Ga=0.73*Ga;
	theField.size=Math.floor(Ga/6.18)
}

function qa(o)
{
	var M=-1;
	if(o.createTextRange)
	{
		var ha=document.selection.createRange().duplicate();
		M=ha.text.length
	}
	else if(o.setSelectionRange)
	{
		M=o.selectionEnd-o.selectionStart
	}
	return M
}

function getCursorPosition(o)
{
	var w=0;
	if(o.createTextRange)
	{
		var ha=document.selection.createRange().duplicate();
		ha.moveEnd("textedit",1);
		w=o.value.length-ha.text.length
	}
	else if(o.setSelectionRange)
	{
		w=o.selectionStart
	}
	else
	{
		w=-1
	}
	return w
}

function nc(f)
{
	if(f.createTextRange)
	{
		var u=f.createTextRange();
		u.moveStart("character",f.value.length);
		u.select()
	}
	else if(f.setSelectionRange)
	{
		f.setSelectionRange(f.value.length,f.value.length)
	}

}

function setDroplistItemStyle(theItem,classname)
{
	ob();
	theItem.className=classname;
	if(Ua)
	{
		return
	}
	switch(classname.charAt(0))
	{
		case "m":
			theItem.style.fontSize="13px";
			theItem.style.fontFamily="arial,sans-serif";
			theItem.style.wordWrap="break-word";
		break;
		case "l":
			theItem.style.display="block";
			theItem.style.paddingLeft="3";
			theItem.style.paddingRight="3";
			theItem.style.height="16px";
			theItem.style.overflow="hidden";
		break;
		case "a":
			theItem.style.backgroundColor="white";
			theItem.style.color="black";
			if(theItem.displaySpan)
			{
				theItem.displaySpan.style.color="green"
			}
		break;
		case "b":
			theItem.style.backgroundColor="#3366cc";
			theItem.style.color="white";
			if(theItem.displaySpan)
			{
				theItem.displaySpan.style.color="white"
			}
		break;
		case "c":
			theItem.style.width=leftColWidth+"%";
			theItem.style.cssFloat="left";
		break;
		case "d":
			theItem.style.cssFloat="right";
			theItem.style.width=100-leftColWidth+"%";
			if(urlOrQuery=="query")
			{
				theItem.style.fontSize="10px";
				theItem.style.textAlign="right";
				theItem.style.color="green";
				theItem.style.paddingTop="3px"
			}
			else
			{
				theItem.style.color="#696969"
			}
		break
	}

}

function ob()
{
	leftColWidth=65;
	if(urlOrQuery=="query")
	{
		var Fb=110;
		var bb=Ta();
		var Db=(bb-Fb)/bb*100;
		leftColWidth=Db
	}
	else
	{
		leftColWidth=65
	}
	if(Ha)
	{
		leftColWidth=99.99
	}

}

function setDroplistCSS(j)
{
	ob();
	var ec="font-size: 13px;font-family: arial,sans-serif;word-wrap:break-word;";
	var gc="display: block;padding-left: 3;padding-right: 3;height: 16px;overflow: hidden;";
	var mc="background-color: white;";
	var Bb="background-color: #3366cc;color: white ! important;";
	var Eb="display: block;margin-left: 0%;width: "+leftColWidth+"%;float: left;";
	var Ra="display: block;margin-left: "+leftColWidth+"%;";
	if(urlOrQuery=="query")
	{
		Ra+="font-size: 10px;text-align: right;color: green;padding-top: 3px;"

	}
	else
	{
		Ra+="color: #696969;"

	}
	E(".mAutoComplete",ec);
	E(".lAutoComplete",gc);
	E(".aAutoComplete *",mc);
	E(".bAutoComplete *",Bb);
	E(".cAutoComplete",Eb);
	E(".dAutoComplete",Ra);
	setDroplistItemStyle(j,"mAutoComplete")
}

function setNewDataForDroplist(theDroplist,completeStrings,displayStrings)
{
	while(theDroplist.childNodes.length>0)theDroplist.removeChild(theDroplist.childNodes[0])
	for(var c=0;c<completeStrings.length;++c)
	{
		var v=document.createElement("DIV")

		setDroplistItemStyle(v,"aAutoComplete")
		v.onmousedown=onSelectionByMouse
		v.onmouseover=Ab
		v.onmouseout=pc

		var ra=document.createElement("SPAN")
		setDroplistItemStyle(ra,"lAutoComplete")

		var Ca=document.createElement("SPAN")
		Ca.innerHTML=completeStrings[c]

		var ga=document.createElement("SPAN")
		setDroplistItemStyle(ga,"dAutoComplete")

		setDroplistItemStyle(Ca,"cAutoComplete")

		v.displaySpan=ga

		if(!Ha)ga.innerHTML=displayStrings[c]
		
		ra.appendChild(Ca)
		ra.appendChild(ga)

		v.appendChild(ra)
		theDroplist.appendChild(v)
	}
}

function E(z,rb)
{
	if(Ua)
	{
		var J=document.styleSheets[0];
		if(J.addRule)
		{
			J.addRule(z,rb)
		}
		else if(J.insertRule)
		{
			J.insertRule(z+" { "+rb+" } ",J.cssRules.length)
		}

	}

}

function httpxmlCtrl()
{
	var C=null;
	try
	{
		C=new ActiveXObject("Msxml2.XMLHTTP")
	}
	catch(e)
	{
		try
		{
			C=new ActiveXObject("Microsoft.XMLHTTP")
		}
		catch(sc)
		{
			C=null
		}

	}
	if(!C&&typeof XMLHttpRequest!="undefined")
	{
		C=new XMLHttpRequest()
	}
	return C
}

function queryServer(ac)
{
	if(theCallerCtrl&&theCallerCtrl.readyState!=0)
	{
		theCallerCtrl.abort()
	}
	theCallerCtrl=httpxmlCtrl();
	if(theCallerCtrl)
	{
		theCallerCtrl.open("GET",query_url+"&q="+ac,true);
		theCallerCtrl.onreadystatechange=function()
		{
			if(theCallerCtrl.readyState==4&&theCallerCtrl.responseText)
			{
				if(theCallerCtrl.responseText.charAt(0)=="<")
				{
alert(theCallerCtrl.responseText)
					timerSpeed--
				}
				else
				{
					eval(theCallerCtrl.responseText)
				}

			}

		}

		;
		theCallerCtrl.send(null)
	}

}

function setFieldText(ib)
{
	theField.value=ib;
	currentFieldText=ib
}

function Zb(h)
{
	if(!h&&window.event)h=window.event;
	if(!Ea&&(is_focused&&h.propertyName=="value"))
	{
		if(fc())
		{
			eb();
			setTimeout("ba("+ma+", "+oa+");",30)
		}

	}

}

function fc()
{
	var ic=theField.value;
	var La=getCursorPosition(theField);
	var Ja=qa(theField);
	return La==ma&&(Ja==oa&&ic==hb)
}

function eb()
{
	hb=theField.value;
	ma=getCursorPosition(theField);
	oa=qa(theField)
}

ba=function(La,Ja)
{
	if(La==ma&&Ja==oa)
	{
		bc()
	}

}

;
function bc()
{
	refocusTheField();
	setSelectedItem(indexOfSelectedItem+1)
}
function trace(str)
{
	window.status = 'trace: ' + (counter++) + ':' + str
}



