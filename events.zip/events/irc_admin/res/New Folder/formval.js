//*** library ************************************************************
var glb_vfld      // retain vfld for timer thread
var proceed = 2
function trim(str)
{
	return str.replace(/^\s+|\s+$/g, '')
}
function setFocusDelayed()
{
	glb_vfld.focus()
}
function setfocus(vfld)
{
	// save vfld in global variable so value retained when routine exits
	glb_vfld = vfld
	setTimeout( 'setFocusDelayed()', 100 )
}
function validate_required(vfld,ifld,reqd)
{
	if(!document.getElementById) return true
	if(/^\s*$/.test(vfld.value))
	{
		if(reqd) return msg(ifld, "error", "Required", vfld)
		else return msg(ifld, "warn", "", null)
	}
	return proceed;
}
function msg(fld,msgtype,message,vfld)
{
	if(fld)
	{
		var dispmessage
		if(/^\s*$/.test(message))
			dispmessage = String.fromCharCode(160)
		else
			dispmessage = message
		var elem = document.getElementById(fld)
		if( msgtype == 'error' ) dispmessage = dispmessage
		elem.firstChild.nodeValue = dispmessage
		elem.className = 'msg_' + msgtype
	}
	if( msgtype == 'error')
	{
		setfocus(vfld)
		return false
	}
	if( msgtype == 'warn') return true
	return proceed
}
function validate_regexp(vfld,ifld,regexp,msgtype,message)
{
	var tfld = trim(vfld.value)
	if(!regexp.test(tfld)) return msg(ifld, msgtype, message, vfld)
	return proceed
}
// ** sub-form **
function deleteRow(button)
{
	var row=button.parentNode;
	while(row.nodeName!="TR")
	{
		row=row.parentNode;
	}
	try
	{
		row.parentNode.deleteRow(row.rowIndex);
	}
	catch (e)
	{
		row.parentNode.deleteRow(-1);
	}
}
function addRow(templatename,target,key)
{
	var template=document.getElementById(templatename);
	var newnode = template.cloneNode(true);
	newnode.id = "";
	tags=newnode.getElementsByTagName("input")
	for(i=0;i<tags.length;i++)
	{
		if(/^key\[/.test(tags[i].name))
		{
			tags[i].value = 'blank';
			break;
		}
	}
	var formstart=document.getElementById(target);
	formstart.parentNode.appendChild(newnode);
}
function nearestId( id, node, depth, height )
{
	for(var i=0;i<node.childNodes.length;i++)
	{
		if(! node.childNodes[i].attributes ) continue;
		for(var j=0;j<node.childNodes[i].attributes.length;j++)
		{
			if( node.childNodes[i].attributes[j].nodeName.toLowerCase() == 'id' && node.childNodes[i].attributes[j].nodeValue == id ) return node.childNodes[i];
		}
		if( height > 0 && (ret = nearestId( id, node.childNodes[i], 0, height-1 ) ) ) return ret;
	}
	if( depth > 0 && node.parentNode ) return nearestId( id, node.parentNode, depth-1, height );
	return false;
}
