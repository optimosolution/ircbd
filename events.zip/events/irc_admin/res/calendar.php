<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Calendar</title>
<link rel=stylesheet href="calendar.css" type="text/css" title="standard" />
<script type="text/javascript" src="form.js"></script>
<script type="text/javascript">
<!--
var month_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
var day_names = new Array("Sun","Mon","Tue","Wed","Thu","Fri","Sat");
//-->
</script>
</head>
<body onload="initCalendar();">
<div id="calendar_data"></div>
<div id="clock_data"></div>
</body>
</html>
