<table width="100%">
	<tr>
		<td style="background: #CEDFCE url('../res/img/tl_corner.gif') no-repeat left top; padding-left:1em">
        <img src="../res/img/pause.gif" width="8" height="13"></img></td>
		<td style="background: #CEDFCE; font-family: verdana,sans-serif; font-size: 8pt; font-weight: bold; padding-left:1em;">Archive</td>
		<td style="background: #CEDFCE url('../res/img/tr_corner.gif') no-repeat right top; padding-left: 2em" align='right'>
        <img src="../res/img/close2.gif" width="15" height="15"></img></td>
	</tr>
	<tr>
		<td colspan='3'>


<style type="text/css" media="screen">@import "../res/calendar.css";</style>
<div id="calendar_data"></div>


<script>
var month_names = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");
var day_names = new Array("Sun","Mon","Tue","Wed","Thu","Fri","Sat");
var day;
var month;
var year;
var hour;
var minute;
var second;
var clock_set = 0;

/**
 * Opens calendar window.
 *
 * @param   string      calendar.php parameters
 * @param   string      form name
 * @param   string      field name
 * @param   string      edit type - date/timestamp
 */
function openCalendar(params, form, field, type) {
    window.open("res/calendar.php?" + params, "calendar", "width='400',height='200',status=yes");
    dateField = eval("document." + form + "." + field);
    dateType = type;
}

/**
 * Formats number to two digits.
 *
 * @param   int number to format.
 */
function formatNum2(i, valtype) {
    f = (i < 10 ? '0' : '') + i;
    if (valtype && valtype != '') {
        switch(valtype) {
            case 'month':
                f = (f > 12 ? 12 : f);
                break;

            case 'day':
                f = (f > 31 ? 31 : f);
                break;

            case 'hour':
                f = (f > 24 ? 24 : f);
                break;

            default:
            case 'second':
            case 'minute':
                f = (f > 59 ? 59 : f);
                break;
        }
    }

    return f;
}

/**
 * Formats number to four digits.
 *
 * @param   int number to format.
 */
function formatNum4(i) {
    return (i < 1000 ? i < 100 ? i < 10 ? '000' : '00' : '0' : '') + i;
}

/**
 * Initializes calendar window.
 */
function initCalendar() {
    if (!year && !month && !day) {
        /* Called for first time */
		dt      = new Date();
		year    = dt.getFullYear();
		month   = dt.getMonth();
		day     = dt.getDate();
    } else {
        /* Moving in calendar */
        if (month > 11) {
            month = 0;
            year++;
        }
        if (month < 0) {
            month = 11;
            year--;
        }
    }

    if (document.getElementById) {
        cnt = document.getElementById("calendar_data");
    } else if (document.all) {
        cnt = document.all["calendar_data"];
    }

    cnt.innerHTML = "";

    str = ""

    //heading table
    str += '<table class="calendar"><tr><th width="50%">';
    str += '<a href="#" onclick="month--; initCalendar();">&laquo;</a> ';
    str += month_names[month];
    str += ' <a href="#" onclick="month++; initCalendar();">&raquo;</a>';
    str += '</th><th width="50%">';
    str += '<a href="#" onclick="year--; initCalendar();">&laquo;</a> ';
    str += year;
    str += ' <a href="#" onclick="year++; initCalendar();">&raquo;</a>';
    str += '</th></tr></table>';

    str += '<table class="calendar"><tr>';
    for (i = 0; i < 7; i++) {
        str += "<th>" + day_names[i] + "</th>";
    }
    str += "</tr>";

    var firstDay = new Date(year, month, 1).getDay();
    var lastDay = new Date(year, month + 1, 0).getDate();

    str += "<tr>";

    dayInWeek = 0;
    for (i = 0; i < firstDay; i++) {
        str += "<td>&nbsp;</td>";
        dayInWeek++;
    }
    for (i = 1; i <= lastDay; i++) {
        if (dayInWeek == 7) {
            str += "</tr><tr>";
            dayInWeek = 0;
        }

        dispmonth = 1 + month;

        actVal = formatNum4(year) + "-" + formatNum2(dispmonth, 'month') + "-" + formatNum2(i, 'day');

        if (
        	i == dt.getDate() &&
			year    == dt.getFullYear() &&
			month   == dt.getMonth()
        ) {
            style = ' class="selected"';
        } else {
            style = '';
        }
        str += "<td" + style + "><a href='../accounting/balance.php" + "'>" + i + "</a></td>"
        //str += "<td" + style + "><a href='#' onclick='returnDate(\"" + actVal + "\");'>" + i + "</a></td>"
        dayInWeek++;
    }
    for (i = dayInWeek; i < 7; i++) {
        str += "<td>&nbsp;</td>"
    }
    str += '</tr><tr><td colspan="7"><a href="#" style="text-decoration: none" onclick="month=year=day=0; initCalendar();">Today is ' + month_names[dt.getMonth()] + ' ' + dt.getDate() + ', ' + dt.getFullYear() + '</a></td>'

    str += "</tr></table>";

    cnt.innerHTML = str;
}

/**
 * Returns date from calendar.
 *
 * @param   string     date text
 */
function returnDate(d) {
    txt = d
    alert(d)
}
initCalendar()
            </script>
		</td>
	</tr>
</table>
