<?php
	include('include.php');
	//include('salesorder.inc.php');
	//include('invoice_pdf.inc.php');

	checkPermission(PERMISSIONID_SELL);

	$rowcount = getParam('rowcount');
	if (getParam("action") == "Update")
	{
            $i=0;
            while($rowcount > 0)
             {
                $checked[$i] = getParam("rawchecked$i",0);
                if (($checked[$i]) > 0 )
                {
                   $updateSQL = "update menulist set active = 1
                                  where sl=$checked[$i]";
                   sql($updateSQL);
                   //echo "AA $checked[$i]<br>";
                }
                $rowcount--;
                $i++;
            }
        }
        $selectSQL = "SELECT sl,level, menutext FROM menulist where level=1";
        $selectSQL2 = "SELECT sl,level,menutext FROM menulist where level=1 and parent= 7";
        $selectSQL3 = "SELECT sl,level,menutext FROM menulist where level=1 and parent= 23";
        $selectSQL4 = "SELECT sl,level,menutext FROM menulist where level=1 and parent= 42";
        $selectSQL5 = "SELECT sl,level,menutext FROM menulist where level=1 and parent= 55";
?>

<head>
<title>ICS System Solutions - <?php etr("Menu Configuration") ?></title>
<?php
styleSheet();
include_common();
?>
</head>

<body onLoad="onLoad()">
<div id=main>
<?php menubar(); ?>
<?php statusBody(); ?>
<?php startBody(); ?>
<h3>Menu Configuration</h3>
<p class="hsub">Select Bellow For Menu List</p><br/><br/>
<form method="post" action="menu_config.php">
<table width="100%" border="1" cellspacing="1" cellpadding="1" align="center">


<table width='50%' border="0" align="left">
<?php
 
$selectSQL.=" and parent= 1";
$rs = query($selectSQL);
$i=0;
echo "<tr bgcolor=\"#CCCCCC\"><td colspan=\"4\">Sales Menu</td></tr>";
while ($row = fetch_object($rs))
{
    //if($row->level == 1 ){
    echo "<tr>";  
    echo "<td align=right>"; ?>
    <?php //checkbox('rawchecked$i','$row->sl');
    echo "<input type='checkbox' name='rawchecked$i' value='$row->sl'> ";
    echo "<td align=left>$row->menutext</td>";
    //echo "</tr>";
$i++;
$row = fetch_object($rs);
if($row->level == 1 ){
    echo "<td align=right>"; ?>
    <?php //checkbox('$row->rawproductid$i')
    echo "<input type='checkbox' name='rawchecked$i' value='$row->sl'> ";
    echo "<td align=left>$row->menutext</td>";
    echo "</tr>";
$i++;
    }
}
?>



<?php

//$selectSQL2 = "SELECT sl,level,menutext FROM menulist where level=1 and parent= 7";

$rs = query($selectSQL2);
echo "<tr bgcolor=\"#CCCCCC\"><td colspan=\"4\">Stock/Inventory Menu</td></tr>";
while ($row = fetch_object($rs))
{
    echo "<tr>";
    echo "<td align=right>"; ?>
    <?php //checkbox('rawchecked$j','$row->sl');
    echo "<input type='checkbox' name='rawchecked$i' value='$row->sl'> ";
    echo "<td align=left>$row->menutext</td>";
$i++;
$row = fetch_object($rs);
if($row->level == 1 ){
    echo "<td align=right>"; ?>
    <?php //checkbox('$row->rawproductid$j')
    echo "<input type='checkbox' name='rawchecked$i' value='$row->sl'> ";
    echo "<td align=left>$row->menutext</td>";
    echo "</tr>";
$i++;
    }
}
?>

<?php

//$selectSQL3 = "SELECT sl,level,menutext FROM menulist where level=1 and parent= 23";

$rs = query($selectSQL3);
echo "<tr bgcolor=\"#CCCCCC\"><td colspan=\"4\">Payroll Menu</td></tr>";
while ($row = fetch_object($rs))
{
    echo "<tr>";
    echo "<td align=right>"; ?>
    <?php //checkbox('rawchecked$i','$row->sl');
    echo "<input type='checkbox' name='rawchecked$i' value='$row->sl'> ";
    echo "<td align=left>$row->menutext</td>";
$i++;
$row = fetch_object($rs);
if($row->level == 1 ){
    echo "<td align=right>"; ?>
    <?php //checkbox('$row->rawproductid$i')
    echo "<input type='checkbox' name='rawchecked$i' value='$row->sl'> ";
    echo "<td align=left>$row->menutext</td>";
    echo "</tr>";
$i++;
    }
}
?>
<?php

//$selectSQL4 = "SELECT sl,level,menutext FROM menulist where level=1 and parent= 42";

$rs = query($selectSQL4);
echo "<tr bgcolor=\"#CCCCCC\"><td colspan=\"4\">Generale Ledger Menu</td></tr>";
while ($row = fetch_object($rs))
{
    echo "<tr>";
    echo "<td align=right>"; ?>
    <?php //checkbox('rawchecked$i','$row->sl');
    echo "<input type='checkbox' name='rawchecked$i' value='$row->sl'> ";
    echo "<td align=left>$row->menutext</td>";
$i++;
$row = fetch_object($rs);
if($row->level == 1 ){
    echo "<td align=right>"; ?>
    <?php //checkbox('$row->rawproductid$i')
    echo "<input type='checkbox' name='rawchecked$i' value='$row->sl'> ";
    echo "<td align=left>$row->menutext</td>";
    echo "</tr>";
$i++;
    }
}
?>
<?php

//$selectSQL5 = "SELECT sl,level,menutext FROM menulist where level=1 and parent= 55";

$rs = query($selectSQL5);
echo "<tr bgcolor=\"#CCCCCC\"><td colspan=\"4\">Common Menu</td></tr>";
while ($row = fetch_object($rs))
{
    echo "<tr>";
    echo "<td align=right>"; ?>
    <?php //checkbox('rawchecked$i','$row->sl');
    echo "<input type='checkbox' name='rawchecked$i' value='$row->sl'> ";
    echo "<td align=left>$row->menutext</td>";
$i++;
$row = fetch_object($rs);
if($row->level == 1 ){
    echo "<td align=right>"; ?>
    <?php //checkbox('$row->rawproductid$i')
    echo "<input type='checkbox' name='rawchecked$i' value='$row->sl'> ";
    echo "<td align=left>$row->menutext</td>";
    echo "</tr>";
    $i++;
    }
}
?>
<input type='hidden'  name='rowcount' value='<?php echo $i ; ?>'>
</table>
    <table width="100%">
        <tr>
          <td> <?php //echo "$i AA";?>
            <div align="center">
              <input type="submit" name="action" value="Update Changes" />
            <input type="submit" name="action" value="Cancel" />
            </div>
          </td>
        </tr>
    </table>


</table>
</form>
    <?php endBody(); ?>
</body>
