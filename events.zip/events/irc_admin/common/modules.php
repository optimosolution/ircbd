<?php
include("include.php");
include("onebookmenu.php");

?> 
   <?php error_reporting(0); ?>
<head>
<title>ICS System Solutions - <?php etr("Sales") ?></title>
<?php styleSheet() ?>
</head>
<link rel="stylesheet" type="text/css" media="all" href="../css/main.css" />
<body>

<div id=main>


<?php menubar(); ?>


 

<table border="0" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%" >
  <tr>
      <td > <br>  &nbsp;&nbsp;<img src="../images/cp.gif"/></td>
  </tr>
  <tr>
    <td  align="left" valign="top" >

    <ul id="modules" >
    <li>
        <a href='../sales/index.php'>
        <img src="../images/inv.gif"/>
        <p><?php etr("Sales") ?></p>
        </a>
    </li>
    <li>
        <a href='../erp/index.php'>
        <img src="../images/sales.gif"/>
        <p><?php etr("Stock/Inventory") ?></p>
        </a>
    </li>
    <li>
        <a href='../order_management/index.php'>
        <img src="../images/sales.gif"/>
        <p><?php etr("Sales Order Management") ?></p>
        </a>
    </li>
    <li>
        <a href='../accounting/index.php' >
        <img src="../images/ledger.gif"/>
        <p><?php etr("General Ledger") ?></p>
        </a>
    </li>
    <li>
        <a href='security.php' >
        <img src="../images/settings.gif"/>
        <p><?php etr("Settings") ?></p>
        </a>
    </li>
</ul>

  </tr>

</table>





</div>
</body>
