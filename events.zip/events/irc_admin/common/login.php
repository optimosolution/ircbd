<?php
include_once('include.php');

//include_once('../sql/upgrade.php');
//upgrade();
	
$companyname = findValue("select companyname from companyinfo");

$action = 'index.php';
if (isset($_SESSION['ORG_SCRIPT_NAME']))
	$action = $_SESSION['ORG_SCRIPT_NAME'];

$mess = null;
if (isset($_REQUEST['login_mess']))
	$mess = $_REQUEST['login_mess'];
	
$dbs = array();
$i = 1;
while (defined("DBNAME_$i")) {
	$dbs[] = array(constant("DBNAME_$i"));
	$i++;
}

?>
<head>
<title>ICS ERP System- <?php etr("Login") ?></title>
<link rel="stylesheet" type="text/css" media="all" href="../css/mainlogin.css" />
<?php styleSheet() ?>
<script>
function onLoad()
{
	document.postform.username.focus();
}
</script>
</head>

<body onLoad="onLoad()">

<br/><br/><br/><br/><br/><br/><br/><br/><br/>
 <div align="center">
             
<form name=postform method="POST" action='<?php echo $action ?>'>
<table width="250px">
    <tr>
        <td valign="top"><br/>
           
        </td>
        <td> <img src="../images/logo.gif"/><br/><br/>
            <table background="../images/tb_middle.gif" cellpadding="0" cellspacing="0">
                <tr>
                    <td colspan="2" ><img src="../images/staff.gif"/></td>
                </tr>
                <tr >
                    <td class="space"><label>&nbsp;&nbsp;&nbsp;<?php etr("Username") ?>:</label></td>
                    <td class="space"><input name=username type=text value=""></td>
                </tr>
                <tr>
                    <td class="space"><label>&nbsp;&nbsp;&nbsp;<?php etr("Password") ?>:</label></td>
                    <td class="space"><input name=pwd type=password value=""></td>
                </tr>
                <tr>
                    <td colspan="2" align="right"><br><input type=submit name=login value='<?php etr("Login") ?>'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </td>
                </tr>
                <tr>
                    <td colspan="2" ><img src="../images/tb_bottom.gif"/> </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2" align="right">
            Powered by <a href='http://www.ics-ss.com' target=_blank>ICS System Solutions</a>
        </td>
    </tr>
</table>
</form>
 </div>

