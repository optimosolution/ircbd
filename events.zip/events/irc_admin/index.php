<html>
<head>
<meta http-equiv="refresh" content="0;url=irc_admin/add_resource.php">
</head>

<body>

</body>
</html>
