<?php
define('DBHOST', 'mysql10.websitesource.net');
define('DBUSER', 'iitmweb_ircbd');
define('DBPWD', 'ir5678');
//define('DBNAME', 'onebook_pro');
define('DBNAME', 'iitmweb_ircbd');
?>