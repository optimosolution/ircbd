<?php include('conn/db_connect.php'); ?>
<?php include('quiries.php');?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <!-- base href="/" --><!--[if IE]></base><![endif]-->
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta name="description" content="Search panel designed by Apsis Solutions." />
        <title>Custom Search</title>

        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />

        <script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
        <script type="text/javascript" src="js/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/jquery.flexisel.js"></script>
		
		<style>
		.author{list-style:none;}
		
		</style>
    </head>

    <body>
       <div class="wrapper">
            <div class="header">
                <div class="logo">
                    <a href="<?php echo $home_url; ?>"><img src="images/search.png" /></a>
                </div>
                <div class="title">
                    <img src="images/irc.png" />
                </div>
            </div>
            <div class="clear"></div>
            <div class="container">
                 <div class="top_menu">
                    <ul>
                    <?php	 	
                        while($res_for_rows =  mysql_fetch_row($res_for1)){
                    ?>
                    <li><a href="<?php echo $home_url; ?>?id=<?php echo $res_for_rows[0]; ?>"><?php echo $res_for_rows[1]; ?> (<?php echo $res_for_rows[2]; ?>)</a></li>
                    <?php
                    }
                    ?> 
                    </ul>
                    <div class="clear"></div>

                    <ul class="author">
                    <?php while($list = mysql_fetch_assoc($author_lists)) { 
                        $author_id=$list['author_id'];
                        $au = mysql_query("SELECT COUNT(resource_id) FROM resources WHERE author_id=$author_id");
                        $count = mysql_fetch_array($au);
                        ?>
                            <li style="border: 1px outset #FFFFFF; list-style: none outside none; margin-bottom: 4px;"><a href="http://resource.ircbd.org/author_info.php?a_id=<?php echo $list['author_id'];?>"><?php echo $list['author_name'].'  ( '.$count[0].' )'; ?></a>
                            </li>
                    <?php }?>
                    </ul>
				 </div>
			</div>
		</div>	
    </body>
</html>
