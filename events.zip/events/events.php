<?php include('conn/db_connect.php'); ?>

<?php

/***************************************** RESOURCE CATEGORY ***************************************************/

   mysql_query("set names 'utf8'");
   $res_cat="SELECT
			resource_category.resource_category as category,
			Count(resource_category.resource_category_id) as total,
			resource_category_id
			FROM
			resources
			RIGHT OUTER JOIN resource_category ON resources.resource_category = resource_category.resource_category_id
			GROUP BY resource_category.resource_category
			ORDER BY resource_category._sort";
   $res_cat_rows = mysql_query($res_cat);
   
   /////////////////////////////////////
   
   	mysql_query("set names 'utf8'");
	$res_qry="SELECT
				resource_category.resource_category as category,
				Count(resource_category.resource_category_id) as total
				FROM
				resources
				INNER JOIN resource_category ON resources.resource_category = resource_category.resource_category_id
				GROUP BY resource_category.resource_category";
	$query1 = mysql_query($res_qry);


/********************************************* RESOURCE FOR ***********************************************/

mysql_query("set names 'utf8'");
$res_for="SELECT 
			resource_for.resource_for_id, 	
			resource_for.resource_for,
			count(resources.resource_for)
			FROM
			resource_for
			LEFT OUTER JOIN resources ON resource_for.resource_for_id = resources.resource_for
			GROUP BY resource_for.resource_for
			ORDER BY resource_for._sort";
$res_for1 = mysql_query($res_for);

/********************************************* AUTHOR INFO ***********************************************/

mysql_query("set names 'utf8'");
$res_author="SELECT
			count(resources.author_id),
			author_info.author_id,
			author_info.author_name
			FROM
			author_info
			LEFT OUTER JOIN resources ON author_info.author_id = resources.author_id
			GROUP BY author_info.author_id
			ORDER BY author_info._sort
			LIMIT 30";
$res_author1 = mysql_query($res_author);	

//////////////////////////////////////////////

mysql_query("set names 'utf8'");
$author_lists = mysql_query("SELECT * FROM	author_info ORDER BY author_name");
//////////////////////////////////////////////

/******************************************** AUTHOR NUMBER ************************************************/

$num_author = mysql_query("SELECT
			count(resources.author_id),
			author_info.author_id,
			author_info.author_name
			FROM
			author_info
			LEFT OUTER JOIN resources ON author_info.author_id = resources.author_id
			GROUP BY author_info.author_id
			ORDER BY author_info._sort");	
$num_authors = mysql_num_rows($num_author);

/*********************************************** RESOURCES NUMBER *********************************************/

$total_resource="SELECT resource_id FROM resources";
$total = mysql_query($total_resource);
$total_rows = mysql_num_rows($total);

/************************************************ EVENT INFO *******************************************************/
////////////////////////////////
//$date=date('Y-m-d');
//mysql_query("UPDATE irc_event SET active=0 WHERE event_date < ".$date."");
mysql_query("set names 'utf8'");
$event_list = mysql_query("SELECT * FROM irc_event WHERE active=1 ORDER BY event_date");

?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<!-- base href="/" --><!--[if IE]></base><![endif]-->
	<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
	<meta name="description" content="Search panel designed by Apsis Solutions." />
	<title>Custom Search</title>

	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />
        <link href="css/glDatePicker.default.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script src="js/glDatePicker.min.js"></script>

	<style>
	.author{list-style:none;}
	.submit{
		font-size: 18px;
		font-weight: bold;
		border-radius: 4px;
		padding: 3px 20px;
		border: 1px solid #ccc;
	}
	</style>
    <script type="text/javascript">
        $(window).load(function()
        { 
			$('input#mydate').glDatePicker(
			{
				onClick: function(target, cell, date, data) {
					target.val(date.getFullYear() + '-' +
								date.getMonth() + '-' +
								date.getDate());

					if(data != null) {
						alert(data.message + '\n' + date);
					}
				}
			});
        });
    </script>
</head>

    <body>
       <div class="wrapper">
            <div class="header">
                <div class="logo">
                    <a href="<?php echo $home_url; ?>"><img src="images/search.png" /></a>
                </div>
                <div class="title">
                    <img src="images/irc.png" />
                </div>
            </div>
            <div class="clear"></div>
            <div class="container">
                 <div class="top_menu">
                    <ul>
                    <?php	 	
                        while($res_for_rows =  mysql_fetch_row($res_for1)){
                    ?>
                    <li><a href="<?php echo $home_url; ?>?id=<?php echo $res_for_rows[0]; ?>"><?php echo $res_for_rows[1]; ?> (<?php echo $res_for_rows[2]; ?>)</a></li>
                    <?php
                    }
                    ?> 
                    </ul>
                    <div class="clear"></div>
                </div>
<!------------------------------------------------------------------>
<?php while($event = mysql_fetch_assoc($event_list)){ ?>
<fieldset style="text-align:left; margin:5px; margin-bottom:20px; padding:15px; border: 1px solid #f8f8f8; background:#f8f8f8; ">
<legend style="left:20px; background: #f8f8f8; padding: 10px;">
&nbsp;<b><i><?php echo $event['event_title']; ?></i>&nbsp;&nbsp;(<?php echo $event['duration']; ?></b>&nbsp; দিন )</b>&nbsp;&nbsp;</legend>
<p style="border-bottom:1px solid #555; text-align:right; padding-bottom: 5px;"><b><?php echo $event['event_place']; ?></b></p>
<table align="left" width="100%">
	<tr>
		<!--td rowspan="4" style="width:10%;"><img src="<?php// echo $event['images']; ?>" ></td-->
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>তারিখ : </b></td>
		<td style="border-bottom: 1px solid #fff;"><?php echo $event['event_date']; ?></td>
	</tr>
	<tr>
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>সময় : </b></td>
		<td style="border-bottom: 1px solid #fff;"><?php echo $event['event_time']; ?></td>
	</tr>
	<tr>
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>বিষয় :</b></td>
		<td style="border-bottom: 1px solid #fff;"><i><?php echo $event['subject']; ?></i></td>
	</tr>
	<tr>
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>বক্তা :</b></td>
		<td style="border-bottom: 1px solid #fff;"><i><?php echo $event['speaker']; ?></i></td>
	</tr>

	<tr>
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>পরিচিতি :</b></td>
		<td style="border-bottom: 1px solid #fff;"><i><?php echo $event['introduction']; ?></i></td>
	</tr>
	<tr>
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>আয়োজক :</b></td>
		<td style="border-bottom: 1px solid #fff;"><i><?php echo $event['organized_by']; ?></i></td>
	</tr>
</table>

</fieldset>
<?php } ?>

<div style="padding:10px;">
<p style="font-size: 20px;"><b>অনুষ্ঠানসূচী লিপিবদ্ধ করুন</b></p>
<form action="http://resource.ircbd.org/event_add.php" method="post">
	<table align="left" width="100%">
		</tr>
		<tr>
			<td style="width:10%;"><label for="eventtitle">শিরোনাম</label></td><td><input id="eventtitle" style="width:100%" type="text" name="eventtitle" /></td>
		</tr>		
		<tr>
			<td style="width:10%;"><label for="subject">বিষয়</label></td><td><input id="subject" style="width:100%" type="text" name="subject" /></td>
		</tr>
		<tr>
			<td style="width:10%;"><label for="place">স্থান</label></td><td><input id="place" style="width:100%" type="text" name="place" /></td>
		</tr>
		<tr>
			<td style="width:10%;"><label for="duration">ব্যপ্তিকাল</label></td><td><input id="duration" style="width:100%" type="text" name="duration" /></td>
		</tr>
		<tr>
			<td style="width:10%;"><label for="mydate">তারিখ</label></td><td><input id="mydate" class="mydate" gldp-id="mydate" style="width:100%" type="text" name="eventdate" />
				<div gldp-el="mydate" style="width:400px; height:300px; position:absolute; top:70px; left:100px;"></div>
			</td>
		</tr>
		<tr>
			<td style="width:10%;"><label for="eventtime">সময়</label></td><td><input id="eventtime" style="width:100%" type="text" name="eventtime" /></td>
		</tr>
		<tr>
			<td style="width:10%;"><label for="speaker">বক্তা</label></td><td><input id="speaker" style="width:100%" type="text" name="speaker" /></td>
		</tr>
		<tr>
			<td style="width:10%;"><label for="introduction">পরিচিতি</label></td><td><textarea id="introduction" style="width:100%" rows="3" name="introduction" ></textarea></td>
		</tr>
		<tr>
			<td style="width:10%;"><label for="organized">আয়োজক</label></td><td><input id="organized" style="width:100%" type="text" name="organized" /></td>
		</tr>	
		<tr><td></td>&nbsp;</td></tr>
		<tr><td></td><td>লিপিকারক :</td></tr>
			<td style="width:10%;"><label for="nam">নাম</label></td><td><input id="nam" style="width:100%" type="text" name="nam" /></td>
		</tr>
		<tr>
			<td style="width:10%;"><label for="phone">ফোন</label></td><td><input id="phone" style="width:100%" type="text" name="phone" /></td>
		</tr>
		<tr>
			<td style="width:10%;"><label for="mail">ই-মেইল</label></td><td><input id="mail" style="width:100%" type="text" name="mail" /></td>
		</tr>
		<tr>
			<td style="width:10%;"><label for="address">ঠিকানা</label></td><td><textarea id="address" style="width:100%" rows="3" name="address" ></textarea></td>
		</tr>		
		<tr><td></td>&nbsp;</td></tr>
		<tr>
			<td></td><td><input class="submit" type="submit" name="" value="Save"/></td>
		</tr>
	</table>
        
</form>
</div>
<div class="clear"></div>

<!------------------------------------------------------------------>
				 
			</div>
		</div>	
    </body>
</html>
<script>

</script>