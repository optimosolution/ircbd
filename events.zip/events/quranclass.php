<?php 
include('conn/db_connect.php'); 
?>
<?php
/************************************************ quran INFO *******************************************************/
if(!empty($_POST)){
    $additional_where = '';
    $additional_where .= isset($_POST['scity'])?" AND irc_quran.city_id = '".$_POST['scity']."'":'';
    $additional_where .= isset($_POST['sarea']) && !empty($_POST['sarea'])?" AND irc_quran.area_id = '".$_POST['sarea']."'":'';
    //$area = $_POST['sarea'];
    mysql_query("set names 'utf8'");
    $quran_list = mysql_query("SELECT * FROM irc_quran 
                            LEFT JOIN irc_city ON irc_city.city_id=irc_quran.city_id 
                            LEFT JOIN irc_area ON irc_area.area_id=irc_quran.area_id 
                            WHERE irc_quran.active=1 $additional_where");
}
else{
mysql_query("set names 'utf8'");
$quran_list = mysql_query("SELECT * FROM irc_quran 
                        LEFT JOIN irc_city ON irc_city.city_id=irc_quran.city_id 
                        LEFT JOIN irc_area ON irc_area.area_id=irc_quran.area_id 
                        WHERE irc_quran.active=1");
}
/********************************************* RESOURCE FOR ***********************************************/

mysql_query("set names 'utf8'");
$res_for="SELECT 
			resource_for.resource_for_id, 	
			resource_for.resource_for,
			count(resources.resource_for)
			FROM
			resource_for
			LEFT OUTER JOIN resources ON resource_for.resource_for_id = resources.resource_for
			GROUP BY resource_for.resource_for
			ORDER BY resource_for._sort";
$res_for1 = mysql_query($res_for);

/***************************************city*****************************************/
mysql_query("set names 'utf8'");
$city_list = mysql_query("SELECT * FROM irc_city");
$city_list1 = mysql_query("SELECT * FROM irc_city");
$area_list = mysql_query("SELECT * FROM irc_area");

/********************************************************************************/


?> 
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<!-- base href="/" --><!--[if IE]></base><![endif]-->
	<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
	<meta name="description" content="Search panel designed by Apsis Solutions." />
	<title>Custom Search</title>

	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.css" />

	<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="js/jquery-ui.min.js"></script>
	
	<style>
	.author{list-style:none;}
	.submit{
		font-size: 18px;
		font-weight: bold;
		border-radius: 4px;
		padding: 3px 20px;
		border: 1px solid #ccc;
	}
	</style>

</head>

    <body>
       <div class="wrapper">
            <div class="header">
                <div class="logo">
                    <a href="<?php echo $home_url; ?>"><img src="images/search.png" /></a>
                </div>
                <div class="title">
                    <img src="images/irc.png" />
                </div>
            </div>
            <div class="clear"></div>
            <div class="container">
                 <div class="top_menu">
                    <ul>
                    <?php	 	
                        while($res_for_rows =  mysql_fetch_row($res_for1)){
                    ?>
                    <li><a href="<?php echo $home_url; ?>?id=<?php echo $res_for_rows[0]; ?>"><?php echo $res_for_rows[1]; ?> (<?php echo $res_for_rows[2]; ?>)</a></li>
                    <?php
                    }
                    ?> 
                    </ul>
                    <div class="clear"></div>
                </div>
<!------------------------------------------------------------------>
<div style="text-align:center; margin-bottom: 20px;">
<form action="" method="post">
    <select class="inp_cls" id="city" name="scity" >
        <option value="">City</option>
        <?php while($city=mysql_fetch_assoc($city_list)){?>
        <option value="<?php echo $city['city_id']; ?>" ><?php echo $city['city_name']; ?></option>
        <?php } ?>
    </select>
    <select class="inp_cls" id="area" name="sarea" ></select>
    <input class="submit" type="submit" name="" value="Search"/>
</form>
</div>
<?php while($quran = mysql_fetch_assoc($quran_list)){ ?>
<fieldset style="text-align:left; margin:5px; margin-bottom:20px; padding:15px; border: 1px solid #f8f8f8; background:#f8f8f8; ">
<legend style="left:20px; background: #f8f8f8; padding: 10px;">
&nbsp;<b><i><?php echo $quran['quran_subject']; ?>&nbsp;</i></legend>
<p style="border-bottom:1px solid #555; padding-bottom: 20px; width:100%"><span style="text-align:left; float:left;">স্থান :&nbsp;<b><?php echo $quran['place']; ?></b></span><span style="text-align:right; float:right;">শিক্ষক :&nbsp;<b><?php echo $quran['speaker']; ?></b></span></p>
<table align="left" width="100%">
	<tr>
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>তারিখ : </b></td>
		<td style="width:30%; border-bottom: 1px solid #fff;"><?php echo $quran['quran_date']; ?></td>
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>সময় : </b></td>
		<td style="width:30%; border-bottom: 1px solid #fff;"><?php echo $quran['quran_time']; ?></td>
	</tr>
	<tr>
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>তারিখ : </b></td>
		<td style="width:30%; border-bottom: 1px solid #fff;"><?php echo $quran['city_name']; ?></td>
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>সময় : </b></td>
		<td style="width:30%; border-bottom: 1px solid #fff;"><?php echo $quran['area_name']; ?></td>
	</tr>
	<tr>
		<td style="width:10%; border-bottom: 1px solid #fff;"><b>মন্তব্য :</b></td>
		<td style="border-bottom: 1px solid #fff;" colspan=3><i><?php echo $quran['introduction']; ?></i></td>
	</tr>
</table>
<br/>
</fieldset>
<?php } ?>

<div style="padding:10px;">
<p style="font-size: 20px;"><b>কোরআন শিক্ষা সময়সুচী নিবন্ধন করুন</b></p>
<form action="quran_add.php" method="post">
    <table align="left" width="100%">
        <tr>
                <td style="width:10%;"><label for="subject">বিষয়</label></td><td><input id="subject" style="width:100%" type="text" name="subject" /></td>
        </tr>

        <tr>
                <td style="width:10%;"><label for="city1">শহর/জেলা</label></td>
                <td>
                <select class="inp_cls" id="city1" name="city1" >
                    <option value="">City</option>
                    <?php while($city1=mysql_fetch_assoc($city_list1)){?>
                    <option value="<?php echo $city1['city_id']; ?>" ><?php echo $city1['city_name']; ?></option>
                    <?php } ?>
                </select>
                </td>
        </tr>
        <tr>
                <td style="width:10%;"><label for="area">এলাকা</label></td>
                <td>
                <select class="inp_cls" id="area1" name="area1" ></select>
                </td>
        </tr>
        <tr>
                <td style="width:10%;"><label for="place">স্থান</label></td><td><input id="place" style="width:100%" type="text" name="place" /></td>
        </tr>
        <tr>
                <td style="width:10%;"><label for="eventdate">তারিখ/বার</label></td><td><input id="eventdate" style="width:100%" type="text" name="qurandate" /></td>
        </tr>
        <tr>
                <td style="width:10%;"><label for="eventtime">সময়</label></td><td><input id="eventtime" style="width:100%" type="text" name="qurantime" /></td>
        </tr>
        <tr>
                <td style="width:10%;"><label for="speaker">শিক্ষক</label></td><td><input id="speaker" style="width:100%" type="text" name="speaker" /></td>
        </tr>
        <tr>
                <td style="width:10%;"><label for="introduction">মন্তব্য</label></td><td><textarea id="introduction" style="width:100%" rows="3" name="introduction" ></textarea></td>
        </tr>

        <tr>
                <td></td><td><input class="submit" type="submit" name="" value="Save"/></td>
        </tr>
    </table>
</form>
</div>
<div class="clear"></div>

<!------------------------------------------------------------------>
				 
			</div>
		</div>	
    </body>
</html>
<script>
$(function() {
    $("#city").change(function(){
        //alert("Your book is overdue.");
        var id = $('#city option:selected').val();
        //alert(id);
        $.ajax({
            url: 'search_quran.php',
            data: {city_id:id},
            type: 'post',
            success: function(data){
                $('#area').html(data);
            }
        });
    });

    $("#city1").change(function(){
        //alert("Your book is overdue.");
        var id1 = $('#city1 option:selected').val();
        //alert(id);
        $.ajax({
            url: 'search_quran.php',
            data: {city_id:id1},
            type: 'post',
            success: function(data){
                $('#area1').html(data);
            }
        });
    });
});
</script>